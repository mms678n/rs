import asyncio
import os
import select
import shlex
import signal
import socket
import subprocess
import sys
import threading
import uuid
from pathlib import Path

import paramiko
import pytest
from cryptography.fernet import Fernet
os.environ.setdefault('ENCRYPTION_KEY',Fernet.generate_key().decode())
sys.path.insert(0,str(Path(__file__).resolve().parents[2] / 'backend'))
from remote_control import ssh_manager


class SSHServer(paramiko.ServerInterface):
    def check_auth_password(self, username, password):
        return paramiko.AUTH_SUCCESSFUL if (username,password)==('test','test-password') else paramiko.AUTH_FAILED
    def get_allowed_auths(self, username): return 'password'
    def check_channel_request(self,kind,chanid): return paramiko.OPEN_SUCCEEDED if kind=='session' else paramiko.OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED
    def check_channel_exec_request(self, channel, command):
        def run():
            proc=subprocess.Popen(['/bin/bash','-c',command.decode()],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                  stdin=subprocess.DEVNULL,start_new_session=True)
            try:
                while not channel.closed:
                    readable,_,_=select.select([proc.stdout],[],[],0.05)
                    if readable:
                        data=os.read(proc.stdout.fileno(),4096)
                        if data: channel.sendall(data)
                        elif proc.poll() is not None: break
                    elif proc.poll() is not None: break
                if not channel.closed: channel.send_exit_status(proc.wait(timeout=2))
            except (OSError,subprocess.TimeoutExpired): pass
            finally:
                if proc.poll() is None:
                    try: os.killpg(proc.pid,signal.SIGKILL)
                    except ProcessLookupError: pass
                proc.wait(timeout=2)
                proc.stdout.close()
                channel.close()
        threading.Thread(target=run,daemon=True).start()
        return True


@pytest.fixture
def ssh_target(monkeypatch, tmp_path):
    monkeypatch.setenv('RSVX7_REMOTE_KNOWN_HOSTS',str(tmp_path/'known_hosts'))
    listener=socket.socket(); listener.bind(('127.0.0.1',0)); listener.listen(4); listener.settimeout(0.2)
    port=listener.getsockname()[1]
    key=paramiko.RSAKey.generate(2048)
    stop=threading.Event(); transports=[]
    def accept():
        while not stop.is_set():
            try: sock,_=listener.accept()
            except (socket.timeout,OSError): continue
            transport=paramiko.Transport(sock); transport.add_server_key(key); transports.append(transport)
            try: transport.start_server(server=SSHServer())
            except Exception: transport.close()
    thread=threading.Thread(target=accept,daemon=True); thread.start()
    monkeypatch.setattr(ssh_manager,'decrypt',lambda value:value)
    target={'_id':uuid.uuid4().hex,'host':'127.0.0.1','port':port,'username':'test','password_enc':'test-password'}
    yield target
    ssh_manager.close_client(target['_id']); stop.set(); listener.close()
    for transport in transports: transport.close()
    thread.join(timeout=1)


def test_real_ssh_stream_drains_large_output_and_preserves_exit_status(ssh_target):
    chunks=[]
    async def output(data): chunks.append(data)
    script="import sys; sys.stdout.write('X'*3000000); sys.stdout.flush(); sys.stderr.write('REAL-STDERR'); sys.exit(7)"
    command=shlex.quote(sys.executable)+' -c '+shlex.quote(script)
    result=asyncio.run(ssh_manager.run_command_stream(ssh_target,command,'bash',10,output))
    data=''.join(chunks)
    assert result['exit_code']==7, result
    assert data.count('X')==3000000
    assert 'REAL-STDERR' in data


def test_real_ssh_timeout_is_returned_to_orchestrator(ssh_target):
    chunks=[]
    async def output(data): chunks.append(data)
    result=asyncio.run(ssh_manager.run_command_stream(ssh_target,'sleep 10','bash',1,output))
    assert result['exit_code']==124, result
    assert result['timed_out'] is True
    assert 'timed out' in ''.join(chunks)


def test_real_ssh_zero_timeout_has_no_automatic_execution_deadline(ssh_target):
    chunks=[]
    async def output(data): chunks.append(data)
    result=asyncio.run(ssh_manager.run_command_stream(ssh_target,'printf START; sleep 1.3; printf DONE','bash',0,output))
    assert result['exit_code']==0, result
    assert ''.join(chunks)=='STARTDONE'


def test_real_ssh_cancellation_closes_execution_channel(ssh_target):
    async def scenario():
        entered=asyncio.Event()
        async def output(data): entered.set()
        task=asyncio.create_task(ssh_manager.run_command_stream(ssh_target,'printf START; sleep 10','bash',0,output))
        await asyncio.wait_for(entered.wait(),5)
        task.cancel()
        with pytest.raises(asyncio.CancelledError): await task
    asyncio.run(scenario())
