"""Ordered source drafts and durable repair ownership, using local fixtures only."""
import asyncio
import copy
import json
from unittest.mock import AsyncMock

import pytest
from tests.test_builder import setup, run, call, USER, SETTINGS, SOURCE
import builder
from builder_output import response_format

NEW = {'/home/project/index.html': {'type': 'file', 'content': '<h1>Reviewed new</h1>', 'isBinary': False}}
EMPTY = {'/home/project/index.html': {'type': 'file', 'content': '', 'isBinary': False}}


def pipeline(stage, completed=1, files=None):
    return {'type': 'pipeline', 'stage': stage, 'completed': completed, 'total': 1, **({'files': files} if files is not None else {})}


def execute_events(setup, monkeypatch, events, observe=None, model_settings=None, payloads=None):
    state = {**builder._empty(), 'files': SOURCE, 'messages': [], 'job': {'id': 'pipeline-job', 'status': 'running', 'mode': 'build',
        'modelSettings': model_settings or SETTINGS, 'request': {'personality': 'deepdark'}, 'model': SETTINGS['model']}}
    setup.projects.rows['p_owned']['builder'] = copy.deepcopy(state)
    class Response:
        status_code = 200
        async def aiter_lines(self):
            for event in events:
                yield json.dumps(event)
                if observe: observe(event, setup.projects.rows['p_owned']['builder'])
    class Context:
        async def __aenter__(self): return Response()
        async def __aexit__(self, *args): pass
    class Client:
        def __init__(self, **kwargs): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *args): pass
        def stream(self, *args, **kwargs):
            assert kwargs['json']['contextLength'] == SETTINGS['context_length']
            if payloads is not None: payloads.append(kwargs['json'])
            return Context()
    monkeypatch.setattr(builder.httpx, 'AsyncClient', Client)
    run(builder._run_job(USER, 'p_owned', 'pipeline-job', state, builder.RunBody(requestId='fixture-pipeline', revision=0, text='Build')))
    return setup.projects.rows['p_owned']['builder']


def result(files=NEW): return {'type': 'files', 'files': files, 'annotation': {'type': 'studioDirectBuild'}}


@pytest.mark.parametrize('provider_limit,expected', [(4096, 4096), (65536, 32768), (None, 8192)])
def test_engine_receives_the_pinned_effective_output_limit(setup, monkeypatch, provider_limit, expected):
    payloads = []
    saved = execute_events(setup, monkeypatch, [pipeline('structure', files=EMPTY), pipeline('writing', files=NEW),
        pipeline('reviewing', files=NEW), result(), {'type': 'done'}],
        model_settings={**SETTINGS, 'max_completion_tokens': provider_limit}, payloads=payloads)
    assert saved['job']['status'] == 'completed'
    assert payloads[0]['maxOutputTokens'] == expected


def test_draft_pipeline_is_persisted_without_replacing_source_until_reviewed_done(setup, monkeypatch):
    seen = []
    def observe(event, saved):
        if event['type'] == 'pipeline':
            assert saved['files'] == SOURCE and saved['revision'] == 0
            assert saved['job']['pipeline']['stage'] == event['stage']
            seen.append(saved['job']['draftFiles'])
    saved = execute_events(setup, monkeypatch, [pipeline('structure', files=EMPTY), pipeline('writing', files=NEW),
        pipeline('reviewing', files=NEW), result(), {'type': 'done'}], observe)
    assert seen == [EMPTY, NEW, NEW]
    assert saved['files'] == NEW and saved['revision'] == 1
    assert saved['job']['status'] == 'completed' and not saved['job'].get('draftFiles')
    assert saved['sourceModel'] == {'modelSettings': {key: SETTINGS.get(key) for key in builder.MODEL_FIELDS}, 'personality': 'deepdark', 'deepThink': False}


@pytest.mark.parametrize('kind', ['missing_review', 'partial_review', 'changed_final', 'review_before_writing', 'missing_snapshot', 'no_pipeline'])
def test_incomplete_or_mismatched_review_cannot_commit_source(setup, monkeypatch, kind):
    events = [pipeline('structure', files=EMPTY), pipeline('writing', files=NEW)]
    if kind == 'no_pipeline': events = []
    elif kind == 'partial_review': events.append(pipeline('reviewing', 0, NEW))
    elif kind == 'changed_final': events.append(pipeline('reviewing', files=SOURCE))
    elif kind == 'review_before_writing': events = [pipeline('structure', files=EMPTY), pipeline('reviewing', files=NEW)]
    elif kind == 'missing_snapshot': events = [pipeline('structure'), pipeline('writing'), pipeline('reviewing')]
    events += [result(), {'type': 'done'}]
    saved = execute_events(setup, monkeypatch, events)
    assert saved['files'] == SOURCE and saved['revision'] == 0 and saved['job']['status'] == 'failed'


def test_cancelled_job_cannot_persist_late_draft(setup, monkeypatch):
    def cancel_after_structure(event, saved):
        if event.get('stage') == 'structure': saved['job']['status'] = 'cancelled'
    saved = execute_events(setup, monkeypatch, [pipeline('structure', files=EMPTY), pipeline('writing', files=NEW), pipeline('reviewing', files=NEW), result(), {'type': 'done'}], cancel_after_structure)
    assert saved['files'] == SOURCE and saved['job']['status'] == 'cancelled'
    assert saved['job']['draftFiles'] == EMPTY


def test_new_pipeline_roles_use_tree_and_file_actions_contracts():
    tree = response_format('file_planner')['json_schema']['schema']
    assert tree['properties']['files']['items']['type'] == 'string'
    review = response_format('file_reviewer')['json_schema']['schema']
    assert review['properties']['actions']['minItems'] == 0
    assert review['properties']['actions']['maxItems'] == 2
    assert set(review['properties']) == {'actions', 'remainingFiles'}
    for role in ('file_planner', 'file_reviewer'):
        assert builder.ModelBody(callId='fixture-role', role=role, messages=[{'role':'user','content':'Inspect'}]).role == role


@pytest.mark.parametrize('attempts,repeated,expected', [(0,False,202), (1,False,202), (2,False,409), (1,True,409)])
def test_automatic_repair_reserves_durable_budget_and_pins_source_model(setup, monkeypatch, attempts, repeated, expected):
    original = {**SETTINGS, 'model': 'original/producing-model'}
    diagnostic = 'ReferenceError missingWidget is not defined at src/App.tsx:12'
    import hashlib, re
    fingerprint = hashlib.sha256(('preview:' + re.sub(r'\b\d+\b', '#', diagnostic)).encode()).hexdigest()
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'files': SOURCE, 'approvedPlan': {'kind': 'proposal'},
        'sourceModel': {'modelSettings': {key:original.get(key) for key in builder.MODEL_FIELDS}, 'personality':'deepdark','deepThink':True},
        'repairState': {'automaticAttempts': attempts, 'fingerprints': [fingerprint] if repeated else []}}
    monkeypatch.setattr(builder, 'ensure_engine', AsyncMock())
    async def pending(*args): await asyncio.Event().wait()
    monkeypatch.setattr(builder, '_run_job', pending)
    async def scenario():
        body = {'requestId':'automatic-repair-1','revision':0,'action':'repair','text':'Fix preview','personality':'kaligpt','deepThink':False,
            'repairContext': {'step':'preview','diagnostic':diagnostic,'automatic':True,'affectedFiles':['/home/project/index.html']}}
        response = await call('/api/builder/projects/p_owned/run','alice','POST',body)
        assert response.status_code == expected
        saved = setup.projects.rows['p_owned']['builder']
        if expected == 202:
            assert saved['job']['model'] == original['model']
            assert saved['job']['request']['personality'] == 'deepdark' and saved['job']['request']['deepThink'] is True
            assert saved['repairState']['automaticAttempts'] == attempts + 1
            assert saved['repairState']['fingerprints'][-1] == fingerprint
            again = await call('/api/builder/projects/p_owned/run','alice','POST',body)
            assert again.json()['job']['id'] == response.json()['job']['id']
            assert setup.projects.rows['p_owned']['builder']['repairState']['automaticAttempts'] == attempts + 1
            await call('/api/builder/projects/p_owned/cancel','alice','POST',{})
            await asyncio.sleep(0)
        assert setup.users.rows['alice']['token_balance'] == USER['token_balance']
    run(scenario())


def test_explicit_retry_of_cancelled_automatic_repair_does_not_reserve_again(setup, monkeypatch):
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'files': SOURCE, 'approvedPlan': {'kind':'proposal'},
        'messages': [{'role':'user','content':'Repair preview'}],
        'sourceModel': {'modelSettings':SETTINGS,'personality':'deepdark','deepThink':False},
        'repairState': {'automaticAttempts':2,'fingerprints':['prior']},
        'job': {'id':'cancelled-auto','status':'cancelled','mode':'build','revision':0,'request': {
            'action':'repair','text':'Repair preview','personality':'deepdark','repairContext': {
                'step':'preview','diagnostic':'ReferenceError missing','automatic':True,'affectedFiles':[]}}}}
    async def pending(*args): await asyncio.Event().wait()
    monkeypatch.setattr(builder, '_run_job', pending)
    async def scenario():
        response = await call('/api/builder/projects/p_owned/run','alice','POST',{'requestId':'retry-auto-explicit','revision':0,'action':'retry'})
        assert response.status_code == 202, response.text
        saved = setup.projects.rows['p_owned']['builder']
        assert saved['repairState']['automaticAttempts'] == 2
        assert saved['job']['request']['repairContext']['automatic'] is False
        await call('/api/builder/projects/p_owned/cancel','alice','POST',{})
        await asyncio.sleep(0)
    run(scenario())


def test_waiting_structure_and_review_fix_rounds_preserve_the_ordered_commit_gate(setup, monkeypatch):
    events = [pipeline('structure', 0), pipeline('structure', files=EMPTY), pipeline('writing', files=NEW),
        pipeline('reviewing', 0, NEW), pipeline('writing', files=SOURCE), pipeline('reviewing', files=SOURCE), result(SOURCE), {'type':'done'}]
    events[0]['total'] = 0
    saved = execute_events(setup, monkeypatch, events)
    assert saved['job']['status'] == 'completed' and saved['revision'] == 1 and saved['files'] == SOURCE


def test_user_source_save_resets_repair_budget_but_retains_producing_model(setup):
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'files':SOURCE, 'repairState':{'automaticAttempts':2,'fingerprints':['old']},
        'sourceModel': {'modelSettings':SETTINGS,'personality':'deepdark','deepThink':False}}
    response = run(call('/api/builder/projects/p_owned/files','alice','PUT',{'revision':0,'files':NEW}))
    assert response.status_code == 200
    saved = setup.projects.rows['p_owned']['builder']
    assert saved['repairState'] == {'automaticAttempts':0,'fingerprints':[]}
    assert saved['sourceModel']['modelSettings']['model'] == SETTINGS['model']


def test_review_model_calls_keep_snapshot_and_existing_idempotent_wallet_accounting(setup, monkeypatch):
    from types import SimpleNamespace
    import jwt
    from tests.test_builder import auth, ai_settings
    pinned = {**SETTINGS, 'model':'original/model', 'supported_parameters':['response_format','structured_outputs']}
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'job': {'id':'review-job','status':'running',
        'modelSettings':pinned,'request':{'personality':'deepdark'}}}
    calls = []
    class Stream:
        def __aiter__(self): return self.events()
        async def events(self):
            yield SimpleNamespace(usage=None, choices=[SimpleNamespace(delta=SimpleNamespace(content='{"actions":[],"remainingFiles":[]}',reasoning=None),finish_reason='stop')])
            yield SimpleNamespace(choices=[], usage=SimpleNamespace(prompt_tokens=100,completion_tokens=50,prompt_tokens_details=SimpleNamespace(cached_tokens=20)))
        async def close(self): pass
    async def create(**kwargs): calls.append(kwargs); return Stream()
    monkeypatch.setattr(ai_settings,'client',SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    token = jwt.encode({'sub':'alice','pid':'p_owned','job':'review-job','aud':'rsvx7-builder-model'},auth.JWT_SECRET,algorithm='HS256')
    request = SimpleNamespace(headers={'Authorization':'Bearer '+token},is_disconnected=AsyncMock(return_value=False))
    body = builder.ModelBody(callId='review-accounting',role='file_reviewer',jsonMode=True,messages=[{'role':'user','content':'Review source'}])
    run(builder.model_call(body, request))
    run(builder.model_call(body, request))
    assert calls[0]['model'] == 'original/model'
    schema = calls[0]['response_format']['json_schema']['schema']
    assert set(schema['properties']) == {'actions','remainingFiles'}
    assert setup.users.rows['alice']['token_balance'] == 100000 - 195
    assert len(setup.token_usage_history.rows) == 1 and not setup.ai_request_leases.rows
