"""Focused workspace regressions against a real standalone MongoDB.

These tests deliberately do not use the application owner, HTTP server, preview
backend, object storage, Telegram, OpenRouter, or a dotenv file.  Every scenario
creates one Motor client and uses it from the one ``asyncio.run`` loop that owns
all operations.  The fixed database name is private to this suite and is dropped
before and after each scenario.
"""
from __future__ import annotations

import asyncio
import importlib
import os
import sys
from pathlib import Path

import dotenv
import pytest
from fastapi import HTTPException, Response
from motor.motor_asyncio import AsyncIOMotorClient


MONGO_URL = "mongodb://127.0.0.1:27017"
DB_NAME = "rsvx7ai_test_workspace"
BACKEND = Path(__file__).resolve().parents[1] / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))
# auth.py needs these at import time; these are test-local values, not loaded
# from the application's env or credentials files.
_previous_env = {key: os.environ.get(key) for key in ("MONGO_URL", "DB_NAME")}
_real_load_dotenv = dotenv.load_dotenv
dotenv.load_dotenv = lambda *args, **kwargs: False
try:
    os.environ["MONGO_URL"] = MONGO_URL
    os.environ["DB_NAME"] = DB_NAME
    auth_module = importlib.import_module("auth")
    workspace = importlib.import_module("workspace")
finally:
    dotenv.load_dotenv = _real_load_dotenv
    for _key, _value in _previous_env.items():
        if _value is None:
            os.environ.pop(_key, None)
        else:
            os.environ[_key] = _value


@pytest.fixture
def run_scenario(monkeypatch):
    """Run one isolated scenario with one Motor client on one event loop."""

    def run(scenario):
        async def owned_loop():
            client = AsyncIOMotorClient(MONGO_URL)
            db = client[DB_NAME]
            await client.admin.command("ping")
            await client.drop_database(DB_NAME)
            # workspace.py imports db from auth.py, so patch the module actually
            # under test rather than silently talking to the application DB.
            monkeypatch.setattr(workspace, "db", db)
            monkeypatch.setattr(auth_module, "db", db)
            try:
                return await scenario(db)
            finally:
                await client.drop_database(DB_NAME)
                client.close()

        return asyncio.run(owned_loop())

    return run


def _user(uid: str = "regression-user") -> dict:
    return {"_id": uid}


def _project(pid: str, uid: str = "regression-user") -> dict:
    return {
        "_id": pid,
        "user_id": uid,
        "name": "Regression project",
        "description": "",
        "is_archived": False,
        "created_at": "now",
        "updated_at": "now",
        "last_opened_at": "now",
        "conversation_count": 0,
        "active_file_count": 0,
    }


def _conversation(cid: str, pid: str, uid: str = "regression-user", **extra) -> dict:
    return {
        "_id": cid,
        "user_id": uid,
        "project_id": pid,
        "title": "Regression chat",
        "is_pinned": False,
        "created_at": "now",
        "updated_at": "now",
        "message_count": 0,
        "next_order_index": 1,
        **extra,
    }


def _upload(name: str = "note.txt", payload: bytes = b"hello"):
    class FakeUpload:
        filename = name
        content_type = "text/plain"

        def __init__(self):
            self._remaining = payload

        async def read(self, size=-1):
            if not self._remaining:
                return b""
            if size < 0:
                size = len(self._remaining)
            chunk, self._remaining = self._remaining[:size], self._remaining[size:]
            return chunk

    return FakeUpload()


def _result(coro):
    async def capture():
        try:
            return ("ok", await coro)
        except HTTPException as exc:
            return ("http", exc.status_code)

    return capture()


def test_general_is_deterministic_upsert_and_revive(run_scenario):
    async def scenario(db):
        uid = "general-regression-user"
        concurrent = await asyncio.gather(*(
            workspace._ensure_default_project(uid) for _ in range(8)
        ))
        assert {item["_id"] for item in concurrent} == {workspace._default_project_id(uid)}
        assert await db.projects.count_documents({"user_id": uid, "name": "General"}) == 1
        first = await workspace._ensure_default_project(uid)
        second = await workspace._ensure_default_project(uid)
        assert first["_id"] == second["_id"] == workspace._default_project_id(uid)
        assert await db.projects.count_documents({"user_id": uid, "name": "General"}) == 1

        await db.projects.update_one(
            {"_id": first["_id"]},
            {"$set": {"is_archived": True, "last_opened_at": "old"}},
        )
        revived = await workspace._ensure_default_project(uid)
        assert revived["_id"] == first["_id"]
        assert revived["is_archived"] is False
        assert revived["last_opened_at"] != "old"

        # A legacy random-id General is revived in place rather than duplicated.
        legacy_uid = "legacy-general-user"
        await db.projects.insert_one({
            **_project("p_legacy_general", legacy_uid),
            "name": "General",
            "is_archived": True,
        })
        legacy = await workspace._ensure_default_project(legacy_uid)
        assert legacy["_id"] == "p_legacy_general"
        assert legacy["is_archived"] is False
        assert await db.projects.count_documents({"user_id": legacy_uid, "name": "General"}) == 1

    run_scenario(scenario)


def test_conversation_id_collision_returns_409_even_when_requests_race(run_scenario):
    async def scenario(db):
        uid = "collision-user"
        pid = "p_collision"
        await db.projects.insert_one(_project(pid, uid))
        body = workspace.ConversationCreate(id="c_same_id", title="same")
        results = await asyncio.gather(
            _result(workspace.create_conversation(pid, body, _user(uid))),
            _result(workspace.create_conversation(pid, body, _user(uid))),
        )
        assert sorted(result[0] for result in results) == ["http", "ok"]
        error = next(result for result in results if result[0] == "http")
        assert error[1] == 409
        assert await db.conversations.count_documents({"_id": "c_same_id"}) == 1

        # The same id is also never accepted in a different user's scope.
        with pytest.raises(HTTPException) as exc:
            await workspace.create_conversation(pid, body, _user("other-user"))
        assert exc.value.status_code == 404  # the project itself is isolated

    run_scenario(scenario)


def test_turn_id_collision_is_409_and_order_indexes_are_atomic(run_scenario):
    async def scenario(db):
        uid, pid, cid = "turn-user", "p_turn", "c_turn"
        await db.projects.insert_one(_project(pid, uid))
        await db.conversations.insert_one(_conversation(cid, pid, uid))

        async def save(index):
            body = workspace.TurnBody(messages=[
                workspace.MessagePayload(
                    id=f"m_race_{index}", role="user", content=f"message-{index}"
                )
            ])
            return await workspace.append_turn(cid, body, _user(uid))

        saved = await asyncio.gather(*(save(i) for i in range(16)))
        assert all(item["ok"] for item in saved)
        messages = await db.messages.find({"conversation_id": cid}).sort("order_index", 1).to_list(100)
        indexes = [message["order_index"] for message in messages]
        assert indexes == list(range(1, 17))
        assert len(indexes) == len(set(indexes))
        conversation = await db.conversations.find_one({"_id": cid})
        assert conversation["next_order_index"] == 17

        # A message id already owned by another conversation cannot be moved.
        other_cid = "c_other"
        await db.conversations.insert_one(_conversation(other_cid, pid, uid))
        await db.messages.insert_one({
            "_id": "m_shared", "user_id": uid, "conversation_id": cid,
            "project_id": pid, "role": "user", "content": "owner", "order_index": 17,
        })
        colliding = workspace.TurnBody(messages=[
            workspace.MessagePayload(id="m_shared", role="assistant", content="attack")
        ])
        with pytest.raises(HTTPException) as exc:
            await workspace.append_turn(other_cid, colliding, _user(uid))
        assert exc.value.status_code == 409
        assert (await db.messages.find_one({"_id": "m_shared"}))[
            "conversation_id"
        ] == cid

    run_scenario(scenario)


def test_migration_resumes_after_partial_message_failure(run_scenario, monkeypatch):
    async def scenario(db):
        uid = "migration-user"
        body = workspace.MigrateBody(chats=[workspace.MigrateChatIn(
            id="c_partial",
            title="Partial import",
            messages=[
                {"id": "m_partial_1", "role": "user", "content": "one"},
                {"id": "m_partial_2", "role": "assistant", "content": "two"},
            ],
        )])
        original_db = workspace.db
        original = db.messages.update_one
        failed = True

        async def fail_once(*args, **kwargs):
            nonlocal failed
            if failed:
                failed = False
                raise RuntimeError("simulated message write interruption")
            return await original(*args, **kwargs)

        class MessagesProxy:
            def __getattr__(self, name):
                return getattr(db.messages, name)

            async def update_one(self, *args, **kwargs):
                return await fail_once(*args, **kwargs)

        class DatabaseProxy:
            def __getattr__(self, name):
                if name == "messages":
                    return MessagesProxy()
                return getattr(db, name)

        monkeypatch.setattr(workspace, "db", DatabaseProxy())
        with pytest.raises(RuntimeError, match="interruption"):
            await workspace.migrate_from_local(body, _user(uid))
        assert await db.conversations.count_documents({"_id": "c_partial"}) == 1
        assert await db.messages.count_documents({"conversation_id": "c_partial"}) == 0

        monkeypatch.setattr(workspace, "db", original_db)
        resumed = await workspace.migrate_from_local(body, _user(uid))
        assert resumed["conversations_imported"] == 0
        assert resumed["messages_imported"] == 2
        assert await db.messages.count_documents({"conversation_id": "c_partial"}) == 2
        conversation = await db.conversations.find_one({"_id": "c_partial"})
        assert conversation["message_count"] == 2
        assert conversation["next_order_index"] == 3

    run_scenario(scenario)


def test_delete_project_cleans_notes_messages_and_file_metadata(run_scenario):
    async def scenario(db):
        uid, other, pid, cid = "delete-user", "other-user", "p_delete", "c_delete"
        await db.projects.insert_one(_project(pid, uid))
        await db.projects.insert_one(_project("p_other", other))
        await db.conversations.insert_one(_conversation(cid, pid, uid))
        await db.messages.insert_one({
            "_id": "m_delete", "user_id": uid, "conversation_id": cid,
            "project_id": pid, "role": "user", "content": "private", "order_index": 1,
        })
        await db.notes.insert_one({"_id": "n_delete", "user_id": uid, "project_id": pid, "content": "private"})
        await db.files.insert_many([
            {"_id": "f_delete", "user_id": uid, "project_id": pid, "is_deleted": False,
             "upload_status": "ready", "storage_path": "external/a"},
            # Legacy metadata without is_deleted must also be hidden.
            {"_id": "f_legacy", "user_id": uid, "project_id": pid,
             "upload_status": "ready", "storage_path": "external/b"},
            {"_id": "f_other", "user_id": other, "project_id": pid, "is_deleted": False,
             "upload_status": "ready"},
        ])

        result = await workspace.delete_project(pid, _user(uid))
        assert result == {"ok": True, "deleted_conversations": 1}
        assert await db.projects.find_one({"_id": pid}) is None
        assert await db.conversations.find_one({"_id": cid}) is None
        assert await db.messages.find_one({"_id": "m_delete"}) is None
        assert await db.notes.find_one({"_id": "n_delete"}) is None
        own_files = await db.files.find({"user_id": uid, "project_id": pid}).to_list(10)
        assert {item["_id"] for item in own_files} == {"f_delete", "f_legacy"}
        assert all(item["is_deleted"] is True and item["upload_status"] == "deleted" for item in own_files)
        assert (await db.files.find_one({"_id": "f_other"}))["is_deleted"] is False

    run_scenario(scenario)


def test_bounded_reader_stops_at_25mb_plus_one_byte(run_scenario):
    async def scenario(_db):
        class LargeUpload:
            def __init__(self):
                self.remaining = workspace.MAX_FILE_BYTES + 1
                self.requested = []

            async def read(self, size):
                self.requested.append(size)
                amount = min(size, self.remaining)
                self.remaining -= amount
                return b"x" * amount

        upload = LargeUpload()
        with pytest.raises(HTTPException) as exc:
            await workspace._read_upload_limited(upload)
        assert exc.value.status_code == 413
        assert sum(upload.requested) == workspace.MAX_FILE_BYTES + 1
        assert upload.requested[-1] == 1
        assert len(upload.requested) == workspace.MAX_FILE_BYTES // (1024 * 1024) + 1

    run_scenario(scenario)


def test_quota_is_atomic_and_storage_failure_rolls_back(run_scenario, monkeypatch):
    async def scenario(db):
        uid, pid = "quota-user", "p_quota"
        await db.projects.insert_one({**_project(pid, uid), "active_file_count": 49})
        await db.files.insert_many([
            {"_id": f"f_existing_{i}", "user_id": uid, "project_id": pid,
             "is_deleted": False, "upload_status": "ready"}
            for i in range(49)
        ])
        async def allow_membership(_user):
            return None
        async def allow_subscription(_user, feature=None):
            return None
        async def put(path, data, content_type):
            return {"path": path}
        monkeypatch.setattr(workspace, "require_membership", allow_membership)
        monkeypatch.setattr(workspace, "require_active_subscription", allow_subscription)
        monkeypatch.setattr(workspace, "_put_object", put)

        results = await asyncio.gather(*(
            _result(workspace.upload_file(pid, _upload(f"ok_{i}.txt"), _user(uid)))
            for i in range(4)
        ))
        assert [item[0] for item in results].count("ok") == 1
        assert [item[1] for item in results if item[0] == "http"] == [400, 400, 400]
        project = await db.projects.find_one({"_id": pid})
        assert project["active_file_count"] == 50
        assert await db.files.count_documents({"project_id": pid, "is_deleted": False}) == 50

        rollback_pid = "p_quota_rollback"
        await db.projects.insert_one({**_project(rollback_pid, uid), "active_file_count": 0})
        async def fail_put(path, data, content_type):
            raise RuntimeError("storage unavailable in test")
        monkeypatch.setattr(workspace, "_put_object", fail_put)
        with pytest.raises(RuntimeError, match="storage unavailable"):
            await workspace.upload_file(rollback_pid, _upload("failed.txt"), _user(uid))
        rolled_back = await db.projects.find_one({"_id": rollback_pid})
        assert rolled_back["active_file_count"] == 0
        failed = await db.files.find_one({"project_id": rollback_pid})
        assert failed["is_deleted"] is True
        assert failed["upload_status"] == "failed"

    run_scenario(scenario)


def test_download_requires_scoped_auth_and_client_uses_blob_authorization(run_scenario, monkeypatch):
    async def scenario(db):
        uid, pid, fid = "download-user", "p_download", "f_download"
        await db.projects.insert_one(_project(pid, uid))
        await db.files.insert_one({
            "_id": fid, "user_id": uid, "project_id": pid, "is_deleted": False,
            "upload_status": "ready", "storage_path": "external/download", "content_type": "text/plain",
        })
        seen = {}

        async def get_object(path):
            seen["path"] = path
            return b"downloaded", "text/plain"

        monkeypatch.setattr(workspace, "_get_object", get_object)
        response = await workspace.download_file(fid, _user(uid))
        assert isinstance(response, Response)
        assert response.body == b"downloaded"
        assert response.media_type == "text/plain"
        assert seen["path"] == "external/download"
        with pytest.raises(HTTPException) as exc:
            await workspace.download_file(fid, _user("wrong-user"))
        assert exc.value.status_code == 404

    run_scenario(scenario)
    client_source = (BACKEND.parent / "frontend/src/lib/workspacePhase2Client.js").read_text()
    assert "?auth=" not in client_source
    assert "Authorization" in client_source
    assert "URL.createObjectURL(" in client_source and ".blob()" in client_source
    assert "URL.revokeObjectURL(url)" in client_source and "revoked" in client_source


def test_preview_gates_media_and_download_links_and_context_guards_are_stale_safe():
    preview = (BACKEND.parent / "frontend/src/components/workspace/ProjectSettingsDialog.jsx").read_text()
    context = (BACKEND.parent / "frontend/src/context/WorkspaceContext.jsx").read_text()
    assert "!loading && !error && file.kind === \"image\"" in preview
    assert "!loading && !error && file.kind === \"pdf\"" in preview
    assert "!loading && !error && file.kind !== \"image\" && file.kind !== \"pdf\"" in preview
    assert "download={file.name}" in preview
    assert "next?.revoke?.()" in preview and "revoke?.()" in preview
    assert "activeUserRef.current !== requestUser" in context
    assert "sessionRef.current !== requestSession" in context
    assert "}, []);" in context[context.index("const touchProjectOpened") : context.index("const currentProject")]
