"""Transport-only tests: no database, provider or account writes."""
import asyncio,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from sse_transport import with_heartbeats


def test_heartbeat_during_silence_without_losing_events():
    async def scenario():
        async def source():
            yield 'data: first\n\n'
            await asyncio.sleep(.04)
            yield 'data: last\n\n'
        events=[event async for event in with_heartbeats(source(),interval=.01)]
        assert events[0]=='data: first\n\n'
        assert events[-1]=='data: last\n\n'
        assert ': keep-alive\n\n' in events
    asyncio.run(scenario())


def test_cancel_closes_generator_and_its_scope_on_the_owner_task():
    async def scenario():
        import anyio
        closed=asyncio.Event()
        async def source():
            try:
                with anyio.fail_after(20):
                    yield 'data: first\n\n'
                    await asyncio.sleep(10)
            finally:
                closed.set()
        stream=with_heartbeats(source(),interval=.01)
        assert await anext(stream)=='data: first\n\n'
        await stream.aclose()
        assert closed.is_set()
        assert not [task for task in asyncio.all_tasks() if task.get_name()=='rsvx7-sse-producer']
    asyncio.run(scenario())


def test_bounded_producer_has_backpressure_and_cancels_if_consumer_stops():
    async def scenario():
        produced=[];closed=asyncio.Event()
        async def source():
            try:
                for i in range(1000):
                    produced.append(i)
                    yield f'data: {i}\n\n'
            finally: closed.set()
        stream=with_heartbeats(source(),capacity=2)
        await anext(stream)
        await asyncio.sleep(.01)
        assert len(produced)<=4
        await stream.aclose()
        assert closed.is_set()
    asyncio.run(scenario())


def test_source_exception_is_not_silently_reported_as_success():
    async def scenario():
        async def source():
            yield 'data: first\n\n'
            raise RuntimeError('transport-test-failure')
        stream=with_heartbeats(source())
        assert await anext(stream)=='data: first\n\n'
        try: await anext(stream)
        except RuntimeError as exc: assert 'transport-test-failure' in str(exc)
        else: raise AssertionError('Expected source exception')
    asyncio.run(scenario())


def test_asgi_cancel_scope_does_not_recancel_producer_during_cleanup():
    async def scenario():
        import anyio
        started=anyio.Event();closed=asyncio.Event()
        async def source():
            try:
                with anyio.fail_after(20):
                    yield 'data: first\n\n'
                    await asyncio.sleep(10)
            finally:
                with anyio.CancelScope(shield=True):
                    # Simulate releasing a Mongo lease / provider socket.
                    await asyncio.sleep(.05)
                    closed.set()
        async def consumer():
            async for _ in with_heartbeats(source()):
                started.set()
        async with anyio.create_task_group() as group:
            group.start_soon(consumer)
            await started.wait()
            group.cancel_scope.cancel()
        assert closed.is_set(), 'ASGI cancellation interrupted lease cleanup'
    asyncio.run(scenario())
