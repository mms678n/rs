"""Actual async bridge execution: accounting, cancellation and parameter compatibility."""
import asyncio, json
from types import SimpleNamespace
from unittest.mock import AsyncMock
import jwt,pytest
from fastapi import HTTPException
from tests.test_builder import setup,run,builder,auth,ai_settings,SETTINGS

def frame(text='',finish=None,usage=None):
    return SimpleNamespace(usage=usage,choices=[SimpleNamespace(delta=SimpleNamespace(content=text,reasoning=None),finish_reason=finish)])
def context(db,monkeypatch,chunks,**options):
    db.projects.rows['p_owned']['builder']={**builder._empty(),'job':{'id':'stream-job','status':'running'}}
    closed=[];calls=[]
    class Stream:
        def __aiter__(self):return self.events()
        async def events(self):
            for chunk in chunks:yield chunk
        async def close(self):closed.append(True)
    async def create(**kwargs):calls.append(kwargs);return Stream()
    monkeypatch.setattr(ai_settings,'client',SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    token=jwt.encode({'sub':'alice','pid':'p_owned','job':'stream-job','aud':'rsvx7-builder-model'},auth.JWT_SECRET,algorithm='HS256')
    request=SimpleNamespace(headers={'Authorization':'Bearer '+token},is_disconnected=AsyncMock(return_value=False))
    body=builder.ModelBody(callId='stream-fixture',stream=True,role='builder',jsonMode=True,messages=[{'role':'user','content':'Return file JSON for an Arabic greeting'}],**options)
    return body,request,closed,calls
async def read(response):
    chunks=[piece async for piece in response.body_iterator]
    data=''.join(piece.decode() if isinstance(piece,bytes) else piece for piece in chunks)
    return chunks,[json.loads(line) for line in data.splitlines() if line.strip()]

def test_stream_delivers_deltas_then_usage_confirmed_result(setup,monkeypatch):
    usage=SimpleNamespace(prompt_tokens=100,completion_tokens=50,prompt_tokens_details=SimpleNamespace(cached_tokens=20))
    body,request,closed,calls=context(setup,monkeypatch,[frame('أهلاً '),frame('وسهلاً',finish='stop'),frame(finish='stop',usage=usage)])
    async def scenario():
        chunks,events=await read(await builder.model_call(body,request))
        assert chunks[0]=='\n'
        assert ''.join(event.get('text','') for event in events)=='أهلاً وسهلاً'
        assert events[-1]=={'type':'result','finishReason':'stop'}
    run(scenario())
    assert setup.users.rows['alice']['token_balance']==100000-195
    assert len(setup.token_usage_history.rows)==1 and not setup.ai_request_leases.rows and closed

def test_stream_failure_after_partial_output_never_sends_success_or_debits(setup,monkeypatch):
    body,request,closed,calls=context(setup,monkeypatch,[frame('partial',finish='stop'),frame('late source')])
    async def scenario():
        _,events=await read(await builder.model_call(body,request))
        assert events[-1]['type']=='error' and events[-1]['status']==502
        assert not any(event['type']=='result' for event in events)
    run(scenario())
    assert not setup.token_usage_history.rows and not setup.ai_request_leases.rows and closed

def test_invalid_capability_is_rejected_before_stream_headers(setup,monkeypatch):
    body,request,closed,calls=context(setup,monkeypatch,[])
    request.headers={'Authorization':'Bearer invalid-token'}
    with pytest.raises(HTTPException) as caught:run(builder.model_call(body,request))
    assert caught.value.status_code==401 and not calls and not setup.ai_request_leases.rows

def test_stream_cancellation_closes_provider_and_releases_lease(setup,monkeypatch):
    body,request,closed,calls=context(setup,monkeypatch,[])
    async def scenario():
        waiting=asyncio.Event()
        class Stream:
            def __aiter__(self):return self.events()
            async def events(self):
                yield frame('partial')
                await waiting.wait()
            async def close(self):closed.append(True)
        async def create(**kwargs):return Stream()
        monkeypatch.setattr(ai_settings.client.chat.completions,'create',create)
        response=await builder.model_call(body,request)
        iterator=response.body_iterator
        assert await iterator.__anext__()=='\n'
        assert json.loads(await iterator.__anext__())['type']=='delta'
        await asyncio.wait_for(iterator.aclose(),1)
    run(scenario())
    assert closed and not setup.ai_request_leases.rows and not setup.token_usage_history.rows

def test_heartbeat_is_sent_while_provider_has_not_returned_headers(setup,monkeypatch):
    body,request,closed,calls=context(setup,monkeypatch,[])
    monkeypatch.setattr(builder,'MODEL_HEARTBEAT_SECONDS',.01)
    async def scenario():
        async def create(**kwargs):await asyncio.Event().wait()
        monkeypatch.setattr(ai_settings.client.chat.completions,'create',create)
        iterator=(await builder.model_call(body,request)).body_iterator
        assert await iterator.__anext__()=='\n'
        assert await asyncio.wait_for(iterator.__anext__(),.3)=='\n'
        await iterator.aclose()
    run(scenario())
    assert not setup.ai_request_leases.rows and not setup.token_usage_history.rows

@pytest.mark.parametrize('rejections',[1,2])
def test_unsupported_output_parameter_falls_back_before_any_generation(setup,monkeypatch,rejections):
    body,request,closed,calls=context(setup,monkeypatch,[frame('{"files":{"index.html":"ok"}}',finish='stop')])
    monkeypatch.setattr(builder,'current_settings',AsyncMock(return_value={**SETTINGS,'supported_parameters':['response_format','structured_outputs']}))
    original=ai_settings.client.chat.completions.create
    attempted=[]
    class Unsupported(Exception):
        status_code=400
        body={'error':{'message':'response_format json_schema is not supported'}}
    async def create(**kwargs):
        attempted.append(kwargs)
        if len(attempted)<=rejections:raise Unsupported('unsupported response_format')
        return await original(**kwargs)
    monkeypatch.setattr(ai_settings.client.chat.completions,'create',create)
    async def scenario():
        _,events=await read(await builder.model_call(body,request))
        assert events[-1]['type']=='result'
    run(scenario())
    assert len(attempted)==rejections+1
    assert attempted[0]['response_format']['type']=='json_schema'
    assert attempted[1]['response_format']=={'type':'json_object'}
    if rejections==2:assert 'response_format' not in attempted[2]
    assert len(setup.token_usage_history.rows)==1 and closed and not setup.ai_request_leases.rows

@pytest.mark.parametrize('message',['invalid messages content','response_format blocked by content policy','response_format invalid due to privacy guardrail'])
def test_non_format_errors_never_trigger_parameter_fallback(setup,monkeypatch,message):
    body,request,closed,calls=context(setup,monkeypatch,[])
    monkeypatch.setattr(builder,'current_settings',AsyncMock(return_value={**SETTINGS,'supported_parameters':['response_format','structured_outputs']}))
    class Rejected(Exception):
        status_code=400
        body={}
    async def create(**kwargs):calls.append(kwargs);raise Rejected(message)
    monkeypatch.setattr(ai_settings.client.chat.completions,'create',create)
    async def scenario():
        _,events=await read(await builder.model_call(body,request))
        assert events[-1]['type']=='error'
    run(scenario())
    assert len(calls)==1 and not setup.token_usage_history.rows and not setup.ai_request_leases.rows

@pytest.mark.parametrize('health',[{'protocol':1,'mode':'agents'},'ok',{'protocol':2,'mode':'direct'},{'protocol':3,'mode':'direct'},{'protocol':4,'mode':'direct'},{'protocol':5,'mode':'direct'}])
def test_engine_handshake_detects_stale_processes_and_ignores_external_proxies(setup,monkeypatch,health):
    import httpx
    options=[]
    class Client:
        def __init__(self,**kwargs):options.append(kwargs)
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        async def get(self,*args,**kwargs):return httpx.Response(200,json=health)
    monkeypatch.setattr(builder.httpx,'AsyncClient',Client)
    launch=AsyncMock();monkeypatch.setattr(builder.asyncio,'create_subprocess_exec',launch)
    if health=={'protocol':5,'mode':'direct'}:run(builder.ensure_engine())
    else:
        with pytest.raises(HTTPException) as caught:run(builder.ensure_engine())
        assert caught.value.status_code==503 and 'قديمة' in caught.value.detail
    assert options[0]['trust_env'] is False
    launch.assert_not_awaited()

def test_whole_model_call_times_out_while_waiting_for_provider_headers(setup,monkeypatch):
    body,request,closed,calls=context(setup,monkeypatch,[])
    monkeypatch.setattr(builder,'MODEL_CALL_SECONDS',.03)
    async def create(**kwargs):await asyncio.Event().wait()
    monkeypatch.setattr(ai_settings.client.chat.completions,'create',create)
    async def scenario():
        _,events=await asyncio.wait_for(read(await builder.model_call(body,request)),.5)
        assert events[-1]['type']=='error' and events[-1]['status']==504
        assert not any(event['type']=='result' for event in events)
    run(scenario())
    assert not setup.ai_request_leases.rows and not setup.token_usage_history.rows

def test_timeout_covers_accounting_after_the_sdk_stream_already_finished(setup,monkeypatch):
    body,request,closed,calls=context(setup,monkeypatch,[frame('complete files',finish='stop')])
    monkeypatch.setattr(builder,'MODEL_CALL_SECONDS',.03)
    async def hung_accounting(*args,**kwargs):await asyncio.Event().wait()
    monkeypatch.setattr(builder,'charge_user',hung_accounting)
    async def scenario():
        _,events=await asyncio.wait_for(read(await builder.model_call(body,request)),.5)
        assert any(event.get('phase')=='accounting' for event in events)
        assert events[-1]['type']=='error' and events[-1]['status']==504
        assert not any(event['type']=='result' for event in events)
    run(scenario())
    assert closed and not setup.ai_request_leases.rows and not setup.token_usage_history.rows

def test_thinking_progress_has_counts_without_private_reasoning_text(setup,monkeypatch):
    thinking=frame();thinking.choices[0].delta.reasoning='PRIVATE synthetic thought'
    body,request,closed,calls=context(setup,monkeypatch,[thinking,frame('source',finish='stop')])
    async def scenario():
        _,events=await read(await builder.model_call(body,request))
        assert any(event.get('reasoningChars')==len('PRIVATE synthetic thought') for event in events)
        assert 'PRIVATE' not in json.dumps(events)
        assert events[-1]['type']=='result'
    run(scenario())

def test_preflight_identity_timeout_rejects_before_stream_headers(setup,monkeypatch):
    body,request,closed,calls=context(setup,monkeypatch,[])
    monkeypatch.setattr(builder,'MODEL_PREFLIGHT_SECONDS',.01)
    async def hung(*args):await asyncio.Event().wait()
    monkeypatch.setattr(builder,'_model_identity',hung)
    with pytest.raises(HTTPException) as error:run(builder.model_call(body,request))
    assert error.value.status_code==504 and not calls

def test_a_stuck_lease_cleanup_cannot_keep_the_response_open_forever(setup,monkeypatch):
    body,request,closed,calls=context(setup,monkeypatch,[frame('source',finish='stop')])
    monkeypatch.setattr(builder,'MODEL_CLEANUP_SECONDS',.01)
    async def hung(*args):await asyncio.Event().wait()
    monkeypatch.setattr(builder,'release_generation',hung)
    async def scenario():
        _,events=await asyncio.wait_for(read(await builder.model_call(body,request)),.5)
        assert events[-1]['type']=='result'
    run(scenario())
    assert closed and len(setup.token_usage_history.rows)==1

def test_builder_lease_covers_the_entire_bounded_model_call(setup,monkeypatch):
    from datetime import datetime,timezone
    body,request,closed,calls=context(setup,monkeypatch,[frame('source',finish='stop')])
    original=ai_settings.client.chat.completions.create
    async def create(**kwargs):
        lease=setup.ai_request_leases.rows['alice']
        assert (lease['expires_at']-datetime.now(timezone.utc)).total_seconds()>builder.MODEL_CALL_SECONDS
        return await original(**kwargs)
    monkeypatch.setattr(ai_settings.client.chat.completions,'create',create)
    async def scenario():
        _,events=await read(await builder.model_call(body,request));assert events[-1]['type']=='result'
    run(scenario())
    assert not setup.ai_request_leases.rows


@pytest.mark.parametrize('provider_limit,expected', [(4096,4096),(65536,32768),(None,8192)])
def test_provider_receives_the_same_output_limit_advertised_to_the_engine(setup,monkeypatch,provider_limit,expected):
    body,request,closed,calls=context(setup,monkeypatch,[frame('source',finish='stop')])
    setup.users.rows['alice']['role']='admin'
    setup.projects.rows['p_owned']['builder']['job']['modelSettings']={**SETTINGS,
        'context_length':131072,'max_completion_tokens':provider_limit}
    async def scenario():
        _,events=await read(await builder.model_call(body,request))
        assert events[-1]['type']=='result'
    run(scenario())
    assert calls[0]['max_tokens']==expected
    assert closed and not setup.ai_request_leases.rows


def test_small_context_reserves_prompt_and_output_without_overflow(setup,monkeypatch):
    body,request,closed,calls=context(setup,monkeypatch,[frame('source',finish='stop')])
    setup.projects.rows['p_owned']['builder']['job']['modelSettings']={**SETTINGS,'context_length':1024}
    async def scenario():
        _,events=await read(await builder.model_call(body,request))
        assert events[-1]['type']=='result'
    run(scenario())
    assert 0<calls[0]['max_tokens']<1024
    assert builder.estimate_messages_tokens(body.messages)+calls[0]['max_tokens']+256==1024
    assert closed and not setup.ai_request_leases.rows


def test_context_rejection_keeps_a_machine_readable_code_in_streamed_error(setup,monkeypatch):
    body,request,closed,calls=context(setup,monkeypatch,[])
    setup.projects.rows['p_owned']['builder']['job']['modelSettings']={**SETTINGS,'context_length':1}
    async def scenario():
        _,events=await read(await builder.model_call(body,request))
        assert events[-1]['status']==413
        assert events[-1]['code']=='context'
        assert events[-1]['message']
    run(scenario())
    assert not calls and not setup.ai_request_leases.rows and not setup.token_usage_history.rows
