import asyncio
import json
from pathlib import Path
import subprocess
import sys
import httpx
import pytest
from tests.test_vps import db  # isolated owner/admin fixtures
import auth, server, platform_updates
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import platform_updater as updater

def run(value): return asyncio.run(value)
async def api(uid='owner', method='GET', body=None):
    headers = {'Authorization': 'Bearer ' + auth.make_token(uid, 'super_admin' if uid == 'owner' else 'admin')} if uid else {}
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url='https://fixture.local') as client:
        return await client.request(method, '/api/admin/platform-update', headers=headers, json=body)

@pytest.fixture
def control(tmp_path, monkeypatch):
    monkeypatch.setattr(platform_updates, 'CONTROL', tmp_path)
    (tmp_path / 'requests').mkdir()
    (tmp_path / 'heartbeat').touch()
    (tmp_path / 'status.json').write_text(json.dumps(dict(status='idle', stage='ready', repository='owner/repo', branch='main', token='must-not-return')))
    return tmp_path

def test_owner_only_and_status_redaction(db, control):
    assert run(api(None)).status_code == 401
    assert run(api('admin')).status_code == 403
    response = run(api())
    assert response.status_code == 200 and response.json()['configured']
    assert 'must-not-return' not in response.text and 'token' not in response.text

def test_request_is_fixed_atomic_and_coalesced(db, control):
    response = run(api(method='POST', body={'command':'malicious', 'repository':'attacker/repo'}))
    assert response.status_code == 202 and response.json()['status'] == 'pending'
    assert (control / 'requests/update').read_bytes() == b''
    assert run(api(method='POST')).status_code == 409
    assert json.loads((control / 'status.json').read_text())['repository'] == 'owner/repo'

def test_unconfigured_never_writes_request(db, control):
    (control / 'status.json').unlink()
    assert run(api()).json()['configured'] is False
    assert run(api(method='POST')).status_code == 409
    assert not (control / 'requests/update').exists()

def test_stopped_worker_cannot_accept_updates(db, control):
    (control / 'heartbeat').unlink()
    assert run(api()).json()['status'] == 'offline'
    assert run(api(method='POST')).status_code == 503
    assert not (control / 'requests/update').exists()

def test_credential_helper_only_releases_token_for_fixed_github_repository(tmp_path,monkeypatch,capsys):
    import io
    monkeypatch.setattr(updater,'BASE',tmp_path)
    (tmp_path/'config.json').write_text('{"repository":"owner/repo"}')
    (tmp_path/'token').write_text('fixture-private-token')
    monkeypatch.setattr(sys,'argv',['updater','credential','get'])
    monkeypatch.setattr(sys,'stdin',io.StringIO('protocol=https\nhost=attacker.example\npath=owner/repo.git\n\n'))
    updater.credential(); assert capsys.readouterr().out == ''
    monkeypatch.setattr(sys,'stdin',io.StringIO('protocol=https\nhost=github.com\npath=owner/repo.git\n\n'))
    updater.credential(); assert 'password=fixture-private-token' in capsys.readouterr().out

def test_archive_real_git_validates_production_files_and_rejects_symlinks(tmp_path, monkeypatch):
    monkeypatch.setattr(updater, 'BASE', tmp_path)
    repo = tmp_path / 'source'; repo.mkdir()
    subprocess.run(['git','init',str(repo)], check=True, capture_output=True)
    for name in ('Dockerfile.selfhost','deploy/compose.selfhost.yaml','backend/server.py','frontend/build/index.html','builder/dist/service.mjs'):
        p = repo / name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text('fixture')
    (repo / 'frontend/build/asset-manifest.json').write_text('{"files":{"index":"/index.html"},"entrypoints":[]}')
    def commit():
        subprocess.run(['git','-C',str(repo),'add','.'],check=True)
        subprocess.run(['git','-C',str(repo),'-c','user.name=Fixture','-c','user.email=fixture@example.test','commit','-m','fixture'],check=True,capture_output=True)
    commit()
    updater.export_tree(repo,'HEAD',tmp_path/'release')
    assert (tmp_path/'release/frontend/build/index.html').read_text() == 'fixture'
    (repo/'escape').symlink_to('/etc/passwd');commit()
    with pytest.raises(ValueError): updater.export_tree(repo,'HEAD',tmp_path/'unsafe')

def test_build_failure_keeps_old_release_and_private_env(tmp_path,monkeypatch):
    monkeypatch.setattr(updater,'BASE',tmp_path)
    (tmp_path/'control').mkdir(); (tmp_path/'repository').mkdir(); (tmp_path/'releases').mkdir()
    config={'repository':'owner/repo','branch':'main','source':'/existing/source','env_file':'/existing/.env.selfhost'}
    calls=[]
    def command(args,**kwargs):
        calls.append(args)
        if 'rev-parse' in args:return b'a'*40+b'\n'
        return b''
    monkeypatch.setattr(updater,'run',command)
    monkeypatch.setattr(updater,'export_tree',lambda *args:None)
    def compose(source,config,*args):
        calls.append(args)
        raise subprocess.CalledProcessError(1,args)
    monkeypatch.setattr(updater,'compose',compose)
    updater.update(config)
    assert config['source']=='/existing/source' and config['env_file']=='/existing/.env.selfhost'
    assert ('up','-d') not in calls
    assert json.loads((tmp_path/'control/status.json').read_text())['status']=='failed'

def test_failed_startup_restores_old_source(tmp_path,monkeypatch):
    monkeypatch.setattr(updater,'BASE',tmp_path)
    for name in ('control','repository','releases'):(tmp_path/name).mkdir()
    config={'repository':'owner/repo','branch':'main','source':'/existing/source','env_file':'/existing/.env.selfhost'}
    monkeypatch.setattr(updater,'run',lambda args,**kwargs: b'b'*40+b'\n' if 'rev-parse' in args else b'')
    monkeypatch.setattr(updater,'export_tree',lambda *args:None)
    calls=[]
    monkeypatch.setattr(updater,'compose',lambda source,config,*args:calls.append((str(source),args)))
    def verify(source,config):
        if str(source)!='/existing/source':raise ValueError('unhealthy release')
    monkeypatch.setattr(updater,'verify',verify)
    updater.update(config)
    assert ('/existing/source',('up','-d')) in calls
    assert json.loads((tmp_path/'control/status.json').read_text())['stage']=='restored'

def test_success_persists_release_and_second_click_does_not_rebuild(tmp_path,monkeypatch):
    monkeypatch.setattr(updater,'BASE',tmp_path)
    for name in ('control','repository','releases'):(tmp_path/name).mkdir()
    config={'repository':'owner/repo','branch':'main','source':'/existing/source','env_file':'/existing/.env.selfhost'}
    monkeypatch.setattr(updater,'run',lambda args,**kwargs: b'c'*40+b'\n' if 'rev-parse' in args else b'')
    monkeypatch.setattr(updater,'export_tree',lambda *args:None)
    calls=[]
    monkeypatch.setattr(updater,'compose',lambda source,config,*args:calls.append(args))
    monkeypatch.setattr(updater,'verify',lambda *args:None)
    updater.update(config)
    assert config['commit']=='c'*40
    assert json.loads((tmp_path/'config.json').read_text())['env_file']=='/existing/.env.selfhost'
    assert json.loads((tmp_path/'control/status.json').read_text())['stage']=='ready'
    calls.clear();updater.update(config)
    assert calls==[]
    assert json.loads((tmp_path/'control/status.json').read_text())['stage']=='current'
