"""Exercise the real OpenAI SDK over in-memory SSE; no network/model/database calls."""
import asyncio
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest
from openai import AsyncOpenAI
from tests.test_reasoning_regressions import patch_chat, server

SETTINGS = {
    'model': 'fixture/coder:fastest', 'context_length': 32000,
    'max_completion_tokens': 512, 'supported_parameters': ['temperature'],
    'reasoning': None,
}
USER = {'_id': 'hf-fixture-user', 'role': 'super_admin'}


def sdk_chunk(delta=None, finish=None, usage=None):
    return {
        'id': 'fixture', 'object': 'chat.completion.chunk', 'created': 1,
        'model': SETTINGS['model'],
        'choices': [] if delta is None and finish is None else [
            {'index': 0, 'delta': delta or {}, 'finish_reason': finish}],
        'usage': usage,
    }


async def collect(response):
    body = ''.join([part async for part in response.body_iterator])
    return [json.loads(line[6:]) for line in body.splitlines()
            if line.startswith('data: ') and line != 'data: [DONE]']


async def sdk_scenario(monkeypatch, chunks):
    requests = []

    async def handle(request):
        requests.append(json.loads(request.content))
        wire = ''.join('data: ' + json.dumps(chunk) + '\n\n' for chunk in chunks)
        return httpx.Response(200, headers={'content-type': 'text/event-stream'},
                              content=(wire + 'data: [DONE]\n\n').encode())

    http = httpx.AsyncClient(transport=httpx.MockTransport(handle))
    client = AsyncOpenAI(api_key='fixture-not-a-secret', base_url='https://router.huggingface.co/v1',
                         http_client=http, max_retries=0)
    _, charge = patch_chat(monkeypatch, None, SETTINGS)
    monkeypatch.setattr(server, 'openrouter_client', client)
    try:
        response = await server.chat_stream(server.ChatStreamRequest(
            messages=[{'role': 'user', 'content': 'write code'}]), USER)
        events = await collect(response)
        return events, charge, requests
    finally:
        await client.close()


def test_sdk_hf_terminal_usage_only_chunk_bills_once_and_preserves_code(monkeypatch):
    async def scenario():
        events, charge, requests = await sdk_scenario(monkeypatch, [
            sdk_chunk({'role': 'assistant', 'content': ''}),
            sdk_chunk({}),
            sdk_chunk({'reasoning_content': 'plan'}),
            sdk_chunk({'content': '```python\nprint(1)\n```'}),
            sdk_chunk({}, 'stop'),
            sdk_chunk(usage={'prompt_tokens': 23, 'completion_tokens': 9, 'total_tokens': 32}),
        ])
        assert ''.join(e.get('t', '') for e in events) == '```python\nprint(1)\n```'
        assert ''.join(e.get('r', '') for e in events) == 'plan'
        assert {'finish': 'stop'} in events
        charge.assert_awaited_once()
        assert charge.await_args.kwargs['prompt_tokens'] == 23
        assert charge.await_args.kwargs['completion_tokens'] == 9
        assert requests[0]['stream_options'] == {'include_usage': True}
        assert requests[0]['model'] == SETTINGS['model']
        assert len(requests) == 1
    asyncio.run(scenario())


def test_sdk_text_content_parts_are_not_dropped_or_nontext_payloads_exposed(monkeypatch):
    async def scenario():
        events, charge, _ = await sdk_scenario(monkeypatch, [
            sdk_chunk({'content': [{'type': 'text', 'text': '```js\n'},
                                   {'type': 'image_url', 'image_url': 'private'},
                                   {'type': 'text', 'text': '1\n```'}]}, 'stop'),
        ])
        assert ''.join(e.get('t', '') for e in events) == '```js\n1\n```'
        assert 'private' not in json.dumps(events)
        charge.assert_awaited_once()
    asyncio.run(scenario())


@pytest.mark.parametrize('reported_usage', [{}, {'prompt_tokens': 23}, {'completion_tokens': 4}])
def test_sdk_partial_usage_falls_back_only_for_missing_counts(monkeypatch, reported_usage):
    async def scenario():
        monkeypatch.setattr(server, 'estimate_messages_tokens', lambda msgs: len(msgs[0]['content']))
        events, charge, _ = await sdk_scenario(monkeypatch, [
            sdk_chunk({'content': 'answer'}, 'stop'), sdk_chunk(usage=reported_usage),
        ])
        assert {'finish': 'stop'} in events
        charge.assert_awaited_once()
        expected_prompt = reported_usage.get('prompt_tokens', len(server.PERSONALITIES['kaligpt']))
        assert charge.await_args.kwargs['prompt_tokens'] == expected_prompt
        assert charge.await_args.kwargs['completion_tokens'] == reported_usage.get('completion_tokens', 6)
    asyncio.run(scenario())


@pytest.mark.parametrize('tail', [[], [sdk_chunk(usage={'prompt_tokens': 23, 'completion_tokens': 4})],
                                [{'error': {'message': 'fixture secret', 'code': 500}}]])
def test_sdk_interrupted_or_errored_stream_does_not_bill_or_report_success(monkeypatch, tail):
    async def scenario():
        events, charge, requests = await sdk_scenario(monkeypatch, [sdk_chunk({'content': 'partial'}), *tail])
        assert any('error' in e for e in events)
        assert not any('finish' in e or 'usage' in e for e in events)
        assert 'fixture secret' not in json.dumps(events)
        charge.assert_not_awaited()
        assert len(requests) == 1
    asyncio.run(scenario())


def test_cancel_before_background_task_starts_releases_generation_without_provider_call(monkeypatch):
    import stream_buffer

    async def scenario():
        monkeypatch.setattr(stream_buffer, '_STREAMS', {})
        create, charge = patch_chat(monkeypatch, None, SETTINGS)
        await server.chat_stream(server.ChatStreamRequest(
            messages=[{'role': 'user', 'content': 'hello'}]), USER)
        state = next(iter(stream_buffer._STREAMS.values()))
        assert stream_buffer.cancel_stream(state)
        await asyncio.gather(state['task'], return_exceptions=True)
        assert state['done']
        create.assert_not_awaited()
        charge.assert_not_awaited()
        server.release_generation.assert_awaited_once_with(USER['_id'], 'reasoning-lease')
    asyncio.run(scenario())


def test_repeated_cancel_does_not_interrupt_provider_close_or_lease_release(monkeypatch):
    import stream_buffer

    async def scenario():
        monkeypatch.setattr(stream_buffer, '_STREAMS', {})
        reading, closing, allow_close = asyncio.Event(), asyncio.Event(), asyncio.Event()

        class BlockingStream:
            async def __aiter__(self):
                yield SimpleNamespace(choices=[SimpleNamespace(
                    delta=SimpleNamespace(content='partial'), finish_reason=None)], usage=None)
                reading.set()
                await asyncio.Event().wait()

            async def close(self):
                closing.set()
                await allow_close.wait()

        _, charge = patch_chat(monkeypatch, BlockingStream(), SETTINGS)
        await server.chat_stream(server.ChatStreamRequest(
            messages=[{'role': 'user', 'content': 'hello'}]), USER)
        state = next(iter(stream_buffer._STREAMS.values()))
        await reading.wait()
        assert stream_buffer.cancel_stream(state)
        await closing.wait()
        assert not stream_buffer.cancel_stream(state)
        allow_close.set()
        await asyncio.gather(state['task'], return_exceptions=True)
        assert state['done']
        charge.assert_not_awaited()
        server.release_generation.assert_awaited_once_with(USER['_id'], 'reasoning-lease')
    asyncio.run(scenario())


def test_disconnect_and_replay_preserve_stream_and_charge_exactly_once(monkeypatch):
    import stream_buffer

    async def scenario():
        monkeypatch.setattr(stream_buffer, '_STREAMS', {})
        resume_provider = asyncio.Event()

        class PausedStream:
            close = AsyncMock()

            async def __aiter__(self):
                for delta, finish, usage in [
                    ({'content': '```python\n'}, None, None),
                    ({'content': 'print(1)\n```'}, 'stop', None),
                    (None, None, SimpleNamespace(prompt_tokens=19, completion_tokens=8)),
                ]:
                    if finish:
                        await resume_provider.wait()
                    yield SimpleNamespace(choices=[] if delta is None else [SimpleNamespace(
                        delta=SimpleNamespace(**delta), finish_reason=finish)], usage=usage)

        stream = PausedStream()
        _, charge = patch_chat(monkeypatch, stream, SETTINGS)
        response = await server.chat_stream(server.ChatStreamRequest(
            messages=[{'role': 'user', 'content': 'hello'}]), USER)
        received = []
        async for event in response.body_iterator:
            received.append(json.loads(event[6:]))
            if 't' in received[-1]:
                break
        await response.body_iterator.aclose()
        sid = received[0]['stream']['id']
        state = stream_buffer.get_stream(sid, USER['_id'])
        assert not state['done']
        assert stream_buffer.get_stream(sid, 'another-user') is None
        resume_provider.set()
        await state['task']
        resumed = await collect(await server.resume_chat_stream(sid, len(received), USER))
        assert ''.join(e.get('t', '') for e in received + resumed) == '```python\nprint(1)\n```'
        assert {'finish': 'stop'} in resumed
        replay = await collect(await server.resume_chat_stream(sid, 0, USER))
        assert replay == received + resumed
        charge.assert_awaited_once()
        assert charge.await_args.kwargs['idempotency_key'] == 'reasoning-lease'
        assert charge.await_args.kwargs['prompt_tokens'] == 19
        assert charge.await_args.kwargs['completion_tokens'] == 8
        stream.close.assert_awaited_once()
    asyncio.run(scenario())


def test_sdk_broken_transport_closes_socket_and_preserves_partial_text_without_charge(monkeypatch):
    async def scenario():
        closed = asyncio.Event()

        class BrokenBody(httpx.AsyncByteStream):
            async def __aiter__(self):
                yield ('data: ' + json.dumps(sdk_chunk({'content': 'partial code'})) + '\n\n').encode()
                raise httpx.ReadError('fixture transport failure with private detail')

            async def aclose(self):
                closed.set()

        async def handle(request):
            return httpx.Response(200, headers={'content-type': 'text/event-stream'}, stream=BrokenBody())

        client = AsyncOpenAI(api_key='fixture-not-a-secret', base_url='https://router.huggingface.co/v1',
                             http_client=httpx.AsyncClient(transport=httpx.MockTransport(handle)), max_retries=0)
        _, charge = patch_chat(monkeypatch, None, SETTINGS)
        monkeypatch.setattr(server, 'openrouter_client', client)
        try:
            response = await server.chat_stream(server.ChatStreamRequest(
                messages=[{'role': 'user', 'content': 'hello'}]), USER)
            events = await collect(response)
            assert ''.join(e.get('t', '') for e in events) == 'partial code'
            assert any('error' in e for e in events)
            assert not any('finish' in e or 'usage' in e for e in events)
            assert 'private detail' not in json.dumps(events)
            assert closed.is_set()
            charge.assert_not_awaited()
            server.release_generation.assert_awaited_once_with(USER['_id'], 'reasoning-lease')
        finally:
            await client.close()
    asyncio.run(scenario())
