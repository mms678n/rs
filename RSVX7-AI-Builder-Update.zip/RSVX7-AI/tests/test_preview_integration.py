"""Writes only to the isolated local preview DB; never run on production."""
import os
import re
import secrets
from pathlib import Path

import pytest
import requests
from dotenv import dotenv_values
from pymongo import MongoClient

ROOT = Path(__file__).resolve().parent.parent


@pytest.mark.skipif(os.environ.get("RUN_PREVIEW_WRITES") != "1", reason="Preview-only write test is opt-in")
def test_preview_auth_and_workspace():
    env = dotenv_values(ROOT / "backend" / ".env")
    assert env.get("DB_NAME") == "rsvx7ai_preview", "This test must not run on a production database"
    assert env.get("MONGO_URL") == "mongodb://127.0.0.1:27017"
    base = "http://127.0.0.1:3000"
    database = MongoClient(env["MONGO_URL"])[env["DB_NAME"]]
    owner_file = (ROOT / "private" / "owner-credentials.md").read_text()
    username = re.search(r"- Username: `([^`]+)`", owner_file).group(1)
    password = re.search(r"- Password: `([^`]+)`", owner_file).group(1)
    owner = requests.Session()
    response = owner.post(base + "/api/auth/login", json={"username": username, "password": password}, timeout=10)
    assert response.status_code == 200
    cookie = response.headers.get("set-cookie", "").lower()
    assert "secure" in cookie and "httponly" in cookie and "samesite=none" in cookie
    owner.headers["Authorization"] = "Bearer " + response.json()["token"]
    assert owner.get(base + "/api/auth/me", timeout=10).json()["role"] == "super_admin"
    assert owner.get(base + "/api/admin/stats", timeout=10).status_code == 200
    users = []
    project_id = None
    try:
        project = owner.post(base + "/api/workspace/projects", json={"name": "Deployment smoke " + secrets.token_hex(4)}, timeout=10)
        assert project.status_code in (200, 201)
        project_id = project.json()["_id"]
        fetched = owner.get(base + "/api/workspace/projects/" + project_id, timeout=10)
        assert fetched.status_code == 200
        note = owner.post(base + f"/api/workspace/projects/{project_id}/notes", json={"content": "Preview persistence check"}, timeout=10)
        assert note.status_code in (200, 201)
        assert owner.get(base + f"/api/workspace/projects/{project_id}/notes", timeout=10).json()
        guest = requests.Session()
        guest_name = "smoke" + secrets.token_hex(6)
        registered = guest.post(base + "/api/auth/register", json={"username": guest_name, "password": secrets.token_urlsafe(18)}, timeout=10)
        assert registered.status_code == 200
        users.append(registered.json()["id"])
        guest.headers["Authorization"] = "Bearer " + registered.json()["token"]
        assert guest.get(base + "/api/auth/me", timeout=10).status_code == 200
        assert guest.get(base + "/api/admin/stats", timeout=10).status_code == 403
        assert guest.get(base + "/api/workspace/projects/" + project_id, timeout=10).status_code == 404
        logout = owner.post(base + "/api/auth/logout", timeout=10)
        assert logout.status_code == 200
        assert "samesite=none" in logout.headers.get("set-cookie", "").lower()
    finally:
        # Remove only IDs created by this test in the verified preview database.
        if project_id:
            database.notes.delete_many({"project_id": project_id})
            database.projects.delete_one({"_id": project_id})
        for uid in users:
            database.users.delete_one({"_id": uid})
            database.usage.delete_many({"user_id": uid})
