#!/usr/bin/env python3
"""Standalone HF migration for RSVX7-AI Glass UI v12. Run from the project root.

Requires Python 3.10+, Docker Compose, and the existing running app/Mongo.
Prompts for a hidden HF token and a model. A single <=64-output-token live
JSON/SSE/usage probe runs before any local changes. Provider charges may apply.
Backups include only the private env, changed source files and AI settings.
Does not change Caddy, certificates, users, subscriptions, wallets or projects.
--rollback BACKUP restores the previous AI settings, env, source and app image.
--fix-catalog repairs HF model discovery without changing provider settings.
"""
import argparse
import base64
from datetime import datetime, timezone
import getpass
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, Request, build_opener

HF_URL = 'https://router.huggingface.co/v1'
DEFAULT_MODEL = 'dphn/Dolphin-Mistral-24B-Venice-Edition:featherless-ai'
# Release-generated payload contains only the two reviewed Python source files.
PAYLOAD = 'ABzY8000000t4keYjfMym4D?{=?p-Jf+*Q>YG&D1vE_+2j_tMN?sg>&0+E*@Y7k%nP%`7yha`3EW@o39&--a7leOc<alNgZW`7C!Z}yyXAGj9)DLVFcJG05eCV=}m_q^_T-J5$Whe7uak9%uD=x037!}uukMw68`TiK_7cX)ct)72!7CTy7Wc*In*CgX88os4qcW8IYZc$|kpl(8W0u@Q7h`LD-3%UL&xW8TffBxYG0jIu$JXPy{*KMseZB+Xfp>7OarKQj*F=EbKVo5bBP(a(oL#xGvbkAol^MB!oaJPf+~aX(Fl2t&^A=Ep&rG5Phfc=d}Qm2G-K&hv1{RRi_hWccStNi2T>4)S0>E~d%z(Oo%4KgjZ66sjRMZ*Jd8#yL-$><S+NngMC=?e5;(y4&R=#E9&cz_+02h0DAFuQs>k_tB&m0Cu~o#k;WZ50Ds5b~WTtugP`@RXaJ%)W<jeaS(;Df+W>L43qdM@pzgh1rn}|M^V^?g}%=xTlhuc3+b91rNL-0@%lWCd9J!#rKcv_j%kYB1lVU^EhHG{1C77KCj0w;-1T?1F5lYPZL;n-O@T-JafbLn?g&%v1E&nbECXB=@3Jwx^@H9pRO1fDM@PVO{h$jy(&RYo@l?$dX1?*cDY(=h@;rd`2f#FJ(D&_^0R5G%>$}^#zw~e4x`s{OyXu>-a6y~f{>@uAegUs<u?}#k$K&HLO=9ne=kETB@p*rx$@W)}h$&Hff2H9?$q7&0#(sQd>+0t1YrFmjH?C}5s~hOX&8_RVZrtA8x+U5`Z<eGCzWn-x#~a>Tt6cy-ZNGiEzrw;kv*7B$#8J`>BKXFmjKgD`jI)$yJV?8PwE>`)XRGH|qbL{#tLMG-)eEh+U?hO--OZgXT7QSRi=a~N3c!%%+iPnH4ccB`zi|G-+VT2w;9=hkJ8N`#LAVA&LnAaAUYg};ID%Q$2uhG4|NX6Bo`E^pN`hEvd1Y(s=FZmE`=xfSgl<)=WSIqA2R&d=_2%ZS%@4K!f*k;GZ+|7{L*U&YAA=eruE>*-KN3HO!CgN`amn^q4)$Z1<m&ddE#N!s>pFKpoQ_7h(_~JM^HDEI@8It=JHGq&Y7jc+tfDJ)D?abX#6AAi?X7EaL}GdzL#jVN;_*>Fz&8j>HyMs1j%rAPg&#onP^x&(9|dUu0>e{!pYk9}Vh}QfL(mQ8&<f5SrMw^B?Euw~lq9>br>v^Y0x^&WM_FeNC5IKS4`8@%FbWRCD9l5i`Dc$E+JlKP_TvE$Kuj{|dG8dIbAKVf>}>BUo^J2Q4E~YbVMx@_tG76)Jrv~wi}Uv8jB=pohZg^|x*O&ZFZZ1T#dTmH!5~CSV)||rf~rI$6nlXSi}&yFNk{T<llDJ<oJJibp-tA~{a_sBz67Qt|89ykR{p{L3~=0`J<Qt`Pwx6g%WE~&#@$(`r;{|ydFMR+9wkXcuN(6QM*e~gDFuplS`88_DaTrhkY@hv>pNS!h^50{!BnU(eQ7t~QsG0fO}m2Er7ABh4o9!LBZk940QP=(1X9@Z1uhj|;J?t^uvq+VI2xd?mW&|gMdQJX`H5R>VL(UJ#BKvHujOu4ZAYunZ}oT`ppkZnmkolAw=OokUU&rS!L{M=fR%9?%Wc#ZCX5F}%z{4m4=-MjlfY<=h5>G|9{A#B!7=YCfU7#oA(iE{3*yLG6%j!9Ii}`w^hh)^ajK(M<_kN_X&B?>>7;FwUd~X1SFgv(o)A#)RmMHgh^40Vs~DS;t;Af@-e|I41ksq2#nNQA;}AR1Q==X#!EaSW6bM#aC%DD!2T_EkafkH198?&sw}F520XJ5v?OM=l5wI~B#C^bUJ_s{4Zj*%|)Z-o~JqG(54~B&ej6)yedVuXr?k6hPT%*83N{KEog%lzZECGO81vN3a$o`5fR<KYE;KQ3L&lI?WRwNu9g}!QIF|=$>=*dZ%ERk?sZF;=Poc;Zl1Aikl1|tmkU0ZHoay=lz8pf<f$_<EWzV4|J4(6y<`0o|e>Z@zhlHRmvzi>T*#^fL|(ic&Z6{fOkuXWrT>_*gMN;87bGGQQG$DEB}IN;~OIPWDV;IJhuP4a-8w{8#%yu+59jzJ^?$;qA=)6lbFPqJQHaw&>~<ky((iIz=vu4YLdH3LWwEFQ<1kr7YDT){~YYJbo>3UX95=ftEQt=(<dla_~XG$meruAH%~vzwB*%;6pw7>sIH%2PKAvW$@zwj-^Xcaz@4)xMd+HSJez#1){1+%*@BBWa6u&I_8$r;U~(I*_g(MqKQ6S)293ZoZeHe+PdYuzw+J=mFIRc%8gdW5Dwb0|?-(;}Bh~Hd1l%7)PA=PxStI$)^M>h6W^Cg&Ghxz*-z6J@E#aP_~zgaJvz>zl49nMuV;X6#q6vR%t;&N8tw;Tfr#Ef%jr)0Cw5l=ITEOs~@#iFC7#=eXqT?dT_7RT)%YbbQyEr8p!un58hm}MuQhhMH_lD<z9arMZ+NP4qOS9Tv}xV3PPBs*sff$fdny-0OT%;V6z~IWOQZw3d_db0s5qZalp`B&asliqDB*Tb9F?e57y|*Y7F+hCZVBeXd!cH@7S#AEXM+}Q)Y01i7HdpkpbJ)-A5THT<vRYl^zT~3iM3{-_Gs$PK>&26a_h`grPu-Q(g8w31b_S1t|)XdFf9wWa*b;PJw*KA!Q@`%Mb)=9l^+;>W83mPEBh=dQ-mX`?$(265>t*f<G+t<CXvxEs$&o`~&;P_%I5)#h4WBN`r1rKn232lVB^V7F^<FpxJ>DlOx=v**Jr?he<wQAAVTp3x4<^1^96KH0*-f72|#Qp`IRE2y31t$H0WRDSC{(4=$}3w-1nIjKVr(Mv2K`+a2eix$a16(<joqtIz>g1*Rb>FT^YAEud!?N8VKE&T!!w@;62#5w8*OQ(uh7L);@+79Pa`wH;xMB+lOf(1)-hWbFxn4qt{mz;%FxGYWem7Ugh;GR-`bDpF}{G=YxN;Z))F)ge=cA@&X|D-2eNsv+)jw`kgAZWN*&nU6=vVlaBc6d-GAHJ}cHRiM$-((<p``Vvqa=MXFtSA8JnH()D*X@Xfv60QdDrx?%}$C?l6XFv<<uS_i=Qe-JZBG;h5W7vpPgPIXJ^d%rw@?T(6lPmKL$lC%8^~rR8jTQO^T(XCLqq-QXK)SQi+8|R)I7&^WPb?oq=}{zU;i`#2)HjE?>YlWfv`^B}ovD+2K*Z^vF*Bo5gr`!>sbRG*3^UWO7Z&CR7}f>3g<S!JZb-Ia7=sXk<%ZHN?G4j20(Hi;LY!#6@GLUv_1NsFUMnIa52$wrk{n5XLS8`yp+i+{!PLnXWfT<@$H+0;%xYy%2c)oKz+m^Do1_2jxth#5;fKD6<oa5Fz-+|3rxlxD2H2ITyLvxE+f!S6#7(8GMQjlrX;=5aQB&%oAI3c&dbs!YSNyPtEWN*iA-GeE$wbhkHcFxSK~i(gpfKQ}2Ry`K@;G5TSKgO8ABT>4ev+hjjQo-01ItH73jkfm3a_6nSB+YwZE(yyrQKxJ@NZ)o6^<HwuF}SjM(eV=wYCCt6A=7Nz2|~e*anp)R(FEXuum)zN0BP6PB)ZdXGH{xIV<rOOV=v1R4~^yY1S@b^1dhXJ|GWWE_&F>AlDe6$&@?aP~8h72xw{oq#^(akPZTv4W#$eE+bQUMOC4%^w!Q84g>C(TT$n#fzTl>d%LlXa2(?vn)7Yup1CbF=p(jn>Zc-C;0VVVKbQ7{(^>#b1!jOTU!g7#OzhfNa()nc!$;R!E$RZRU7<b}VZ5eQE!uI`EE%WBZ*3K4ogaaf?g6DkoU_8Kva!q-;D+f`=1w`hPA9%hl@{wZ=l@YLKkb5x=2S9Whc_c<RKx4#1|p+&e&g+nKRH`=*UzuF-rlfhtj$T)30ZwRn*S&3mo}O;c3eq=w++>6G=GEb&_<{nB5gmzRN%6VF|DT}x*3?8=`qI4!09Fei!H|-tvd+fBhF61_W(76t{4Zb72^X!BJg0gsYoIZK&#?5XcSX;wH7AAUnpL)$#{e=YtIjI!kZ?%{iS4u78Zo|c_o0R?_0!dDlX||aJ#^gBdbn2qjG?EU>8RxFvH>pcEn?z%3va_F$5gu2|-DyA&bL`iVym*cPypSrPF9-CB(WA`JzU{qloWi5&TxM+KpC&N(3;YZAWh2VDDW8=U4z8(FTh#P?ikAL=tKjfKHKL4kzp?rywM#*~|liX63PZNq3AQ%|&sHa9IH<qXa{7SssGvEB3|=@ffCz;;~9#O->NoXf^_@b8WNX0*KT`XnlWWO>GbGBr@voLqq~V0P>KOFR%*m#9oUcu7Gm6JEB)*Pbxm6#!%CHU<Tyl%*UubO8JG>g?2R~C}J{J;fs5r)q>4t`e^o>*=Mu+vxn0^Ouu2%|DJt5ea>e0r%$Gjrcc@I<JsrT+~hq5U!KlBnSBC{W}h+Ye}DS@^!e<I*~jAXQ~2}#>^Gj%s7IMc;P|k~_yT&j)KE!hr|9x4kTtg<MF}+m8i9KUbMa$XNIJezwvVdQ?a80gdsmq+!Mub%k?=B;U%Qi$`nj3sX?O_cOeGUmM}W6l=P~CD`22qQhuIf^cElc_{mJwN{$kU|({HEG0J~o^MJD)4WD;0^3V(h+{n}&r1caIW4(V46^%ac#47%WdPrT(Ux-vKxwQWvVX4dJyv*}ZK{Sekei^I|Wb^1s`Q!x9&d4Z*#(3&5@;tQkkl|d-%?LmK;+-jwcNoeM#Vxel*wBVH5u=Fw_`Q_}PBKUv7BEFbDs~1xXNhO(mH2ZA&$LY6=#Fat6I?<MMdT5qn$guDv3|}t>JH&M{%u2Q+{lJ`$lq~cM;FT0#bYdIGd?KXVR3$w+zO2FvG7`O5j0kDKKl2pX??H^7u<7^k`L}{QzD3TM-3RXZ3|99Ae0Tugq1khGgOc%tb9i0w>6udVX!=Lw#5q79N#MU{HH0#`c_}j4DTIQFF-8GM?vjaAaWc)X(o$2A16UrGP2B~%MCEnO){1EHXq+SW2g=iEigGLLchFdlNV5lkmq%qZp-?iw)H5Iw;P5%1;L-FyQ2`>gp23S}(?4k?IDJ7n&lKJzzy}P!2KWK4Z-I6|QVl&a2>?(0LZYdFd^mkk0I5qRD}<r)H0^#{g!$Wv8T|i<&{X3hI?5o_{9^Bn9NHy3G)3*#;l-i1)mYMrL-<N_pXJCkez+%hhPNa=pP$!M9!l8O?6^k5bd#WkAB1*P!xuR_;1XHs?V9z@4ZDPBa||Xv7IX&`ur3_F)jl}*W(d3&W?f99O=Lw8N1rlhx3?`nNkwb5H&6)$FT-W3@t%HnU|@7^&{}n~sZ|%b#z`o2Z4K+*b998t0K%yYFgXXO$d&cqQ1@y~5P#k~ExEcsw`g2XR*kbNNvlQcxVMEm2-j$o5(M+9VL}62Llqj~uv-8fCcR0!T5{6Fq;2{Nz%CR0cl;1D4^9v|r=@K|gv-!VUnYvFwJ@&6v)fd54*lUrox1jCZkw0TpnamOb2P*(+q~r1cxb6VgO<M+d;g2s$ME87Hv44ySlI(l;oV=fZz*Fzggr#Rhc@aRKFQp@0^BA$Ck%CxVO<+Q<n-(~t_skqDkWWS&``dn3el(;-H*bNtHEe4sEnE$*=g8t>A`?O8kT-hQ)(EDMIMw0TUwVvSaWwRl9@E{*`e#AZ+*c<&D^T|qFr&;Wn4>5vL}CFao{~Hg)ET0C)P-yVWgC1$D9{TX_noe+H;^1D#rIl$;j0p8(xQj;=S_14~(>}MGQ|U2-lW~j+U4=*?N-|QNNBl&g8|(iK|XDdE>m>@WL#?!k8e((q`4=aMD4wvM1AiioU=bl#n+S0-h(ZWxZWUE~@L&S5nlZbA*<5e$4NJag^!I=4o9xFXa?utW#4`SE8aK_?oc8t^6218{66`E)5oxcaRZ9BA@b;4J+DGIT7`Lu47czK%3G65h!+HKg9CHWE|&z1FCR|9ZwWZUe?K$`ie=rOtD;_*wV#`<adh7-F9&T4m#-HuH%?R^aI|#BXiSM1=@nTL+LK8Uu1s=4gil;?HN41)oP(u3gU^Iq&>F_FWLF?bpA*@{*<k6TomO)x)^LJSI?P#2~_zOqaybK$s)?Kd2^eI&>UbM-9DrQdVlxPV})i!MGDt^32(l`Xw+BJKjSBISxbb{MSiBy0lv(LD#SH~Tq=nkn&eS+XhBaL3)SAG3TJ0J?2l3ZfE6}AA_olE^avyVCs_TMTZU|X9r|1}QTz=U`ggF*$J6gjY?WgnkCE9m4t`Lgpb4amqU6NK+(ioL$vUL2<|PnbHhW=(k?X?fb7TIc(~C`Yn5lEmL02P5!;dKKg8KShFv@{6vgH1>QJsf;`I`7X+AJ4Zu&Z2Xov#aIpTW}4fi{1(B7-u}q-dst`(MZy;OqgLJru#f7czAEIdS=RjEA$p=Vmu`e#B|a$Jm)6|I%@VQry25MWrBu>aEI;Foj*;LfAK$-*y^Q&Ak|xMk#9zAVHV3zdYPz+a4wN{YQ1@f{X>}#1S@JbV}2CdD@G>)noYkd5P#o6xmEZ7*))q@t$LV6N8r@!w&Qv#wv?Eg%MO$q04XK+Y3fHijP49{DsXv#hs1K9?Tvt<dlW^G-nMY#`#;8u5zIMhsoFM!K+JC!I*VPGzYU6&QgLU2b!NhTSipK5PuozS&|=Q2|Q+3oi(Q>x9YT=a%L4wlGl`1H8O_>ORe{%D7ZKcT1&y#oB*BA6ne~ZymlFesM}wwIXAI`FP(7H2Vbdua2$jY)t`459x5tP=ZxfB{WwO!@*EOZ`=D)VZb9G)oAt3eE9QVNSLDR%l4!<KPlD74(Q8NAm{{<+csq{ud&i=|f{G=ic7;R~8to{V6=35#NunN1GEt?WSq*0j(ZtXgT6!Rv*jZLU892hXCXVn~OqTLt5Q-!4h^kf%)e6)I(4ue{=1$GVj4NCOkhMx0#ecc!u~@7;yRKTsj}+U0EeqLGJMaam+GV0*HL@5UzR6!Tr@!%{fZn9qomQpblc`m_nLxT^K@MG(3sIa}{<^gpmYoKxWl=`4LpqNn4^4Mo5<wsjz4GR2<Bdzpq|-Oh<;FyuG*Zls`74nRekwQV>38toW2%!7Y1k*zzhIv46D+Y1sbDt!J=!;4q8}rMLy!E0wNuyEd29&JU)48=eq{@)@RgRV=WrT-ohp?Q^k)~Ty!0xpP<)bsz^xVj?^+J(#IYjtIh_+PJY*4;w}To@=6A}0c;i}|*Asfj#0og6Jtl+WG8TeLLl$`Y<mIc)PZsGLQ4lqPK0ZUkk@{Xx%Ws8x=7kK(vD})I5H)EK6ZJOMalEs!jv>pX5Wm!=2@8v4$^s+{qI5mMQ?k0hsf2LQRe3)B26z$+Jd_x{5+h(9dg*#*olE(FSrj91Sdzw<4;ofE@(f1S97tC`bzTb(E(mMap|Ndaj{@9v?Us#li(C)QT`tdV*IuU~uU*3>*4&&?*^`%A1Z4}%mPHx>+EOBbFmteQ_#)l#vb*`Kg!&zf^gHsZf$Xmo=YO42@V^q_f1Lno!%>j|ustu(4?xhC*_J|DJ*E}~;m|K?!QFA#qvG-=JJ)1+9{Hk5K2zcUjSH>PT>-L+g7wBJ*_M|#cUZ)OjOwMa@(PT)pgSPGbuxB1?tu;fn>tN0S+h;K!!FM<p6N5uJO6NvLe&AFAJ}9Rf<}P9fK9?Yn!JOh`RD`U;UKoVdyV1gG`xl`Qy16uJhmAtE*s$smL?~n0i9L`3g^i%#IpYh5nJA=aR^(_9Tu>dpBP2*H3y7=Q*tn+TmwrDm0Jzvu{q3EV0yx6gO8V5tqKR3$K>VxI%bi+Kxt1N(oxI+;*9y)xza6KQD4v)RIx?ZIC@my;}7^<cl~0099~I#5b862G)}Pz`hYd5W?Wkn73ULypRii)#|a%M+k+2+8ksy6fw{pbrvp3y{OKuW3#(0pw$?Q(r>6&}&B~N2$p}Byit$nXMmX$|5qobI_ei>uLLHN$r{#&HLL*nL`0^SQ8rDRDxAAE9DHcA0qWA`lli9za@mv&3f_A`~$j6p%f}Oy+zE8H#1C@9J|K^j~$MRX%u-a-wBdVkrQZByKss`1mZAQ!&FbrUq%YCB48FiF8HS&ad8zwi<75*X9sH;B&^Fc5wGGTr2ddH|n=zL2byx-A?4ME)mN8HGcrLeDuA90}13DTHu)4`27<o4}Q!v6$O0yP$Z|0F=dr5K(mRy`U;1;SZ1PFIT6s39dV)WUSHz7mmgwGSXuh#Gi1stnCP1(x^^wY9te4;J`n`u*&4Z*IMNvD=CD%nNxV=uHbky#~BsR9u#~&?mHO$3=<|ZSLO|wdJrqJ|j!~>$-~n!e%!z5yF?Z;^b;k6x2~<!g%e*a_f=jpyZP3UD<NIJvMj@68U)g7^M~qlAkdpqvg7J^nf2Cfhd_g{l2vJxeKsD919kZqBTZ=Cb5Qc_Q9yLzCZmFtOWUj800t711i`>Bx!ZjqZT&7GcDwq3rq5hEM_b-%@YFW^Gf_fdvk!JAHqB3Wk0Mv3}dX!2tG==cC8!4wBl(p^@c(x<jjycK;0Ui?_*Zc_eG^HIGbj3Jms|vwq(9r;*0b>Yz0qnZ4Y1_UzhYkh26C5-xv7#61e*L?6-Q!x&(DaD6O^xW`9M3Lj}*`C)kbvhQ6b^?iOI{vg(`S@Zoz`nY=|*#qHmb*9$bY1=qCh@5_@ErfVWX55p)j&mqcNhP%mVV%<?~-Jh%Tr81OZK<af9%$e@T)|JCXmr`5Iv7QW)U>L3*Z#c!KR4OD;>o2aWE0vzYZlW9M>xfBw9Ag}GatD1GbjB`vG<6TJvnJxr`WE2Q%_Z|vBi8149lbr;>HrrqYerKl`<k`&-no4x(<f$+U`wY<L}U$dU9pIH(Tf0q4ysC1*t)7KbrxOr1<&r!+U?S-#?PEm{Y$<5918o{w{DjboaQ&>sf8p}7gLl{g!2|OH_tVHe%VEjiD?{lLJGYR%<Yg@VxNyPj%Oq%X8r>n?GzENsd8#cWQ*pUm@>hvCWYz`5EZE@^Mg|kdzF*LMq8s2!@(mC&fN1kPWf~ZP<&7HIasQH<#>-dz(RD;*$Y)3DV#{BbZ95Du%X{N*40sTSh&OXN)#@}SdPYGlNEG!a7^c*bTEzz-g?D@#EI+R)%WQ4i=<94lE3lpX4sx^Sq38JfJ?8jKtjQz;1>|7N$u;hu+u^u>#eQCb;T`pqa*{e9dl9K*VNanHrn-f<CU-}dw~Pqs5|c@KVv9Ld>3Q<l(j@;P|c<wdV_7oc$0ntN(=9G!!3nQo~IPl2;zx-Hr!+SN?OcTrN;rTMU6%Gb!PH^z>w%mvhW;wakfca=|(ro;s3NjT$v{i2dN7_#S^NqFm^T0G_gvzjDwD#Lp)^y*Im1V!lExuN4BAJY3ibKc{_PQb^x-NR^QYGYJW^Z+4F@!Iusj0uekz4{SmJ>5fYX4^F@e~E=4bod^RvSP&@l!0En)Hge3C2gCy)~IjmefCAYjX^4p49rAWe@i{INsQo1|?Zx40Xo0{6I?5%bCkQa?pdr!P|7|XmfzO62A)wV-;BwT!-u9wWz4KT%3ZTf#M;!`Le_|Y~gE{nT0r~(yP*SJ+)U$*d$xaBX!3nrq7C3FQ~H;E!44z`o6P<!qi+Ik+|!H++R`|m2Kv@7-X)i-mxTi4nwaovA82vn0DuyIrio)Ph1>Ua)i0!ky*ClFpD<5V-Il`4pFJDQtFz#tts0;m52d7^{<t!4lK'
OLD_SETTINGS_SHA256 = '625081549eca69758c900d3e17ee1c2f206681e168d8ad4bf14d68e9b1db7ce8'
PREVIOUS_HF_SETTINGS_SHA256 = 'add40ce25f650d2a147b4cbba2d3808b1c374ecd2192b38860dc78447fcb2044'


class MigrationError(RuntimeError):
    pass


def decode_files():
    files = json.loads(gzip.decompress(base64.b85decode(PAYLOAD)).decode())
    expected = {'backend/ai_settings.py', 'backend/huggingface_provider.py'}
    if set(files) != expected:
        raise MigrationError('Invalid source payload')
    for name, content in files.items():
        compile(content, name, 'exec')
    return files


def check_sources(root, files):
    for name, content in files.items():
        target = root / name
        if target.is_symlink():
            raise MigrationError('Symlink source is not supported: ' + name)
        if not target.exists() and name == 'backend/huggingface_provider.py':
            continue
        if not target.is_file():
            raise MigrationError('Missing source: ' + name)
        digest = hashlib.sha256(target.read_bytes()).hexdigest()
        allowed = {hashlib.sha256(content.encode()).hexdigest()}
        if name == 'backend/ai_settings.py':
            allowed.add(OLD_SETTINGS_SHA256)
            allowed.add(PREVIOUS_HF_SETTINGS_SHA256)
        if digest not in allowed:
            raise MigrationError('Source version differs from the reviewed release; nothing changed: ' + name)


def rewrite_env(text, updates):
    result, seen = [], set()
    for line in text.splitlines():
        match = re.match(r'^(\s*(?:export\s+)?)([A-Za-z_][A-Za-z0-9_]*)\s*=', line)
        key = match.group(2) if match else None
        if key in updates:
            if key not in seen:
                result.append(match.group(1) + key + '=' + updates[key])
                seen.add(key)
        else:
            result.append(line)
    result.extend(key + '=' + value for key, value in updates.items() if key not in seen)
    return '\n'.join(result) + '\n'


def ensure_running_matches(config, container):
    """Do not restart the named project using another deployment's secrets/DB."""
    service = config['services']['app']
    configured = service.get('environment') or {}
    running = dict(item.split('=', 1) for item in container['Config']['Env'] if '=' in item)
    ignored = {'AI_PROVIDER', 'OPENROUTER_BASE_URL', 'OPENROUTER_API_KEY', 'OPENROUTER_MODEL', 'RSVX7_RELEASE_ID'}
    critical = {'MONGO_URL', 'DB_NAME', 'JWT_SECRET', 'RSVX7_JWT_SECRET', 'RSVX7_DATA_BACKEND',
                'FILE_STORAGE_BACKEND', 'OWNER_USERNAME', 'OWNER_INITIAL_PASSWORD', 'COOKIE_SECURE', 'CORS_ORIGINS'}
    keys = (set(configured) | critical) - ignored
    changed = [key for key in sorted(keys) if configured.get(key) != running.get(key)]
    if changed:
        raise MigrationError('Selected env differs from the running app; use its original private env file. Fields: ' + ', '.join(changed))
    expected = set()
    for mount in service.get('volumes') or []:
        kind, source = mount['type'], mount['source']
        if kind == 'volume':
            source = (config.get('volumes') or {}).get(source, {}).get('name', source)
        expected.add((kind, source, mount['target'], bool(mount.get('read_only'))))
    actual = {(mount['Type'], mount.get('Name') if mount['Type'] == 'volume' else mount['Source'],
               mount['Destination'], not mount.get('RW', True)) for mount in container.get('Mounts', [])}
    if expected != actual:
        raise MigrationError('App storage mounts differ from the running deployment; no configuration changed')


def atomic_write(path, data, mode=None):
    previous = path.stat() if path.exists() else None
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode if mode is not None else stat.S_IMODE(previous.st_mode) if previous else 0o644)
        if previous and os.geteuid() == 0:
            os.chown(temporary, previous.st_uid, previous.st_gid)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def validate_stream(stream):
    text, finish, usage, done, data = '', None, None, False, []
    started = time.monotonic()
    while time.monotonic() - started < 90:
        raw = stream.readline(65537)
        if len(raw) > 65536:
            raise MigrationError('Provider SSE frame too large')
        if not raw:
            break
        line = raw.decode('utf-8').rstrip('\r\n')
        if line.startswith('data:'):
            data.append(line[5:].lstrip())
            continue
        if line or not data:
            continue
        event, data = '\n'.join(data), []
        if event == '[DONE]':
            done = True
            break
        try:
            row = json.loads(event)
        except ValueError:
            raise MigrationError('HF_CHECK:stream:invalid_json_event; no configuration changed') from None
        if not isinstance(row, dict) or row.get('error'):
            raise MigrationError('Provider returned an SSE error')
        for choice in row.get('choices') or []:
            delta = choice.get('delta') or {}
            content = delta.get('content') or ''
            if finish and content:
                raise MigrationError('Provider sent content after completion')
            text += content
            finish = choice.get('finish_reason') or finish
        if isinstance(row.get('usage'), dict):
            usage = row['usage']
        if len(text) > 8192:
            raise MigrationError('Unexpected provider probe response')
    if not done:
        raise MigrationError('HF_CHECK:stream:missing_done; no configuration changed')
    if finish != 'stop':
        code = 'output_truncated' if finish == 'length' else 'unexpected_finish'
        raise MigrationError('HF_CHECK:stream:' + code + '; no configuration changed')
    try:
        parsed = json.loads(text)
    except ValueError:
        raise MigrationError('HF_CHECK:stream:invalid_json_output; no configuration changed') from None
    if parsed != {'ok': True}:
        raise MigrationError('HF_CHECK:stream:json_payload_mismatch; no configuration changed')
    if not usage or not all(isinstance(usage.get(k), int) and not isinstance(usage[k], bool) and usage[k] > 0 for k in ('prompt_tokens', 'completion_tokens')):
        raise MigrationError('Provider did not return token usage; no configuration changed')
    return {key: usage[key] for key in ('prompt_tokens', 'completion_tokens')}


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def live_probe(key, model, metadata_function):
    opener = build_opener(NoRedirect)
    headers = {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}
    def get(url):
        with opener.open(Request(url, headers=headers), timeout=25) as response:
            return json.load(response)
    stage = 'identity'
    try:
        identity = get('https://huggingface.co/api/whoami-v2')
        if not isinstance(identity, dict) or not isinstance(identity.get('name'), str):
            raise MigrationError('Hugging Face identity validation failed')
        print('HF_CHECK:identity:ok', flush=True)
        stage = 'catalog'
        record = get(HF_URL + '/models/' + model.partition(':')[0]).get('data')
        metadata = metadata_function(model, [record] if isinstance(record, dict) else record)
        print('HF_CHECK:catalog:ok', flush=True)
        body = {'model': model, 'messages': [{'role': 'user', 'content': 'Return exactly this JSON object, with no markdown and no other text: {"ok":true}'}],
                'stream': True, 'stream_options': {'include_usage': True}, 'max_tokens': 64, 'temperature': 0}
        if 'structured_outputs' in metadata['supported_parameters']:
            body['response_format'] = {'type': 'json_schema', 'json_schema': {'name': 'connection_probe', 'strict': True,
                'schema': {'type': 'object', 'properties': {'ok': {'type': 'boolean'}}, 'required': ['ok'], 'additionalProperties': False}}}
        stage = 'stream'
        with opener.open(Request(HF_URL + '/chat/completions', headers=headers, data=json.dumps(body).encode()), timeout=25) as response:
            if 'text/event-stream' not in response.headers.get('Content-Type', ''):
                raise MigrationError('Provider did not return an SSE stream')
            usage = validate_stream(response)
        print('HF live probe passed: JSON + SSE + usage (' + str(usage['prompt_tokens']) + '+' + str(usage['completion_tokens']) + ' tokens).', flush=True)
        return metadata
    except HTTPError as error:
        messages = {401: 'Invalid HF token', 403: 'HF permission/model access denied; check Inference Providers permission',
                    402: 'Insufficient Hugging Face inference credits', 404: 'Model or route unavailable', 429: 'Provider rate limited'}
        raise MigrationError('HF_CHECK:' + stage + ':http_' + str(error.code) + ' - ' + messages.get(error.code, 'Provider HTTP error') + '; no configuration changed') from None
    except (URLError, TimeoutError, ValueError, TypeError, KeyError) as error:
        allowed = {'invalid_model', 'invalid_catalog', 'model_unavailable', 'text_model_required', 'provider_unavailable'}
        if isinstance(error, json.JSONDecodeError):code = 'invalid_json_response'
        elif stage == 'catalog' and type(error) is ValueError and str(error) in allowed:code = str(error)
        elif isinstance(error, TimeoutError):code = 'connection_timeout'
        elif isinstance(error, URLError):code = 'connection_failed'
        else:code = 'invalid_provider_response'
        raise MigrationError('HF_CHECK:' + stage + ':' + code + '; no configuration changed') from None


DB_COMMON = '''import asyncio,json,sys
sys.path.insert(0,"/app/backend")
from bson import json_util
from auth import db
'''
DB_READ = DB_COMMON + '''async def main():
 print(json_util.dumps(await db.settings.find_one({"_id":"ai"})))
asyncio.run(main())
'''
DB_MIGRATE = DB_COMMON + '''from ai_settings import API_KEY,credential_cipher
from huggingface_provider import migration_fields
from datetime import datetime,timezone
async def main():
 metadata=json.load(sys.stdin)
 saved=await db.settings.find_one({"_id":"ai"}) or {}
 values=migration_fields(saved,metadata,credential_cipher().encrypt(API_KEY.encode()).decode(),datetime.now(timezone.utc).isoformat())
 query={"_id":"ai"}
 for name in ("model_revision","connection_revision"):
  query[name]=saved[name] if name in saved else {"$exists":False}
 result=await db.settings.update_one(query,{"$set":values},upsert=not bool(saved))
 assert result.matched_count or result.upserted_id,"Concurrent AI settings update"
 print("ok")
asyncio.run(main())
'''
DB_RESTORE = DB_COMMON + '''async def main():
 saved=json_util.loads(sys.stdin.read())
 if saved is None:await db.settings.delete_one({"_id":"ai"})
 else:
  assert saved.get("_id")=="ai"
  await db.settings.replace_one({"_id":"ai"},saved,upsert=True)
 print("ok")
asyncio.run(main())
'''
APP_VERIFY = '''import asyncio,json,sys,urllib.request
sys.path.insert(0,"/app/backend")
from ai_settings import API_KEY,BASE_URL,current_settings,configured_key,db
async def main():
 data=json.load(sys.stdin)
 assert BASE_URL=="https://router.huggingface.co/v1"
 assert configured_key(await db.settings.find_one({"_id":"ai"}))==API_KEY
 for profile in ("kaligpt","deepdark","rsvx7-ai"):
  assert (await current_settings(profile))["model"]==data["model"]
 with urllib.request.build_opener(urllib.request.ProxyHandler({})).open("http://127.0.0.1:3000/readyz",timeout=4) as r:
  assert json.load(r)["status"]=="ready"
 print("ok")
asyncio.run(main())
'''

CATALOG_PATCH_VERIFY = '''import hashlib,json,sys,urllib.request
from pathlib import Path
sys.path.insert(0,"/app/backend")
import ai_settings
data=json.load(sys.stdin)
assert ai_settings.is_huggingface(ai_settings.AI_PROVIDER,ai_settings.BASE_URL)
assert hashlib.sha256(Path(ai_settings.__file__).read_bytes()).hexdigest()==data["sha256"]
with urllib.request.build_opener(urllib.request.ProxyHandler({})).open("http://127.0.0.1:3000/readyz",timeout=4) as response:
 assert json.load(response)["status"]=="ready"
print("ok")
'''


class Deployment:
    def __init__(self, root, env_file, log=None, release=None):
        self.root, self.env_file, self.log = root, env_file, log
        self.env = dict(os.environ, RSVX7_SELFHOST_ENV=str(env_file))
        if release:
            self.env['RSVX7_RELEASE_ID'] = release
        self.compose = ['docker', 'compose', '-p', 'rsvx7', '--env-file', str(env_file), '-f', str(root / 'deploy/compose.selfhost.yaml')]

    def run(self, args, *, input=None, timeout=60, stage='Docker operation'):
        try:
            result = subprocess.run(args, input=input, cwd=self.root, env=self.env, capture_output=True, timeout=timeout)
        except (OSError, subprocess.SubprocessError):
            raise MigrationError(stage + ' failed; see private backup log') from None
        if result.returncode:
            if self.log:
                with self.log.open('ab') as stream:
                    stream.write((stage + '\n').encode() + result.stdout + result.stderr)
            raise MigrationError(stage + ' failed; see private backup log')
        return result.stdout

    def compose_run(self, *args, **kwargs):
        return self.run(self.compose + list(args), **kwargs)

    def job(self, code, input=None):
        return self.compose_run('run', '--rm', '--no-deps', '-T', 'app', 'python', '-c', code, input=input, timeout=90, stage='AI settings migration')

    def ready(self, model):
        for attempt in range(30):
            try:
                self.compose_run('exec', '-T', 'app', 'python', '-c', APP_VERIFY, input=json.dumps({'model': model}).encode(), timeout=10, stage='Application verification')
                return
            except MigrationError:
                if attempt == 29:
                    raise
                time.sleep(2)

    def ready_catalog_patch(self, digest):
        for attempt in range(30):
            try:
                self.compose_run('exec', '-T', 'app', 'python', '-c', CATALOG_PATCH_VERIFY,
                    input=json.dumps({'sha256': digest}).encode(), timeout=10, stage='Catalog repair verification')
                return
            except MigrationError:
                if attempt == 29:
                    raise
                time.sleep(2)


def restore(root, backup):
    state = json.loads((backup / 'state.json').read_text())
    if state['root'] != str(root):
        raise MigrationError('Run rollback from the same project directory')
    env_file = Path(state['env_file'])
    deployment = Deployment(root, env_file, backup / 'rollback.log', state.get('release'))
    deployment.run(['docker', 'image', 'inspect', state['backup_image']], stage='Backup image availability')
    deployment.compose_run('stop', 'app', timeout=90, stage='Stopping app for rollback')
    for name, existed in state['files'].items():
        target = env_file if name == 'env.private' else root / name
        saved = backup / name
        if existed:
            atomic_write(target, saved.read_bytes(), stat.S_IMODE(saved.stat().st_mode))
        elif target.exists():
            target.unlink()
    deployment.run(['docker', 'tag', state['backup_image'], state['image_tag']], stage='Restoring app image')
    if state.get('db_touched'):
        deployment.job(DB_RESTORE, (backup / 'ai-settings.json').read_bytes())
    deployment.compose_run('up', '-d', '--no-deps', '--force-recreate', 'app', timeout=120, stage='Starting previous app')
    print('Previous app, provider settings and private env restored. Backup: ' + str(backup), flush=True)


def repair_catalog(root, env_file, files):
    """Deploy only the HF lookup repair; never read or write the AI document."""
    deployment = Deployment(root, env_file)
    identifier = deployment.compose_run('ps', '--quiet', 'app').decode().strip()
    if not re.fullmatch(r'[a-f0-9]{12,64}', identifier):
        raise MigrationError('An existing running app is required')
    container = json.loads(deployment.run(['docker', 'inspect', identifier]))[0]
    if container['State']['Status'] != 'running':
        raise MigrationError('Existing app is not running')
    config = json.loads(deployment.compose_run('config', '--format', 'json', stage='Checking deployment identity'))
    ensure_running_matches(config, container)
    running_env = dict(item.split('=', 1) for item in container['Config']['Env'] if '=' in item)
    rendered_env = config['services']['app'].get('environment') or {}
    provider_fields = ('AI_PROVIDER', 'OPENROUTER_BASE_URL', 'OPENROUTER_API_KEY', 'OPENROUTER_MODEL')
    changed = [name for name in provider_fields if rendered_env.get(name) != running_env.get(name)]
    if changed:
        raise MigrationError('Repair env differs from the running provider; no configuration changed. Fields: ' + ', '.join(changed))
    if running_env.get('AI_PROVIDER') not in ('hf', 'huggingface') or running_env.get('OPENROUTER_BASE_URL', '').rstrip('/') != HF_URL:
        raise MigrationError('--fix-catalog requires the existing Hugging Face deployment')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    parent = root / '.rsvx7-backups'
    parent.mkdir(mode=0o700, exist_ok=True)
    os.chmod(parent, 0o700)
    backup = parent / ('hf-catalog-' + stamp)
    backup.mkdir(mode=0o700)
    deployment.log = backup / 'migration.log'
    deployment.env['RSVX7_RELEASE_ID'] = running_env.get('RSVX7_RELEASE_ID', 'local')
    name = 'backend/ai_settings.py'
    source = root / name
    saved = backup / name
    saved.parent.mkdir(mode=0o700, parents=True)
    shutil.copy2(source, saved)
    state = {'root': str(root), 'env_file': str(env_file), 'files': {name: True}, 'db_touched': False,
             'release': deployment.env['RSVX7_RELEASE_ID'], 'image_tag': container['Config']['Image'],
             'backup_image': 'rsvx7-hf-backup:' + stamp.lower()}
    try:
        deployment.run(['docker', 'tag', container['Image'], state['backup_image']], stage='Preserving app image')
    except MigrationError:
        print('Snapshotting the running app for rollback; it may pause temporarily...', flush=True)
        deployment.run(['docker', 'commit', identifier, state['backup_image']], timeout=180, stage='Snapshotting running app')
    deployment.run(['docker', 'image', 'inspect', state['backup_image']], stage='Verifying app backup')
    atomic_write(backup / 'state.json', json.dumps(state, indent=2).encode(), 0o600)
    print('Private backup: ' + str(backup), flush=True)
    try:
        atomic_write(source, files[name].encode())
        print('Building app with direct HF model lookup...', flush=True)
        deployment.compose_run('build', 'app', timeout=900, stage='Building catalog repair')
        deployment.compose_run('up', '-d', '--no-deps', '--force-recreate', 'app', timeout=120, stage='Starting repaired app')
        deployment.ready_catalog_patch(hashlib.sha256(files[name].encode()).hexdigest())
    except (Exception, KeyboardInterrupt):
        print('Repair failed; restoring the previous app...', flush=True)
        try:
            restore(root, backup)
        except (Exception, KeyboardInterrupt):
            print('Automatic rollback incomplete. Retry: python3 ' + str(Path(__file__).resolve()) + ' --rollback ' + str(backup), file=sys.stderr)
        raise
    print('HF_CATALOG_FIX:ready\nExisting model assignments and provider credentials preserved.', flush=True)
    print('Rollback: python3 ' + str(Path(__file__).resolve()) + ' --rollback ' + str(backup), flush=True)


def migrate(root, env_file, key, model, files):
    deployment = Deployment(root, env_file)
    identifier = deployment.compose_run('ps', '--quiet', 'app').decode().strip()
    if not re.fullmatch(r'[a-f0-9]{12,64}', identifier):
        raise MigrationError('An existing running app is required')
    container = json.loads(deployment.run(['docker', 'inspect', identifier]))[0]
    if container['State']['Status'] != 'running':
        raise MigrationError('Existing app is not running')
    config = json.loads(deployment.compose_run('config', '--format', 'json', stage='Checking deployment identity'))
    ensure_running_matches(config, container)
    running_env = dict(item.split('=', 1) for item in container['Config']['Env'] if '=' in item)
    if running_env.get('AI_PROVIDER') == 'local':
        raise MigrationError('This migration targets the existing hosted-provider deployment')
    if running_env.get('MONGO_URL', '').split('://', 1)[0] not in ('mongodb', 'mongodb+srv'):
        raise MigrationError('Unsupported database configuration')
    code = {}
    exec(compile(files['backend/huggingface_provider.py'], 'huggingface_provider.py', 'exec'), code)
    print('Checking HF identity, model, JSON, streaming and token usage...', flush=True)
    metadata = live_probe(key, model, code['model_metadata'])
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    parent = root / '.rsvx7-backups'
    parent.mkdir(mode=0o700, exist_ok=True)
    os.chmod(parent, 0o700)
    backup = parent / ('hf-' + stamp)
    backup.mkdir(mode=0o700)
    deployment.log = backup / 'migration.log'
    deployment.env['RSVX7_RELEASE_ID'] = running_env.get('RSVX7_RELEASE_ID', 'local')
    state = {'root': str(root), 'env_file': str(env_file), 'files': {}, 'db_touched': False,
             'release': deployment.env['RSVX7_RELEASE_ID'], 'image_tag': container['Config']['Image'],
             'backup_image': 'rsvx7-hf-backup:' + stamp.lower()}
    for name in ['env.private', *files]:
        source = env_file if name == 'env.private' else root / name
        state['files'][name] = source.exists()
        if source.exists():
            target = backup / name
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            shutil.copy2(source, target)
    snapshot = deployment.compose_run('exec', '-T', 'app', 'python', '-c', DB_READ, stage='Backing up AI settings')
    json.loads(snapshot)
    atomic_write(backup / 'ai-settings.json', snapshot, 0o600)
    # HF_RUNNING_SNAPSHOT: the original image reference can disappear while
    # its container keeps running. Snapshot that container, never a newer tag.
    try:
        deployment.run(['docker', 'tag', container['Image'], state['backup_image']], stage='Preserving app image')
    except MigrationError:
        print('Snapshotting the running app for rollback; it may pause temporarily...', flush=True)
        deployment.run(['docker', 'commit', identifier, state['backup_image']], timeout=180, stage='Snapshotting running app')
    deployment.run(['docker', 'image', 'inspect', state['backup_image']], stage='Verifying app backup')
    atomic_write(backup / 'state.json', json.dumps(state, indent=2).encode(), 0o600)
    print('Private backup: ' + str(backup), flush=True)
    try:
        for name, content in files.items():
            atomic_write(root / name, content.encode())
        updates = {'AI_PROVIDER': 'huggingface', 'OPENROUTER_BASE_URL': HF_URL,
                   'OPENROUTER_API_KEY': key, 'OPENROUTER_MODEL': model}
        atomic_write(env_file, rewrite_env(env_file.read_text(), updates).encode(), 0o600)
        print('Building app only; existing gateway and certificate volumes stay in use...', flush=True)
        deployment.compose_run('build', 'app', timeout=900, stage='Building HF app image')
        # Stop first so an owner edit cannot race the one-document migration.
        deployment.compose_run('stop', 'app', timeout=90, stage='Stopping app for provider switch')
        # A build can take minutes while the old app remains available. Capture
        # the latest owner settings after stopping, not the pre-build snapshot.
        snapshot = deployment.job(DB_READ)
        json.loads(snapshot)
        atomic_write(backup / 'ai-settings.json', snapshot, 0o600)
        state['db_touched'] = True
        atomic_write(backup / 'state.json', json.dumps(state, indent=2).encode(), 0o600)
        deployment.job(DB_MIGRATE, json.dumps(metadata).encode())
        deployment.compose_run('up', '-d', '--no-deps', '--force-recreate', 'app', timeout=120, stage='Starting HF app')
        deployment.ready(model)
    except (Exception, KeyboardInterrupt):
        print('Switch failed; restoring previous provider...', flush=True)
        try:
            restore(root, backup)
        except (Exception, KeyboardInterrupt):
            print('Automatic rollback incomplete. Retry: python3 ' + str(Path(__file__).resolve()) + ' --rollback ' + str(backup), file=sys.stderr)
        raise
    print('HF_SWITCH:ready\nProvider: Hugging Face\nModel: ' + model, flush=True)
    print('All three model profiles now use this model. You can assign different HF models in admin settings.', flush=True)
    print('Rollback: python3 ' + str(Path(__file__).resolve()) + ' --rollback ' + str(backup), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--env-file', default='.env.selfhost')
    parser.add_argument('--model')
    action = parser.add_mutually_exclusive_group()
    action.add_argument('--rollback')
    action.add_argument('--fix-catalog', action='store_true')
    args = parser.parse_args()
    root = Path.cwd().resolve()
    try:
        if not (root / 'deploy/compose.selfhost.yaml').is_file():
            raise MigrationError('Run from the RSVX7-AI project directory')
        if args.rollback:
            restore(root, Path(args.rollback).resolve())
            return 0
        overrides = [name for name in ('AI_PROVIDER', 'OPENROUTER_BASE_URL', 'OPENROUTER_API_KEY', 'OPENROUTER_MODEL') if name in os.environ]
        if overrides:
            raise MigrationError('Unset provider shell overrides first: ' + ', '.join(overrides))
        files = decode_files()
        check_sources(root, files)
        env_file = Path(args.env_file).resolve()
        if not env_file.is_file() or env_file.is_symlink():
            raise MigrationError('The existing private env file is required')
        if args.fix_catalog:
            repair_catalog(root, env_file, files)
            return 0
        model = args.model or input('HF model [' + DEFAULT_MODEL + ']: ').strip() or DEFAULT_MODEL
        # getpass opens /dev/tty. Refuse echo fallback in noninteractive shells.
        if not sys.stdin.isatty():
            raise MigrationError('Run interactively to enter the HF token safely')
        key = getpass.getpass('HF token (hidden): ').strip()
        if not re.fullmatch(r'hf_[A-Za-z0-9]{10,}', key):
            raise MigrationError('Expected a Hugging Face token starting with hf_')
        migrate(root, env_file, key, model, files)
        return 0
    except KeyboardInterrupt:
        print('Cancelled.', file=sys.stderr)
        return 130
    except Exception as error:
        # Never print arbitrary provider/SDK exception bodies or credentials.
        print(str(error) if isinstance(error, MigrationError) else 'Migration failed (' + type(error).__name__ + '); inspect the private backup log.', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
