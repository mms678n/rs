#!/usr/bin/env python3
"""Read-only deployment diagnosis. Output contains fixed codes, never terminal text."""
import json
from pathlib import Path
import subprocess
import sys
import urllib.request

INNER_PROBE = r'''
import asyncio,hashlib,hmac,json,os,sys,urllib.request
checks={}
checks['release']=os.environ.get('RSVX7_RELEASE_ID','')
def http(url):
 with urllib.request.urlopen(url,timeout=4) as response:
  return response.status,response.headers.get('Content-Type',''),response.read(131072)
try:
 status,_,body=http('http://127.0.0.1:3000/readyz')
 checks['database']='ready' if status==200 and json.loads(body).get('status')=='ready' else 'not_ready'
except Exception:checks['database']='not_ready'
try:
 status,kind,_=http('http://127.0.0.1:3000/')
 checks['frontend']='ready' if status==200 and 'text/html' in kind else 'not_ready'
except Exception:checks['frontend']='not_ready'
try:
 key=hmac.new(os.environ['RSVX7_JWT_SECRET'].encode(),b'rsvx7-builder-engine-v1',hashlib.sha256).hexdigest()
 request=urllib.request.Request('http://127.0.0.1:'+os.environ.get('BUILDER_ENGINE_PORT','3001')+'/health',headers={'Authorization':'Bearer '+key})
 with urllib.request.urlopen(request,timeout=4) as response:
  sys.path.insert(0,'/app/backend')
  import builder
  health=json.loads(response.read(4096))
  checks['engine']='ready' if response.status==200 and isinstance(health,dict) and health.get('status')=='ok' and health.get('protocol')==builder.ENGINE_PROTOCOL and health.get('mode')=='direct' else 'not_ready'
except Exception:checks['engine']='not_ready'
try:
 sys.path.insert(0,'/app/backend')
 from ai_settings import current_settings,BASE_URL,AI_PROVIDER
 async def settings():return await asyncio.wait_for(current_settings(),5)
 selected=asyncio.run(settings())
 if not selected['key_configured']:checks['model']='missing_key'
 elif AI_PROVIDER=='local':
  _,_,body=http(BASE_URL+'/models')
  installed=[item.get('id') for item in json.loads(body).get('data',[])]
  checks['model']='configured' if selected['model'] in installed else 'model_not_installed'
 else:checks['model']='configured'
except Exception:checks['model']='model_unavailable'
print(json.dumps(checks))
'''

CHECK_CODES = {
    'release': {'ready', 'not_ready', 'release_mismatch'},
    'database': {'ready', 'not_ready'},
    'frontend': {'ready', 'not_ready'},
    'engine': {'ready', 'not_ready'},
    'model': {'configured', 'missing_key', 'model_not_installed', 'model_unavailable'},
    'public': {'ready', 'public_url_unavailable'},
}


def public_ready(site, expected_release=None):
    """Check DB readiness and HTML, keeping certificate verification enabled."""
    from urllib.parse import urlsplit
    origin = urlsplit(site)
    try:
        for path in ('/readyz', '/'):
            with urllib.request.urlopen(site + path, timeout=8) as response:
                final = urlsplit(response.geturl())
                if origin.scheme != final.scheme or origin.netloc != final.netloc:
                    return False
                if response.status != 200:
                    return False
                if path == '/readyz':
                    data = json.loads(response.read(4096))
                    if data.get('status') != 'ready' or (expected_release and data.get('release') != expected_release):
                        return False
                elif 'text/html' not in response.headers.get('Content-Type', ''):
                    return False
        return True
    except Exception:
        return False


def diagnose(settings):
    env_file = Path(settings['envFile'])
    release = Path(settings['release'])
    raw = {}
    if env_file.is_file() and (release / 'deploy/compose.selfhost.yaml').is_file():
        command = ['docker', 'compose', '-p', 'rsvx7', '--env-file', str(env_file),
                   '-f', str(release / 'deploy/compose.selfhost.yaml'), 'exec', '-T', 'app', 'python', '-c', INNER_PROBE]
        try:
            # No build/up/restart, provider generation call or charge is performed.
            import os
            env = dict(os.environ, RSVX7_SELFHOST_ENV=str(env_file))
            result = subprocess.run(command, capture_output=True, text=True, timeout=35, env=env)
            if result.returncode == 0:
                raw = json.loads(result.stdout)
            if not isinstance(raw, dict):
                raw = {}
        except Exception:
            raw = {}
    expected = settings.get('expectedRelease')
    raw['release'] = 'ready' if expected and raw.get('release') == expected else 'release_mismatch'
    raw['public'] = 'ready' if public_ready(settings['siteUrl'], expected) else 'public_url_unavailable'
    checks = []
    for name, allowed in CHECK_CODES.items():
        code = raw.get(name)
        if not isinstance(code, str) or code not in allowed:
            code = 'model_unavailable' if name == 'model' else 'not_ready'
        checks.append({'id': name, 'status': 'passed' if code in ('ready', 'configured') else 'failed', 'code': code})
    return {'checks': checks, 'ready': all(c['status'] == 'passed' for c in checks if c['id'] != 'model')}


if __name__ == '__main__':
    try:
        print(json.dumps(diagnose(json.load(sys.stdin))))
    except Exception:
        # Configuration paths and raw process errors can contain private values.
        print(json.dumps({'error': 'diagnostic_unavailable'}))
        raise SystemExit(1)
