/** Real local processes/HTTP exercise the authoritative runtime; no provider or registry calls. */
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { createRequire } from 'node:module';
import * as fs from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { source } from './fixtures/agent-fixtures.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(join(root, 'frontend/package.json'));
const scratch = await fs.mkdtemp(join(tmpdir(), 'builder-real-runtime-'));
const project = join(scratch, 'project'), logs = join(scratch, 'logs');
await fs.mkdir(project); await fs.mkdir(logs);
const journal = [], children = new Set(), discoveries = new Set();
let runtime, adapter, success = false;
const controller = new AbortController();
const overallTimeout = setTimeout(() => { controller.abort(); runtime?.stop(); adapter?.killAll(); }, 100_000);
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

function localPath(name) {
  const path = resolve(project, name.replace(/^\/home\/project\//, ''));
  assert.ok(path === project || path.startsWith(project + sep), 'Sandbox paths stay inside fixture project');
  return path;
}
async function reservePort() {
  const server = createServer();
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  const { port } = server.address();
  await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
  return port;
}

async function localContainer() {
  const port = await reservePort(), listeners = new Map();
  const emit = (name, ...args) => { for (const listener of listeners.get(name) || []) listener(...args); };
  return {
    fs: {
      readFile: (name, encoding) => fs.readFile(localPath(name), encoding),
      writeFile: (name, value) => fs.writeFile(localPath(name), value),
      mkdir: (name, options) => fs.mkdir(localPath(name), options),
      readdir: name => fs.readdir(localPath(name)),
    },
    on(name, listener) {
      const group = listeners.get(name) || new Set(); listeners.set(name, group); group.add(listener);
      return () => group.delete(listener);
    },
    async spawn(shell, args, options = {}) {
      assert.equal(shell, 'jsh'); assert.equal(args[0], '-c');
      controller.signal.throwIfAborted();
      const command = args[1], number = journal.filter(item => item.command).length + 1;
      const entry = { command, number }; journal.push(entry);
      // No fixture dependencies exist. Offline npm also makes accidental registry use fail.
      const child = spawn('bash', ['-c', command], {
        cwd: project, detached: true, stdio: ['ignore', 'pipe', 'pipe'],
        env: { ...process.env, ...options.env, PORT: String(port),
          npm_config_offline: 'true', npm_config_update_notifier: 'false',
          npm_config_registry: 'http://127.0.0.1:9', npm_config_cache: join(scratch, 'npm-cache') },
      });
      children.add(child);
      let done = false, forcedKill, complete, outputController;
      let output = '';
      const exit = new Promise(resolve => { complete = resolve; });
      const stream = new ReadableStream({ start(value) { outputController = value; } });
      const append = chunk => { output += chunk; outputController.enqueue(chunk); };
      child.stdout.setEncoding('utf8'); child.stderr.setEncoding('utf8');
      child.stdout.on('data', append); child.stderr.on('data', append);
      child.once('error', error => { output += String(error); });
      child.once('close', async (code, signal) => {
        done = true; clearTimeout(forcedKill); children.delete(child);
        entry.code = code ?? 128; entry.signal = signal;
        outputController.close();
        try { await fs.writeFile(join(logs, `${number}.log`), command + '\n' + output); }
        finally { complete(entry.code); }
      });
      const kill = () => {
        if (done) return;
        try { process.kill(-child.pid, 'SIGTERM'); } catch (error) { if (error.code !== 'ESRCH') throw error; }
        forcedKill ||= setTimeout(() => { try { process.kill(-child.pid, 'SIGKILL'); } catch {} }, 1500);
        forcedKill.unref();
      };
      child.fixtureKill = kill;
      if (/^npm run ['"]?(?:dev|start|preview)(?:['"]|\s|$)/.test(command)) {
        const discovery = (async () => {
          for (let attempt = 0; attempt < 150 && !done && !controller.signal.aborted; attempt++) {
            try {
              const url = `http://127.0.0.1:${port}`;
              const response = await fetch(url, { signal: AbortSignal.timeout(300) });
              await response.text();
              if (response.ok && !done) { emit('server-ready', port, url); emit('port', port, 'open', url); return; }
            } catch {}
            await delay(40);
          }
        })();
        discoveries.add(discovery); discovery.finally(() => discoveries.delete(discovery));
      }
      return { output: stream, exit, kill };
    },
    killAll() { for (const child of children) child.fixtureKill(); },
  };
}

try {
  await require('esbuild').build({
    stdin: { contents: "export {ProjectRuntime} from './builder/vendor/darkforge/app/lib/runtime/project-runtime'; export {runProjectPipeline} from './builder/project-pipeline';", resolveDir: root },
    outfile: join(scratch, 'authoritative-runtime.mjs'), bundle: true, platform: 'node', format: 'esm', target: 'es2022',
    nodePaths: [join(root, 'frontend/node_modules')], alias: {'~': join(root, 'builder/vendor/darkforge/app')},
    define: {'import.meta.env': '{}'}, logLevel: 'silent',
  });
  const { ProjectRuntime, runProjectPipeline } = await import(pathToFileURL(join(scratch, 'authoritative-runtime.mjs')));
  const fixtureCalls = [];
  const generate = (files = {}, repair = false) => runProjectPipeline({
    files, signal: controller.signal, ...(repair ? {affectedFiles: ['client.js']} : {}),
    progress: event => journal.push({stage: event.stage, completed: event.completed, total: event.total}),
    async call(call) {
      fixtureCalls.push({ stage: call.stage, required: [...call.required] });
      const value = call.stage === 'structure' ? {files: repair ? ['client.js'] : Object.keys(source)}
        : call.stage === 'reviewing' ? {actions: [], remainingFiles: []}
        : {actions: call.required.map(filePath => ({type: 'file', filePath, content: source[filePath]})), remainingFiles: []};
      return {text: JSON.stringify(value), finishReason: 'stop'};
    },
  });
  const reviewed = await generate();
  assert.equal(journal.at(-1).stage, 'reviewing');
  assert.ok(journal.at(-1).total > 0 && journal.at(-1).completed === journal.at(-1).total);
  adapter = await localContainer();
  runtime = new ProjectRuntime(Promise.resolve(adapter), { command: 30_000, start: 12_000, boot: 5000 }, false,
    () => fs.readFile(join(root, 'frontend/public/internal/project-verifier.js'), 'utf8'));
  const mount = async (files, repair = false) => {
    runtime.stop(); runtime.beginTask(true, repair);
    for (const [path, file] of Object.entries(files)) {
      assert.equal(file.isBinary, false);
      const name = path.replace('/home/project/', '');
      await fs.mkdir(dirname(localPath(name)), {recursive: true});
      await fs.writeFile(localPath(name), file.content);
      runtime.fileWritten(name);
    }
    await runtime.verify();
  };
  await mount(reviewed.files);
  const ready = runtime.state.get();
  assert.equal(ready.phase, 'ready', JSON.stringify(ready));
  assert.equal(ready.checks.length, 7);
  assert.ok(ready.checks.every(check => check.status === 'passed'), JSON.stringify(ready.checks));
  const commands = journal.filter(event => event.command).map(event => event.command);
  assert.deepEqual(commands.slice(0, 6), ['npm install --no-audit --no-fund', 'node .darkforge/verify.cjs syntax',
    'node .darkforge/verify.cjs quality', "npm run 'test'", 'npm run build', "npm run 'dev'"]);
  const firstCommand = journal.findIndex(event => event.command);
  assert.equal(journal[firstCommand - 1].stage, 'reviewing');
  assert.equal(journal[firstCommand - 1].completed, journal[firstCommand - 1].total);
  assert.match(await (await fetch(ready.previewUrl, {signal: AbortSignal.timeout(2000)})).text(), /<h1>العناصر<\/h1>/);
  console.log('PASS reviewed fixture runs real npm installation, four checks and HTTP preview (7/7 checks)');

  const broken = structuredClone(reviewed.files);
  broken['/home/project/client.js'].content = 'const brokenClient = ;\n';
  await mount(broken);
  const request = runtime.repairRequest.get();
  assert.equal(runtime.state.get().phase, 'repairing');
  assert.equal(request.step, 'types');
  assert.equal(request.automatic, true);
  assert.match(request.diagnostic, /client\.js/);
  assert.ok(request.affectedFiles.includes('/home/project/client.js'));
  assert.match(request.prompt, /client\.js/);
  assert.equal(await fs.readFile(join(project, 'package.json'), 'utf8'), source['package.json']);
  console.log('PASS actual source syntax failure emits structured repair context with the broken path');

  const repaired = await generate(broken, true);
  assert.equal(repaired.files['/home/project/package.json'].content, source['package.json']);
  assert.equal(repaired.files['/home/project/server.mjs'].content, source['server.mjs']);
  assert.ok(fixtureCalls.some(call => call.stage === 'writing' && call.required.includes('client.js')));
  await mount(repaired.files, true);
  assert.equal(runtime.state.get().phase, 'ready', JSON.stringify(runtime.state.get()));
  assert.ok(runtime.state.get().checks.every(check => check.status === 'passed'));
  assert.equal(journal.filter(item => item.command?.startsWith('npm install')).length, 1, 'Unchanged dependencies are reused during repair');
  console.log('PASS deterministic same-framework source repair reruns real checks and restores HTTP preview');
  // npm workspaces put dependencies in nested manifests; root files stay unchanged.
  const workspace = structuredClone(repaired.files);
  workspace['/home/project/package.json'].content = JSON.stringify({ ...JSON.parse(source['package.json']), workspaces: ['packages/*'] });
  workspace['/home/project/packages/widget/package.json'] = {content: JSON.stringify({name:'fixture-widget',version:'1.0.0'}),isBinary:false};
  await mount(workspace);
  assert.equal(runtime.state.get().phase, 'ready', JSON.stringify(runtime.state.get()));
  const installedBeforeWorkspaceChange = journal.filter(item => item.command?.startsWith('npm install')).length;
  workspace['/home/project/packages/widget/package.json'].content = JSON.stringify({name:'fixture-widget',version:'2.0.0'});
  await mount(workspace, true);
  assert.equal(runtime.state.get().phase, 'ready', JSON.stringify(runtime.state.get()));
  assert.equal(journal.filter(item => item.command?.startsWith('npm install')).length, installedBeforeWorkspaceChange + 1,
    'Changing a workspace manifest must reinstall despite unchanged root manifest and existing node_modules');
  const workspaceLock = JSON.parse(await fs.readFile(join(project,'package-lock.json'),'utf8'));
  assert.equal(workspaceLock.packages['packages/widget'].version, '2.0.0');
  console.log('PASS nested workspace manifest change reruns real offline npm install and updates its lock entry');
  console.log('HTTP-only verification: browser rendering and paid inference were not exercised.');
  success = true;
} finally {
  clearTimeout(overallTimeout); controller.abort(); runtime?.stop(); adapter?.killAll();
  await Promise.allSettled([...children].map(child => new Promise(resolve => child.once('close', resolve))));
  await Promise.allSettled([...discoveries]);
  if (success) await fs.rm(scratch, {recursive: true, force: true});
  else console.error('Local process diagnostics:', logs);
}
