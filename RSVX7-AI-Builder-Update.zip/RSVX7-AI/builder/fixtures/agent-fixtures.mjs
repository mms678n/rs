export const criteria = ['إضافة عنصر صالح وحفظه', 'رفض الإدخال غير الصالح', 'تحميل العناصر بعد إعادة التشغيل'];
export const architecture = {
  summary: 'قائمة عناصر بواجهة عربية وخادم وتخزين فعلي',
  stack: ['Node.js HTTP', 'HTML/CSS/JavaScript', 'Node test runner'],
  modules: [
    {
      name: 'foundation',
      purpose: 'Server, data and entry point',
      files: ['package.json', 'server.mjs', 'index.html'],
    },
    { name: 'interface', purpose: 'Responsive form and API client', files: ['client.js', 'style.css'] },
    { name: 'tests', purpose: 'HTTP behavior and durable storage tests', files: ['server.test.mjs'] },
  ],
  data: { mode: 'server', entities: ['item: id,title'], storage: 'Server JSON file in an application data directory' },
  journeys: ['Add an item', 'Reload saved items'],
  acceptanceChecks: criteria,
  testStrategy: 'Real HTTP requests and application restart against a temporary storage file',
  blockers: [],
};
export const design = {
  direction: 'Arabic application with a focused list and accessible form',
  palette: { background: '#080E18', surface: '#142237', text: '#D8F3FF', accent: '#00BFFF' },
  typography: 'System Arabic font, readable labels',
  screens: [{ name: 'Items', layout: 'Form above list', interactions: 'Submit, show errors, reload saved items' }],
  responsive: 'Fluid width with phone padding',
  accessibility: 'Labeled input and live status',
  components: ['Item form', 'Item list', 'Status'],
};
export const review = {
  verdict: 'pass',
  issues: [],
  coverage: criteria.map((requirement) => ({
    requirement,
    files: ['server.mjs', 'server.test.mjs'],
    status: 'covered',
  })),
};
export const source = {
  'package.json': JSON.stringify({
    name: 'agent-fixture-app',
    type: 'module',
    scripts: { dev: 'node server.mjs', build: 'node --check server.mjs', test: 'node --test server.test.mjs' },
  }),
  'server.mjs': `import { createServer } from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = dirname(fileURLToPath(import.meta.url));
export function createApp(file = join(root, '.data/items.json')) {
 return createServer(async (req,res) => {
  const reply=(status,value,type='application/json')=>{res.writeHead(status,{'content-type':type});res.end(type==='application/json'?JSON.stringify(value):value);};
  try {
   let items=[];try{items=JSON.parse(await readFile(file,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
   if(req.url==='/api/items'&&req.method==='GET')return reply(200,items);
   if(req.url==='/api/items'&&req.method==='POST'){
    let text='';for await(const chunk of req){text+=chunk;if(text.length>4096)return reply(413,{error:'Too large'});}
    let input;try{input=JSON.parse(text);}catch{return reply(400,{error:'Invalid JSON'});}
    if(typeof input?.title!=='string'||!input.title.trim()||input.title.trim().length>100)return reply(400,{error:'Invalid title'});
    const item={id:crypto.randomUUID(),title:input.title.trim()};items.push(item);await mkdir(dirname(file),{recursive:true});await writeFile(file,JSON.stringify(items));return reply(201,item);
   }
   const asset={'/':'index.html','/client.js':'client.js','/style.css':'style.css'}[req.url];
   if(asset&&req.method==='GET')return reply(200,await readFile(join(root,asset),'utf8'),asset.endsWith('.js')?'text/javascript':asset.endsWith('.css')?'text/css':'text/html');
   reply(404,{error:'Not found'});
  }catch{reply(500,{error:'Request failed'});}
 });
}
if(process.argv[1]===fileURLToPath(import.meta.url))createApp().listen(Number(process.env.PORT||4173),'0.0.0.0');
`,
  'index.html':
    '<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>العناصر</title><link rel="stylesheet" href="/style.css"><main><h1>العناصر</h1><form><label for="title">عنوان العنصر</label><input id="title" name="title" required maxlength="100"><button>إضافة</button></form><p role="status"></p><ul></ul></main><script type="module" src="/client.js"></script></html>',
  'client.js': `const form=document.querySelector('form'),status=document.querySelector('[role=status]'),list=document.querySelector('ul');
async function load(){const response=await fetch('/api/items');if(!response.ok)throw new Error('تعذّر تحميل العناصر');const items=await response.json();list.replaceChildren(...items.map(item=>{const row=document.createElement('li');row.textContent=item.title;return row;}));}
form.addEventListener('submit',async event=>{event.preventDefault();const button=form.querySelector('button');button.disabled=true;status.textContent='جارٍ الحفظ…';try{const response=await fetch('/api/items',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({title:form.elements.namedItem('title').value})});if(!response.ok)throw new Error('تعذّر حفظ العنصر');form.reset();await load();status.textContent='تم الحفظ';}catch(error){status.textContent=error.message;}finally{button.disabled=false;}});
load().catch(error=>status.textContent=error.message);`,
  'style.css':
    'body{margin:0;background:#080E18;color:#D8F3FF;font:18px system-ui}main{max-width:800px;margin:auto;padding:24px}form{display:grid;gap:12px;background:#142237;padding:20px;border-radius:14px}input,button{font:inherit;padding:12px;min-width:0}button{background:#00BFFF;color:#080E18;border:0;border-radius:8px}li{overflow-wrap:anywhere}button:disabled{opacity:.6}',
  'server.test.mjs': `import { test } from 'node:test';import assert from 'node:assert/strict';import { mkdtemp,rm } from 'node:fs/promises';import { tmpdir } from 'node:os';import { join } from 'node:path';import { createApp } from './server.mjs';
test('real HTTP validation and persistence across restart',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'agent-app-')),file=join(dir,'items.json');let server;
 const start=async()=>{server=createApp(file);await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));return 'http://127.0.0.1:'+server.address().port;};
 const stop=()=>new Promise(resolve=>server.close(resolve));
 try{let base=await start();let response=await fetch(base+'/api/items',{method:'POST',body:JSON.stringify({title:'  '})});assert.equal(response.status,400);assert.deepEqual(await(await fetch(base+'/api/items')).json(),[]);
 response=await fetch(base+'/api/items',{method:'POST',body:JSON.stringify({title:'Saved item'})});assert.equal(response.status,201);assert.equal((await response.json()).title,'Saved item');
 await stop();base=await start();const items=await(await fetch(base+'/api/items')).json();assert.equal(items.length,1);assert.equal(items[0].title,'Saved item');
 assert.equal((await fetch(base+'/missing')).status,404);
 }finally{if(server.listening)await stop();await rm(dir,{recursive:true,force:true});}
});`,
};
export function artifact(files) {
  return (
    '<boltArtifact id="fixture" title="Project">' +
    Object.entries(files)
      .map(([path, content]) => '<boltAction type="file" filePath="' + path + '">\n' + content + '\n</boltAction>')
      .join('\n') +
    '</boltArtifact>'
  );
}
export function batchArtifact(batch) {
  return artifact(Object.fromEntries(batch.files.map((path) => [path, source[path]])));
}
