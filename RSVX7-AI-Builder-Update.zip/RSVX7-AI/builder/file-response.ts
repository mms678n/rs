import { jobFilePath } from './vendor/darkforge/app/lib/common/background-jobs';

const record = (value: unknown): value is Record<string, any> => !!value && typeof value === 'object' && !Array.isArray(value);
const invalid = (detail = '') => new Error((detail ? detail + ' ' : '') + 'Return one complete file-actions JSON object with string source content.');
const sourcePath = (value: string) => {
  const path = jobFilePath(value);
  if (path.split('/').some(part => ['.darkforge', 'dist', 'build'].includes(part))) throw new Error('Write editable source files outside reserved build and platform directories.');
  return path;
};

function readJSON(text: string): any {
  try {
    let value = JSON.parse(text);
    // Some compatible providers wrap the entire JSON document in a JSON string.
    if (typeof value === 'string') value = JSON.parse(value);
    return value;
  } catch { throw invalid(); }
}

function completeObject(text: string, start: number): number {
  const stack: string[] = [];
  let quoted = false, escaped = false;
  for (let i = start; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (escaped) escaped = false;
      else if (c === '\\') escaped = true;
      else if (c === '"') quoted = false;
    } else if (c === '"') quoted = true;
    else if (c === '{' || c === '[') stack.push(c);
    else if (c === '}' || c === ']') {
      if (stack.pop() !== (c === '}' ? '{' : '[')) throw invalid();
      if (!stack.length) return i + 1;
    }
  }
  throw invalid();
}

function document(text: string): any {
  const clean = text.trim().replace(/^\uFEFF/, '').replace(/^<(think|analysis|reasoning)>[\s\S]*?<\/\1>\s*/i, '');
  try { return readJSON(clean); } catch { /* A prose prefix or outer fence is optional. */ }
  // Extract only whole, line-aligned JSON documents. Never repair source bytes,
  // splice multiple documents, or promote a nested object from a truncated one.
  const candidates: any[] = [];
  const starts = /(?:^|\n)[\t ]*([\[{])/g;
  let match: RegExpExecArray | null;
  while ((match = starts.exec(clean))) {
    const start = match.index + match[0].lastIndexOf(match[1]);
    const end = completeObject(clean, start);
    candidates.push(readJSON(clean.slice(start, end)));
    starts.lastIndex = end;
  }
  if (candidates.length !== 1) throw invalid();
  return candidates[0];
}

/** Normalize equivalent provider field names without editing generated source. */
export function parseResponseDocument(raw: string): any { return document(raw); }

export function normalizeFileResponse(raw: string, options: { allowEmpty?: boolean } = {}): { text: string; remaining: string[] } {
  if (raw.trimStart().startsWith('<boltArtifact') || raw.trimStart().startsWith('<boltAction')) return { text: raw, remaining: [] };
  let value = document(raw);
  if (record(value) && record(value.artifact)) value = value.artifact;
  const next = record(value) ? value.remainingFiles ?? value.remaining_files ?? [] : [];
  if (!Array.isArray(next) || next.length > 200 || next.some(path => typeof path !== 'string')) throw invalid('remainingFiles must be an array of at most 200 path strings.');
  const remaining = [...new Set(next.map(sourcePath))];
  let actions: any[];
  if (Array.isArray(value)) actions = value;
  else if (record(value) && Array.isArray(value.actions)) actions = value.actions;
  else if (record(value) && Array.isArray(value.files)) actions = value.files;
  else if (record(value) && record(value.files)) actions = Object.entries(value.files).map(([path, file]) => typeof file === 'string' ? { path, content: file } : record(file) ? { ...file, path } : null);
  else throw invalid('Missing actions array or files map.');
  if ((!actions.length && !options.allowEmpty) || actions.length > 200) throw invalid('actions must contain complete files.');
  const normalized = actions.map((action, index) => {
    const field = `actions[${index}]`;
    if (!record(action)) throw invalid(field + ' must be a file object.');
    if (action.isBinary) throw invalid(field + '.isBinary is unsupported for generated source. Preserve existing binary assets; return complete UTF-8 source files.');
    if (action.type !== undefined && action.type !== 'file') throw invalid(field + '.type must be file; executable shell actions are not accepted.');
    const paths = [action.filePath, action.file_path, action.path, action.filename].filter(path => path !== undefined);
    if (!paths.length || paths.some(path => typeof path !== 'string')) throw invalid(field + '.filePath must be a path string.');
    if (new Set(paths.map(sourcePath)).size !== 1) throw invalid(field + ' contains conflicting path aliases.');
    if (typeof action.content !== 'string') throw invalid(field + '.content must be a string containing the complete source, not null or an object.');
    return { type: 'file', filePath: sourcePath(paths[0]), content: action.content };
  });
  return { text: JSON.stringify({ actions: normalized, remainingFiles: remaining }), remaining };
}
