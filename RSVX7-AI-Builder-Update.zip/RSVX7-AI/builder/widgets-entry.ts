export { BuildProgress } from './vendor/darkforge/app/components/chat/BuildProgress';
