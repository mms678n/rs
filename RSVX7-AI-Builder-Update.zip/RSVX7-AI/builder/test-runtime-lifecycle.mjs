import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const require = createRequire(new URL('../frontend/package.json', import.meta.url));
const folder = await mkdtemp(join(tmpdir(), 'runtime-lifecycle-'));
let failures = 0;
const test = async (name, run) => {
  try { await run(); console.log('PASS', name); }
  catch (error) { failures++; console.error('FAIL', name, error.message); }
};
try {
  const root = resolve(new URL('..', import.meta.url).pathname);
  await require('esbuild').build({
    stdin: { contents: "export {ProjectRuntime} from './builder/vendor/darkforge/app/lib/runtime/project-runtime'; export {projectCheckPlan} from './builder/vendor/darkforge/app/lib/runtime/project-checks';", resolveDir: root },
    bundle: true, platform: 'node', format: 'esm', target: 'es2022', outfile: join(folder, 'runtime.mjs'),
    nodePaths: [join(root, 'frontend/node_modules')],
  });
  const { ProjectRuntime, projectCheckPlan } = await import(pathToFileURL(join(folder, 'runtime.mjs')));
  await test('external command cancellation interrupts container boot immediately', async () => {
    const session = new ProjectRuntime(new Promise(() => {}), {boot:500,command:500,start:500}, false);
    const controller = new AbortController();
    const started = Date.now();
    const pending = session.execute('node -e 0', controller.signal);
    controller.abort();
    await assert.rejects(pending, error => error.name === 'AbortError');
    assert.ok(Date.now() - started < 250, 'External abort must not wait for boot timeout');
    session.stop();
  });
  await test('external command cancellation does not wait for a killed process to exit', async () => {
    let kills = 0;
    const process = {output: new ReadableStream({start(controller){controller.close();}}),exit:new Promise(()=>{}),kill(){kills++;}};
    const session = new ProjectRuntime(Promise.resolve({spawn:async()=>process}), {boot:500,command:500,start:500}, false);
    const controller = new AbortController();
    const started = Date.now();
    const pending = session.execute('node -e 0', controller.signal);
    setTimeout(()=>controller.abort(), 20);
    await assert.rejects(pending, error => error.name === 'AbortError');
    assert.ok(Date.now() - started < 250, 'External abort must not wait for command timeout');
    assert.ok(kills > 0);
    session.stop();
  });
  await test('stale workspace lockfiles use npm install instead of failing npm ci', async () => {
    const pkg = {scripts:{dev:'node server.mjs'},workspaces:['packages/*']};
    const lock = {packages:{'':{workspaces:['packages/*']},'packages/widget':{name:'fixture-widget',version:'1.0.0'}}};
    const plan = projectCheckPlan(JSON.stringify(pkg), false, {lockfile:JSON.stringify(lock),
      manifests:{'packages/widget/package.json':JSON.stringify({name:'fixture-widget',version:'2.0.0'})}});
    assert.equal(plan.install, 'npm install --no-audit --no-fund');
    delete lock.packages[''].workspaces;
    assert.equal(projectCheckPlan(JSON.stringify(pkg),false,{lockfile:JSON.stringify(lock)}).install, 'npm install --no-audit --no-fund');
  });
  await test('a stalled verifier download times out without requesting a source repair', async () => {
    const container = {fs:{readFile:async name=>{if(name==='index.html')return '<h1>Fixture</h1>';throw Error('ENOENT');}}};
    const session = new ProjectRuntime(Promise.resolve(container), {boot:30,command:500,start:500}, false, ()=>new Promise(()=>{}));
    session.beginTask(true);session.fileWritten('index.html');
    const pending = session.verify();
    await Promise.race([pending,new Promise(resolve=>setTimeout(resolve,150))]);
    const state = session.state.get(), request = session.repairRequest.get();
    session.stop();
    assert.equal(state.phase,'failed','Verifier download must have a finite deadline');
    assert.equal(state.failureKind,'environment');
    assert.equal(request,undefined);
  });
  const runtime = () => new ProjectRuntime(Promise.resolve({}), undefined, false);
  const fail = async (session, diagnostic) => {
    session.fileWritten('src/App.jsx');
    session.recordActionFailure(new Error(diagnostic));
    await session.verify();
  };
  await test('reopening a project at its automatic repair cap cannot restart the repair loop', async () => {
    const session = runtime();
    session.restoreRepairState({ automaticAttempts: 2 });
    session.beginTask(true);
    await fail(session, 'SyntaxError: src/App.jsx:7 Unexpected token');
    assert.equal(session.state.get().phase, 'failed');
    assert.equal(session.state.get().attempt, 2);
    assert.equal(session.repairRequest.get(), undefined);
    session.stop();
  });
  await test('restored attempt one permits only one more automatic repair across file application', async () => {
    const session = runtime();
    session.restoreRepairState({ automaticAttempts: 1 });
    session.beginTask(true);
    await fail(session, 'SyntaxError: src/App.jsx:7 Unexpected token');
    assert.equal(session.repairRequest.get().attempt, 2);
    session.beginTask(true, true);
    await fail(session, 'ReferenceError: src/App.jsx:12 missingName is not defined');
    assert.equal(session.state.get().phase, 'failed');
    assert.equal(session.repairRequest.get(), undefined);
    session.stop();
  });
  await test('repair handoff carries observed diagnostics and affected source; manual retry is explicit', async () => {
    const session = runtime();
    session.beginTask(true);
    await fail(session, 'SyntaxError: src/App.jsx:7 Unexpected token');
    const automatic = session.repairRequest.get();
    assert.equal(automatic.step, 'files');
    assert.equal(automatic.diagnostic, 'SyntaxError: src/App.jsx:7 Unexpected token');
    assert.equal(automatic.automatic, true);
    assert.deepEqual(automatic.affectedFiles, ['/home/project/src/App.jsx']);
    session.pause('Repair submission rejected');
    assert.equal(session.state.get().phase, 'failed');
    assert.equal(session.state.get().requestFailed, true);
    session.requestRepair();
    assert.equal(session.repairRequest.get().automatic, false);
    session.stop();
  });
  await test('network and browser environment failures never become model repair requests', async () => {
    for (const diagnostic of ['getaddrinfo ENOTFOUND registry.npmjs.org', 'connect ETIMEDOUT registry.npmjs.org:443', 'SharedArrayBuffer is unavailable in this WebContainer']) {
      const session = runtime();
      session.beginTask(true);
      await fail(session, diagnostic);
      assert.equal(session.state.get().phase, 'failed');
      assert.equal(session.repairRequest.get(), undefined);
      assert.equal(session.canRequestRepair, false);
      session.stop();
    }
  });
} finally { await rm(folder, { recursive: true, force: true }); }
if (failures) process.exitCode = 1;
