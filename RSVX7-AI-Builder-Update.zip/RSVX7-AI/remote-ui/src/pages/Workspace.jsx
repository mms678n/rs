import { useEffect, useRef, useState } from "react";
import { useOutletContext, Link } from "react-router-dom";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "../components/ui/dropdown-menu";
import {
  Server, Laptop, Monitor, Cpu, Database, Cloud, Smartphone, HardDrive,
  Circle, ChevronDown, Terminal as TerminalIcon, MonitorX, MousePointerClick,
} from "lucide-react";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "../components/ui/resizable";
import Terminal from "../components/Terminal";
import AIChat from "../components/AIChat";
import DeviceTerminal from "../components/DeviceTerminal";
import DeviceChat from "../components/DeviceChat";
import { useDeviceRealtime } from "../hooks/useDeviceRealtime";

const DEVICE_ICONS = { server: Server, laptop: Laptop, monitor: Monitor, cpu: Cpu, database: Database, cloud: Cloud, smartphone: Smartphone, "hard-drive": HardDrive };

export default function Workspace() {
  const { activeServer } = useOutletContext();
  const terminalRef = useRef(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [compact, setCompact] = useState(() => window.matchMedia("(max-width: 1099px)").matches);
  useEffect(() => {
    const query = window.matchMedia("(max-width: 1099px)");
    const update = () => setCompact(query.matches);
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  const { devices } = useDeviceRealtime();
  const [selectedId, setSelectedId] = useState(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const autoSelected = useRef(false);
  const serverId = activeServer?.id;

  // Put the autonomous Agent workspace first when a connected device appears.
  // Users can still choose “No Device Selected” manually afterward.
  useEffect(() => {
    if (!autoSelected.current && devices.length) {
      const preferred = devices.find((d) => d.status === "online") || devices[0];
      setSelectedId(preferred.id);
      autoSelected.current = true;
    }
  }, [devices]);

  const device = devices.find((d) => d.id === selectedId) || null;
  const online = device?.status === "online";

  return (
    <div className="remote-workspace flex flex-col p-3 md:p-4 gap-3">
      {/* Top bar: device selector */}
      <div className="flex flex-wrap items-center gap-3 shrink-0">
        <span className="text-xs uppercase tracking-[0.15em] text-white/30 hidden sm:block">Target device</span>
        <DeviceSelector devices={devices} selected={device} onSelect={(id) => { setSelectedId(id); setPickerOpen(false); }}
          open={pickerOpen} setOpen={setPickerOpen} />
        {device && (
          <span className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full ${online ? "bg-[#22C55E]/10 text-[#22C55E]" : "bg-red-500/10 text-red-400"}`} data-testid="workspace-device-status">
            <Circle className={`w-2 h-2 ${online ? "fill-[#22C55E] text-[#22C55E] pulse-dot" : "fill-red-400 text-red-400"}`} />
            {online ? "Online" : "Offline"}
          </span>
        )}
      </div>

      {/* Body */}
      <div className="flex-1 min-h-0">
        {device ? (
          online ? (
            fullscreen ? (
              <div className="fixed inset-0 z-50 bg-[#050505]">
                <DeviceTerminal ref={terminalRef} deviceId={device.id} deviceName={device.name} />
              </div>
            ) : (
              <ResizablePanelGroup direction={compact ? "vertical" : "horizontal"} className="h-full rounded-2xl overflow-hidden border border-white/10" data-testid="device-console">
                <ResizablePanel defaultSize={55} minSize={30}>
                  <DeviceTerminal key={device.id} ref={terminalRef} deviceId={device.id} deviceName={device.name} />
                </ResizablePanel>
                <ResizableHandle className="bg-white/10 hover:bg-accent-ai/50 transition-colors" />
                <ResizablePanel defaultSize={45} minSize={28}>
                  <div className="h-full flex flex-col bg-[#0A0A0B]">
                    <DeviceChat key={device.id} device={device} terminalRef={terminalRef} />
                  </div>
                </ResizablePanel>
              </ResizablePanelGroup>
            )
          ) : (
            <div className="h-full flex items-center justify-center rounded-2xl border border-white/10">
              <div className="text-center glass rounded-2xl p-6 sm:p-10 max-w-md" data-testid="device-offline-state">
                <MonitorX className="w-12 h-12 text-red-400/60 mx-auto mb-4" />
                <h3 className="font-display text-2xl">Device Offline</h3>
                <p className="text-white/40 text-sm mt-2">{device.name} is not connected. Start the Hacker rsvx7 Ai Agent on the device to open a terminal and run commands.</p>
                <Link to={`/app/devices/${device.id}`} className="inline-block mt-5 text-xs text-gold hover:underline">Manage device →</Link>
              </div>
            </div>
          )
        ) : serverId ? (
          fullscreen ? (
            <div className="fixed inset-0 z-50 bg-[#050505]">
              <Terminal ref={terminalRef} serverId={serverId} fullscreen onToggleFullscreen={() => setFullscreen(false)} />
            </div>
          ) : (
            <ResizablePanelGroup direction={compact ? "vertical" : "horizontal"} className="h-full rounded-2xl overflow-hidden border border-white/10">
              <ResizablePanel defaultSize={55} minSize={30}>
                <Terminal ref={terminalRef} serverId={serverId} fullscreen={false} onToggleFullscreen={() => setFullscreen(true)} />
              </ResizablePanel>
              <ResizableHandle className="bg-white/10 hover:bg-accent-ai/50 transition-colors" />
              <ResizablePanel defaultSize={45} minSize={28}>
                <AIChat serverId={serverId} terminalRef={terminalRef} />
              </ResizablePanel>
            </ResizablePanelGroup>
          )
        ) : (
          <div className="h-full flex items-center justify-center rounded-2xl border border-white/10">
            <div className="text-center glass rounded-2xl p-6 sm:p-10 max-w-md" data-testid="no-device-selected">
              <MousePointerClick className="w-12 h-12 text-white/20 mx-auto mb-4" />
              <h3 className="font-display text-2xl">Please select a connected device</h3>
              <p className="text-white/40 text-sm mt-2">Choose a device above to open a live terminal and let Hacker rsvx7 Ai run and explain commands on it.</p>
              <Link to="/app/devices" className="inline-block mt-5 text-xs text-gold hover:underline">Go to devices →</Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function DeviceSelector({ devices, selected, onSelect, open, setOpen }) {
  const SelIcon = selected ? (DEVICE_ICONS[selected.icon] || Server) : TerminalIcon;
  return <DropdownMenu open={open} onOpenChange={setOpen}>
    <DropdownMenuTrigger asChild>
      <button data-testid="workspace-device-selector" aria-label="Target device" className="flex min-w-0 w-64 max-w-full items-center gap-2 px-3 h-11 rounded-xl text-sm bg-white/5 border border-white/10 hover:border-white/20 transition-colors">
        <SelIcon className={`w-4 h-4 shrink-0 ${selected ? "text-gold" : "text-white/40"}`} />
        <span className="truncate flex-1 text-start">{selected ? selected.name : "No Device Selected"}</span>
        <ChevronDown className="w-4 h-4 text-white/40 shrink-0" />
      </button>
    </DropdownMenuTrigger>
    <DropdownMenuContent align="start" className="w-80 max-w-[calc(100vw-2rem)] bg-[#16181D] border-white/10" data-testid="workspace-device-menu">
      <DropdownMenuItem onSelect={() => onSelect(null)} data-testid="workspace-device-none"><TerminalIcon className="w-4 h-4 shrink-0" /> No Device Selected</DropdownMenuItem>
      <DropdownMenuSeparator />
      <DropdownMenuLabel className="text-xs text-white/50">Linked devices</DropdownMenuLabel>
      {!devices.length && <p className="px-3 py-3 text-sm text-white/50">No devices linked yet.</p>}
      {devices.map(d => {
        const Icon = DEVICE_ICONS[d.icon] || Server;
        return <DropdownMenuItem key={d.id} onSelect={() => onSelect(d.id)} data-testid={`workspace-device-${d.id}`}>
          <Icon className="w-4 h-4 text-gold shrink-0" /><span className="flex-1 min-w-0 truncate">{d.name}</span>
          <span className={`text-xs ${d.status === "online" ? "text-[#22C55E]" : "text-white/50"}`}>{d.status === "online" ? "Online" : "Offline"}</span>
        </DropdownMenuItem>;
      })}
    </DropdownMenuContent>
  </DropdownMenu>;
}
