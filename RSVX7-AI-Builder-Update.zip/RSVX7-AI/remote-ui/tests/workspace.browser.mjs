// Run after `node scripts/build_remote.mjs`. Uses the host Playwright install.
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const root = fileURLToPath(new URL('../../', import.meta.url));
const fixtures = {
  '/auth/me': {username:'Workspace tester',plan:'Pro'},
  '/servers': [],
  '/devices': [{id:'offline-device',name:'Development laptop with a deliberately long device name',device_id:'HG-TEST-1234',status:'offline',icon:'laptop'}],
  '/dashboard/stats': {total_servers:0,online_servers:0,commands_run:0,ai_messages:0,servers:[],recent_activity:[],plan:'Pro'},
  '/agent/info': {version:'test'},
};
const server = createServer(async (request,response) => {
  try {
    const url = new URL(request.url,'http://localhost');
    if (url.pathname.startsWith('/api/remote/api')) {
      response.setHeader('Content-Type','application/json');
      response.end(JSON.stringify(fixtures[url.pathname.slice('/api/remote/api'.length)] ?? [])); return;
    }
    const path = url.pathname.startsWith('/fonts/') ? resolve(root,'frontend/public',url.pathname.slice(1)) : resolve(root,'frontend/build/remote',url.pathname.replace(/^\/remote-ui\/?/, '') || 'index.html');
    const content = await readFile(path);
    response.setHeader('Content-Type', path.endsWith('.css') ? 'text/css' : path.endsWith('.js') ? 'text/javascript' : path.endsWith('.woff2') ? 'font/woff2' : 'text/html');
    response.end(content);
  } catch { response.writeHead(404).end(); }
});
await new Promise(resolve => server.listen(0,'127.0.0.1',resolve));
const browser = await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH || undefined,args:process.env.CHROMIUM_ARGS ? JSON.parse(process.env.CHROMIUM_ARGS) : ['--no-sandbox']});
try {
  const page = await browser.newPage({viewport:{width:390,height:844},reducedMotion:'reduce'});
  const errors = [];
  page.on('pageerror',error => errors.push(error.message));
  await page.addInitScript((devices) => {
    class FixtureSocket {
      static OPEN = 1;
      constructor() {
        this.readyState = 1;
        setTimeout(() => {
          this.onopen?.();
          this.onmessage?.({data: JSON.stringify({type:'snapshot', devices})});
        }, 10);
      }
      send() {}
      close() { this.readyState = 3; this.onclose?.(); }
    }
    window.WebSocket = FixtureSocket;
  }, fixtures['/devices']);
  await page.goto(`http://127.0.0.1:${server.address().port}/remote-ui/#/app`);
  await page.getByRole('heading',{name:'Command Center'}).waitFor();
  await page.getByTestId('mobile-nav-open').click();
  await page.getByRole('dialog').getByRole('link',{name:'Servers',exact:true}).click();
  await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByTestId('add-server-btn').click();
  assert.equal(await page.getByLabel('Nickname',{exact:true}).count(),1);
  await page.getByLabel('Nickname',{exact:true}).fill('Production');
  await page.getByLabel('Host / IP').fill('192.0.2.1');
  await page.getByLabel('Username',{exact:true}).fill('tester');
  assert.equal(await page.getByTestId('save-server-btn').isEnabled(),true);
  await page.keyboard.press('Escape');
  await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByTestId('mobile-nav-open').click();
  await page.getByRole('dialog').getByTestId('user-menu').click();
  await page.getByRole('menuitem',{name:'Log out'}).waitFor();
  await page.keyboard.press('Escape');
  await page.getByRole('menuitem',{name:'Log out'}).waitFor({state:'hidden'});
  await page.keyboard.press('Escape');
  await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByTestId('mobile-nav-open').click();
  await page.getByRole('dialog').getByRole('link',{name:'Workspace',exact:true}).click();
  await page.getByTestId('device-offline-state').waitFor();
  await page.getByTestId('workspace-device-selector').focus();
  await page.keyboard.press('Enter');
  await page.getByTestId('workspace-device-menu').waitFor();
  await page.keyboard.press('Escape');
  assert.equal(await page.getByTestId('workspace-device-selector').getAttribute('data-state'),'closed');
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth),false);
  await page.screenshot({path:'/tmp/remote-mobile-workspace.png',fullPage:true});
  await page.setViewportSize({width:1440,height:1000});
  await page.getByRole('navigation',{name:'Workspace',exact:true}).getByRole('link',{name:'Devices',exact:true}).click();
  await page.getByTestId('add-device-btn').click();
  await page.getByTestId('already-installed').click();
  await page.getByLabel('Device ID',{exact:true}).fill('HG-TEST');
  await page.getByLabel('Device Secret',{exact:true}).fill('test-secret');
  assert.equal(await page.getByTestId('register-device-btn').isEnabled(),true);
  await page.keyboard.press('Escape');
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth),false);
  assert.deepEqual(errors,[]);
  console.log('Remote browser checks passed: mobile navigation/account, server form labels, keyboard picker, device pairing labels, 390/1440 overflow, no page errors.');
} finally { await browser.close(); await new Promise(resolve => server.close(resolve)); }
