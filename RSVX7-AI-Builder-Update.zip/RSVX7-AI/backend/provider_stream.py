"""Readable text normalization shared by OpenAI-compatible provider consumers."""

def _reasoning_text(value) -> str:
    """Extract only readable reasoning text, never encrypted/provider payloads."""
    if isinstance(value, str):
        return value
    if not isinstance(value, dict):
        return ""
    kind = str(value.get("type") or value.get("format") or "").lower()
    if "encrypted" in kind:
        return ""
    if kind and kind not in {"text", "summary", "reasoning", "reasoning.text", "reasoning.summary"} \
            and not kind.endswith((".text", ".summary")):
        return ""
    text = value.get("text") if "text" in value else value.get("summary")
    return text if isinstance(text, str) else ""


def _reasoning_details_text(details) -> str:
    if details is None:
        return ""
    items = details if isinstance(details, (list, tuple)) else [details]
    parts = []
    for item in items:
        if isinstance(item, dict):
            payload = item
        else:
            payload = {
                key: getattr(item, key)
                for key in ("type", "format", "text", "summary")
                if hasattr(item, key)
            }
        text = _reasoning_text(payload)
        if text:
            parts.append(text)
    return "".join(parts)


def _reasoning_delta(delta) -> str:
    """Normalize the SDK's supported reasoning field variants without guessing."""
    if delta is None:
        return ""
    for name in ("reasoning", "reasoning_content"):
        text = _reasoning_text(getattr(delta, name, None))
        if text:
            return text
    return _reasoning_details_text(getattr(delta, "reasoning_details", None))


def _content_delta(value) -> str:
    """Keep text parts from compatible providers; never stringify other payloads."""
    if isinstance(value, str):
        return value
    if not isinstance(value, list):
        return ""
    return "".join(
        part["text"] for part in value
        if isinstance(part, dict) and part.get("type") == "text"
        and isinstance(part.get("text"), str)
    )


