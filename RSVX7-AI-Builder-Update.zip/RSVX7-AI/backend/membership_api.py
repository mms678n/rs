"""Public catalog, member requests, and payment-permission admin activation."""
import secrets
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from auth import db, current_user, require_permission
from memberships import PLANS, refresh, wallet_fields, activate, utcnow

router = APIRouter(prefix="/api/memberships", tags=["Monthly plans"])
admin_router = APIRouter(prefix="/api/admin/memberships", tags=["Monthly plans admin"])
@router.get("/plans")
async def plans(): return {"plans": list(PLANS.values())}
@router.get("/me")
async def mine(user=Depends(current_user)):
    user = await refresh(user, db)
    return wallet_fields(user)
class PlanRequest(BaseModel):
    plan: str = Field(pattern="^(pro|max)$")
@router.post("/request")
async def request_plan(body: PlanRequest, user=Depends(current_user)):
    # Requests are pending only. No paid entitlement or credits are self-granted.
    request = {"id": secrets.token_hex(12), "plan": body.plan, "at": utcnow().isoformat(), "status": "pending"}
    existing = user.get("membership_request") or {}
    if existing.get("status") == "pending" and existing.get("plan") == body.plan: return {"request": existing}
    await db.users.update_one({"_id": user["_id"]}, {"$set": {"membership_request": request}})
    return {"request": request}
@admin_router.get("")
async def members(q: str = Query("", max_length=100), admin=Depends(require_permission("payments"))):
    query = {"username": {"$regex": __import__("re").escape(q), "$options": "i"}} if q else {}
    users = await db.users.find(query, {"_id": 1, "username": 1, "role": 1, "token_balance": 1, "monthly": 1, "membership_request": 1, "membership_last_action": 1}).limit(500).to_list(500)
    results = []
    for user in users:
        refreshed = await refresh(user, db, grant_missing=False)
        results.append({"_id": str(user["_id"]), "username": user.get("username", ""), "role": user.get("role", "user"),
            "token_balance": refreshed.get("token_balance", 0), "request": refreshed.get("membership_request"),
            "last_action": refreshed.get("membership_last_action"), **wallet_fields(refreshed)})
    return {"users": results, "plans": list(PLANS.values())}
class Activation(BaseModel):
    plan: str = Field(pattern="^(free|pro|max)$")
    request_id: str = Field(min_length=8, max_length=100, pattern="^[A-Za-z0-9_-]+$")
@admin_router.post("/{uid}")
async def set_plan(uid: str, body: Activation, admin=Depends(require_permission("payments"))):
    operation = admin["_id"] + ":" + body.request_id
    user = await activate(db, uid, body.plan, operation)
    await db.users.update_one({"_id": uid, "membership_request.status": "pending", "membership_request.plan": body.plan},
        {"$set": {"membership_request.status": "activated", "membership_request.activated_by": admin["_id"]}})
    return {"ok": True, "token_balance": user.get("token_balance", 0), **wallet_fields(user)}
