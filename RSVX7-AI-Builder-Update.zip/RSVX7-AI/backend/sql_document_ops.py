"""دلالات مستندات التطبيق وترجمة الاستعلامات إلى SQL آمن.

هذه ليست طبقة توافق Mongo عامة. القائمة هنا هي عقود العمليات التي يستعملها
التطبيق فعلياً؛ أي عامل آخر يرفع UnsupportedMongoOperator بدلاً من التخمين.
"""
from __future__ import annotations

from dataclasses import dataclass
from copy import deepcopy
from datetime import date, datetime, timezone
import json
import re
from typing import Any, Callable, Iterable, Mapping

try:
    from pymongo.errors import DuplicateKeyError
except Exception:  # pragma: no cover - pymongo is an application dependency
    class DuplicateKeyError(Exception):
        """Fallback only for documentation/import tooling."""


class UnsupportedMongoOperator(ValueError):
    """عامل Mongo خارج عقد التطبيق المسموح."""


class UnsafeFieldError(ValueError):
    """حقل أو مسار لا يطابق whitelist الخاصة بالتطبيق."""


MISSING = object()
_MONGO_OPERATORS = {
    "$eq", "$ne", "$in", "$nin", "$gt", "$gte", "$lt", "$lte",
    "$exists", "$type", "$regex", "$options",
}
_UPDATE_OPERATORS = {
    "$inc", "$set", "$setOnInsert", "$unset", "$addToSet", "$pull", "$max",
}
_LOGICAL_OPERATORS = {"$or", "$and"}
_SAFE_PATH = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*$")


def utc_datetime(value: Any) -> datetime | None:
    """إرجاع datetime واعٍ بتوقيت UTC أو None للقيم غير الصالحة."""
    if isinstance(value, datetime):
        return (value.replace(tzinfo=timezone.utc) if value.tzinfo is None
                else value.astimezone(timezone.utc))
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day, tzinfo=timezone.utc)
    if isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
        return (parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None
                else parsed.astimezone(timezone.utc))
    return None


def json_default(value: Any) -> str:
    """تطبيع القيم غير القابلة لـ JSON مع إبقاء UTC بدقة microseconds."""
    if isinstance(value, datetime):
        dt = utc_datetime(value)
        return dt.isoformat().replace("+00:00", "Z") if dt else str(value)
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, set):
        return sorted(value)
    raise TypeError(f"Unsupported JSON value: {type(value).__name__}")


def dumps_document(document: Mapping[str, Any]) -> str:
    return json.dumps(document, ensure_ascii=False, separators=(",", ":"), default=json_default)


def loads_document(value: Any) -> dict[str, Any]:
    if isinstance(value, (bytes, bytearray)):
        value = value.decode("utf-8")
    if isinstance(value, str):
        loaded = json.loads(value)
    elif isinstance(value, Mapping):
        loaded = dict(value)
    else:
        loaded = {}
    if not isinstance(loaded, dict):
        raise ValueError("Stored document JSON must be an object")
    return loaded


def split_path(path: str) -> list[str]:
    if path == "_id":
        return ["_id"]
    if not isinstance(path, str) or not _SAFE_PATH.fullmatch(path):
        raise UnsafeFieldError(f"Unsafe field path: {path!r}")
    return path.split(".")


def get_path(document: Mapping[str, Any], path: str) -> Any:
    parts = split_path(path)
    current: Any = document
    for part in parts:
        if not isinstance(current, Mapping) or part not in current:
            return MISSING
        current = current[part]
    return current


def set_path(document: dict[str, Any], path: str, value: Any) -> None:
    parts = split_path(path)
    if parts == ["_id"]:
        document["_id"] = value
        return
    current = document
    for part in parts[:-1]:
        existing = current.get(part)
        if not isinstance(existing, dict):
            existing = {}
            current[part] = existing
        current = existing
    current[parts[-1]] = value


def unset_path(document: dict[str, Any], path: str) -> None:
    parts = split_path(path)
    if parts == ["_id"]:
        raise ValueError("_id cannot be unset")
    current: Any = document
    for part in parts[:-1]:
        if not isinstance(current, Mapping) or part not in current:
            return
        current = current[part]
    if isinstance(current, dict):
        current.pop(parts[-1], None)


def _mongo_equal(actual: Any, expected: Any) -> bool:
    if actual is MISSING:
        return expected is None
    if isinstance(actual, list) and not isinstance(expected, list):
        return any(_mongo_equal(item, expected) for item in actual)
    if isinstance(actual, datetime) and isinstance(expected, datetime):
        left = utc_datetime(actual)
        right = utc_datetime(expected)
        return left == right
    return actual == expected


def _comparison_values(actual: Any) -> Iterable[Any]:
    if isinstance(actual, list):
        return actual
    return (actual,)


def _compare(actual: Any, expected: Any, operator: str) -> bool:
    if actual is MISSING:
        return False
    for candidate in _comparison_values(actual):
        try:
            left, right = candidate, expected
            if isinstance(left, (datetime, str)) and isinstance(right, (datetime, str)):
                left_dt, right_dt = utc_datetime(left), utc_datetime(right)
                if left_dt is not None and right_dt is not None:
                    left, right = left_dt, right_dt
            if operator == "$gt" and left > right:
                return True
            if operator == "$gte" and left >= right:
                return True
            if operator == "$lt" and left < right:
                return True
            if operator == "$lte" and left <= right:
                return True
        except (TypeError, ValueError):
            continue
    return False


def _type_name(value: Any) -> str:
    if value is MISSING:
        return "missing"
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, datetime):
        return "date"
    return type(value).__name__


def _regex_match(actual: Any, pattern: str, options: str) -> bool:
    unsupported = set(options) - set("imsx")
    if unsupported:
        raise UnsupportedMongoOperator(f"Unsupported regex option(s): {''.join(sorted(unsupported))}")
    flags = 0
    if "i" in options:
        flags |= re.IGNORECASE
    if "m" in options:
        flags |= re.MULTILINE
    if "s" in options:
        flags |= re.DOTALL
    if "x" in options:
        flags |= re.VERBOSE
    try:
        compiled = re.compile(pattern, flags)
    except re.error as exc:
        raise ValueError(f"Invalid regex: {exc}") from exc
    return any(compiled.search(str(item)) is not None for item in _comparison_values(actual)) \
        if actual is not MISSING else False


def _evaluate_operator(actual: Any, operator: str, expected: Any, options: str = "") -> bool:
    if operator not in _MONGO_OPERATORS:
        raise UnsupportedMongoOperator(operator)
    if operator == "$exists":
        return (actual is not MISSING) is bool(expected)
    if operator == "$type":
        expected_types = expected if isinstance(expected, list) else [expected]
        aliases = {"int": "number", "long": "number", "double": "number",
                   "decimal": "number", "bool": "bool", "boolean": "bool"}
        return any(_type_name(actual) == aliases.get(str(item), str(item)) for item in expected_types)
    if operator == "$regex":
        if not isinstance(expected, str):
            raise ValueError("$regex requires a string")
        return _regex_match(actual, expected, options)
    if operator == "$options":
        if not isinstance(expected, str):
            raise ValueError("$options requires a string")
        if set(expected) - set("imsx"):
            raise UnsupportedMongoOperator(f"Unsupported regex option(s): {expected}")
        return True
    if operator == "$ne":
        if actual is MISSING:
            return True
        return not _mongo_equal(actual, expected)
    if operator == "$nin":
        if actual is MISSING:
            return True
        if not isinstance(expected, list):
            raise ValueError("$nin requires an array")
        return not any(_mongo_equal(actual, item) for item in expected)
    if operator == "$in":
        if actual is MISSING or not isinstance(expected, list):
            if not isinstance(expected, list):
                raise ValueError("$in requires an array")
            return False
        return any(_mongo_equal(actual, item) for item in expected)
    if operator in {"$gt", "$gte", "$lt", "$lte"}:
        return _compare(actual, expected, operator)
    if operator == "$eq":
        return _mongo_equal(actual, expected)
    raise UnsupportedMongoOperator(operator)


def matches_document(document: Mapping[str, Any], query: Mapping[str, Any] | None) -> bool:
    """مطابقة Mongo الدقيقة للجزء المستعمل من filters التطبيق."""
    if not query:
        return True
    for key, condition in query.items():
        if key in _LOGICAL_OPERATORS:
            if not isinstance(condition, list) or not all(isinstance(item, Mapping) for item in condition):
                raise ValueError(f"{key} requires a list of objects")
            results = [matches_document(document, item) for item in condition]
            if key == "$or" and not any(results):
                return False
            if key == "$and" and not all(results):
                return False
            continue
        if key.startswith("$"):
            raise UnsupportedMongoOperator(key)
        actual = get_path(document, key)
        if isinstance(condition, Mapping) and any(str(op).startswith("$") for op in condition):
            options = condition.get("$options", "")
            for operator, expected in condition.items():
                if not _evaluate_operator(actual, operator, expected, options):
                    return False
        elif not _mongo_equal(actual, condition):
            return False
    return True


def _ensure_update_path(path: str) -> None:
    split_path(path)
    if path == "_id":
        raise ValueError("_id is immutable")


def _numeric(value: Any, label: str) -> int | float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{label} requires a number")
    return value


def _pull_matches(value: Any, criterion: Any) -> bool:
    if isinstance(criterion, Mapping) and any(str(k).startswith("$") for k in criterion):
        return matches_document({"value": value}, {"value": criterion})
    return _mongo_equal(value, criterion)


def apply_update(document: Mapping[str, Any], update: Mapping[str, Any], *, is_insert: bool = False) -> dict[str, Any]:
    """تطبيق operators التطبيق فقط على نسخة مستقلة من المستند."""
    if not isinstance(update, Mapping) or not update:
        raise ValueError("An operator update document is required")
    if any(not str(key).startswith("$") for key in update):
        raise ValueError("Replacement updates are not part of the MySQL contract")
    unknown = set(update) - _UPDATE_OPERATORS
    if unknown:
        raise UnsupportedMongoOperator(next(iter(sorted(unknown))))
    result = deepcopy(dict(document))
    touched: set[str] = set()
    for operator, values in update.items():
        if not isinstance(values, Mapping):
            raise ValueError(f"{operator} requires an object")
        if operator == "$setOnInsert" and not is_insert:
            continue
        for path, value in values.items():
            _ensure_update_path(path)
            if path in touched:
                raise ValueError(f"Conflicting update path: {path}")
            touched.add(path)
            current = get_path(result, path)
            if operator == "$set" or operator == "$setOnInsert":
                set_path(result, path, deepcopy(value))
            elif operator == "$unset":
                unset_path(result, path)
            elif operator == "$inc":
                amount = _numeric(value, "$inc")
                base = 0 if current is MISSING or current is None else _numeric(current, "$inc target")
                set_path(result, path, base + amount)
            elif operator == "$max":
                if current is MISSING or _compare(current, value, "$lt"):
                    set_path(result, path, deepcopy(value))
            elif operator == "$addToSet":
                items = value.get("$each") if isinstance(value, Mapping) and "$each" in value else [value]
                if not isinstance(items, list):
                    raise ValueError("$addToSet.$each requires an array")
                array = [] if current is MISSING or current is None else current
                if not isinstance(array, list):
                    raise TypeError("$addToSet target must be an array")
                array = deepcopy(array)
                for item in items:
                    if not any(_mongo_equal(existing, item) for existing in array):
                        array.append(deepcopy(item))
                set_path(result, path, array)
            elif operator == "$pull":
                if current is MISSING:
                    continue
                if not isinstance(current, list):
                    raise TypeError("$pull target must be an array")
                set_path(result, path, [item for item in current if not _pull_matches(item, value)])
    return result


def upsert_seed(query: Mapping[str, Any]) -> dict[str, Any]:
    """استخراج equality predicates فقط لبناء مستند upsert موثوق."""
    seed: dict[str, Any] = {}
    for key, value in query.items():
        if key.startswith("$"):
            if key in _LOGICAL_OPERATORS:
                # Mongo upsert seeds from equality predicates; the lease query
                # intentionally has an `$or` expiry guard and must seed only
                # its stable `_id`.
                continue
            raise UnsupportedMongoOperator(key)
        if isinstance(value, Mapping) and any(str(k).startswith("$") for k in value):
            # Range/exists predicates select an existing row but do not define
            # a value for a newly inserted row.
            continue
        set_path(seed, key, deepcopy(value))
    return seed


def _json_literal(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=json_default)


@dataclass(frozen=True)
class CompiledQuery:
    sql: str
    params: tuple[Any, ...]


def compile_filter(
    query: Mapping[str, Any] | None,
    *,
    field_validator: Callable[[str], str] | None = None,
    typed_fields: Mapping[str, str] | None = None,
) -> CompiledQuery:
    """ترجمة filter إلى WHERE مع bind parameters فقط.

    `field_validator` مملوك للمستودع ويمنع الحقول غير المعروفة. أسماء الأعمدة
    لا تأتي من مدخل المستخدم؛ القيم ومسارات JSON كلها parameters.
    """
    query = query or {}
    typed_fields = typed_fields or {}
    validate = field_validator or (lambda field: field)

    def path_for(field: str) -> str:
        validate(field)
        if field == "_id":
            return "$. _id".replace(" ", "")
        return "$." + field

    def exists_expr(field: str) -> tuple[str, list[Any]]:
        if field == "_id":
            return "1=1", []
        return "JSON_CONTAINS_PATH(data, 'one', %s)", [path_for(field)]

    def scalar_expr(field: str) -> tuple[str, list[Any]]:
        validate(field)
        if field == "_id":
            return "doc_id", []
        column = typed_fields.get(field)
        if column:
            return f"`{column}`", []
        return "JSON_UNQUOTE(JSON_EXTRACT(data, %s))", [path_for(field)]

    def raw_expr(field: str) -> tuple[str, list[Any]]:
        validate(field)
        if field == "_id":
            return "doc_id", []
        return "JSON_EXTRACT(data, %s)", [path_for(field)]

    def equality(field: str, expected: Any) -> tuple[str, list[Any]]:
        if expected is None:
            exists, ep = exists_expr(field)
            raw, rp = raw_expr(field)
            return f"((NOT ({exists})) OR {raw} IS NULL OR JSON_TYPE({raw}) = 'NULL')", ep + rp + rp
        raw, rp = raw_expr(field)
        candidate = _json_literal(expected)
        if field == "_id":
            return "doc_id = %s", [str(expected)]
        column = typed_fields.get(field)
        # Ownership/idempotency/scalar predicates use real indexed columns.
        # Datetime equality remains JSON-shaped to preserve string identity.
        if column and isinstance(expected, (str, bool, int, float)) and not column.endswith("_at"):
            return f"`{column}` = %s", [expected]
        # JSON_CONTAINS handles scalar equality and scalar-in-array equality.
        return f"JSON_CONTAINS(data, %s, %s)", [candidate, path_for(field)]

    def one_field(field: str, condition: Any) -> tuple[str, list[Any]]:
        validate(field)
        if not (isinstance(condition, Mapping) and any(str(k).startswith("$") for k in condition)):
            return equality(field, condition)
        parts: list[str] = []
        params: list[Any] = []
        options = condition.get("$options", "")
        if not isinstance(options, str) or set(options) - set("imsx"):
            raise UnsupportedMongoOperator(f"Unsupported regex option(s): {options!r}")
        for operator, expected in condition.items():
            if operator == "$options":
                continue
            if operator not in _MONGO_OPERATORS:
                raise UnsupportedMongoOperator(operator)
            exists, ep = exists_expr(field)
            raw, rp = raw_expr(field)
            scalar, sp = scalar_expr(field)
            if operator == "$exists":
                parts.append(f"({exists} = %s)")
                params.extend(ep)
                params.append(1 if bool(expected) else 0)
            elif operator == "$eq":
                fragment, fp = equality(field, expected)
                parts.append(fragment)
                params.extend(fp)
            elif operator == "$ne":
                candidate = _json_literal(expected)
                if field == "_id":
                    parts.append(f"((NOT ({exists})) OR doc_id <> %s)")
                    params.extend(ep)
                    params.append(str(expected))
                else:
                    parts.append(f"((NOT ({exists})) OR NOT JSON_CONTAINS(data, %s, %s))")
                    params.extend(ep)
                    params.extend([candidate, path_for(field)])
            elif operator in {"$in", "$nin"}:
                if not isinstance(expected, list):
                    raise ValueError(f"{operator} requires an array")
                alternatives: list[str] = []
                alt_params: list[Any] = []
                for item in expected:
                    if field == "_id":
                        alternatives.append("doc_id = %s")
                        alt_params.append(str(item))
                    else:
                        alternatives.append("JSON_CONTAINS(data, %s, %s)")
                        alt_params.extend([_json_literal(item), path_for(field)])
                joined = " OR ".join(alternatives) or "0=1"
                if operator == "$in":
                    parts.append(f"({joined})")
                else:
                    parts.append(f"((NOT ({exists})) OR NOT ({joined}))")
                    # `$nin` needs the existence path in addition to alternatives.
                    params.extend(ep)
                params.extend(alt_params)
            elif operator in {"$gt", "$gte", "$lt", "$lte"}:
                if isinstance(expected, (int, float)) and not isinstance(expected, bool):
                    compare_expr = f"CAST({scalar} AS DECIMAL(65,18))"
                else:
                    compare_expr = scalar
                op = {"$gt": ">", "$gte": ">=", "$lt": "<", "$lte": "<="}[operator]
                parts.append(f"({exists} AND {compare_expr} {op} %s)")
                params.extend(ep + sp)
                params.append(expected)
            elif operator == "$type":
                wanted = expected if isinstance(expected, list) else [expected]
                aliases = {"int": ["INTEGER"], "long": ["INTEGER"], "double": ["DOUBLE"],
                           "decimal": ["DOUBLE", "DECIMAL"], "bool": ["BOOLEAN"], "boolean": ["BOOLEAN"],
                           "number": ["INTEGER", "DOUBLE", "DECIMAL"]}
                names = [name for item in wanted for name in aliases.get(str(item), [str(item).upper()])]
                placeholders = ",".join("%s" for _ in names) or "NULL"
                parts.append(f"({exists} AND JSON_TYPE({raw}) IN ({placeholders}))")
                params.extend(ep + rp)
                params.extend(names)
            elif operator == "$regex":
                if not isinstance(expected, str):
                    raise ValueError("$regex requires a string")
                if set(options) - set("i"):
                    raise UnsupportedMongoOperator(f"Unsupported regex option(s): {options}")
                # MySQL/MariaDB REGEXP is portable; i is emulated by LOWER.
                regex_expr = f"LOWER({scalar}) COLLATE utf8mb4_bin REGEXP LOWER(%s)" if "i" in options else f"{scalar} COLLATE utf8mb4_bin REGEXP %s"
                parts.append(f"({exists} AND {regex_expr})")
                params.extend(ep + sp)
                params.append(expected)
            else:
                raise UnsupportedMongoOperator(operator)
        return " AND ".join(parts) if parts else "1=1", params

    def group(items: Mapping[str, Any]) -> tuple[str, list[Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        for key, value in items.items():
            if key == "$or":
                if not isinstance(value, list) or not value:
                    raise ValueError("$or requires a non-empty list")
                sub = [group(item) for item in value]
                clauses.append("(" + " OR ".join(item[0] for item in sub) + ")")
                for _, subparams in sub:
                    params.extend(subparams)
            elif key == "$and":
                if not isinstance(value, list) or not value:
                    raise ValueError("$and requires a non-empty list")
                sub = [group(item) for item in value]
                clauses.append("(" + " AND ".join(item[0] for item in sub) + ")")
                for _, subparams in sub:
                    params.extend(subparams)
            elif key.startswith("$"):
                raise UnsupportedMongoOperator(key)
            else:
                fragment, fragment_params = one_field(key, value)
                clauses.append(fragment)
                params.extend(fragment_params)
        return (" AND ".join(clauses) if clauses else "1=1"), params

    sql, params = group(query)
    return CompiledQuery(sql=sql, params=tuple(params))


def apply_projection(document: Mapping[str, Any], projection: Mapping[str, Any] | None) -> dict[str, Any]:
    if not projection:
        return deepcopy(dict(document))
    include = [key for key, value in projection.items() if key != "_id" and bool(value)]
    exclude = [key for key, value in projection.items() if key != "_id" and not bool(value)]
    if include and exclude:
        raise ValueError("Projection cannot mix inclusion and exclusion")
    if include:
        result: dict[str, Any] = {}
        for path in include:
            value = get_path(document, path)
            if value is not MISSING:
                set_path(result, path, deepcopy(value))
        if projection.get("_id", 1) and "_id" in document:
            result["_id"] = document["_id"]
        return result
    result = deepcopy(dict(document))
    for path in exclude:
        unset_path(result, path)
    if projection.get("_id", 1) == 0:
        result.pop("_id", None)
    return result


# أسماء الأعمدة typed لا تأتي من input؛ هذه الخريطة هي whitelist SQL المركزية.
TYPED_FIELDS: dict[str, dict[str, str]] = {
    "users": {
        "user_id": "user_id", "username": "username", "email": "email",
        "role": "role", "status": "status", "registration_ip": "registration_ip", "last_ip": "last_ip", "is_owner": "is_owner",
        "token_balance": "token_balance", "registered_at": "registered_at",
        "last_login": "last_login", "updated_at": "updated_at",
    },
    "usage": {"user_id": "user_id", "date": "date_key"},
    "settings": {},
    "token_usage_history": {
        "user_id": "user_id", "conversation_id": "conversation_id",
        "created_at": "created_at", "idempotency_key": "idempotency_key",
    },
    "coupons": {"code": "code", "enabled": "enabled", "expires_at": "expires_at", "starts_at": "starts_at", "created_at": "created_at"},
    "redemptions": {"user_id": "user_id", "code": "code", "dedup_key": "dedup_key", "redeemed_at": "redeemed_at", "tokens": "tokens"},
    "referral_codes": {"user_id": "user_id"},
    "tg_required_groups": {"order": "item_order", "created_at": "created_at", "updated_at": "updated_at"},
    "tg_seen": {"telegram_id": "telegram_id"},
    "projects": {"user_id": "user_id", "is_archived": "is_archived", "is_favorite": "is_favorite", "created_at": "created_at", "updated_at": "updated_at", "last_opened_at": "last_opened_at"},
    "conversations": {"user_id": "user_id", "project_id": "project_id", "is_pinned": "is_pinned", "next_order_index": "next_order_index", "created_at": "created_at", "updated_at": "updated_at"},
    "messages": {"user_id": "user_id", "conversation_id": "conversation_id", "project_id": "project_id", "order_index": "order_index", "created_at": "created_at", "updated_at": "updated_at"},
    "notes": {"user_id": "user_id", "project_id": "project_id", "created_at": "created_at", "updated_at": "updated_at"},
    "files": {"user_id": "user_id", "project_id": "project_id", "is_deleted": "is_deleted", "upload_status": "upload_status", "created_at": "created_at"},
    "ai_request_leases": {"expires_at": "expires_at"},
    "status_checks": {"timestamp": "timestamp"},
    "banned_ips": {"banned_at": "banned_at"},
}

TYPED_FIELDS.update({name: {'user_id':'user_id','created_at':'created_at','updated_at':'updated_at','status':'status'}
    for name in ('remote_servers','remote_devices','remote_logs','remote_chat_sessions','remote_messages')})


def validate_field_for_collection(collection: str, field: str) -> str:
    """Whitelist للـ path syntax مع جدول collection معروف؛ JSON مرن لا يسمح SQL injection."""
    split_path(field)
    if field == "_id":
        return field
    # الحقول المتداخلة في telegram/subscription/hidden_context والمرفقات جزء من
    # data JSON. التحقق الصارم من كل اسم segment يمنع أي SQL identifier injection.
    if collection not in TYPED_FIELDS:
        raise UnsafeFieldError(f"Unknown collection: {collection}")
    return field
