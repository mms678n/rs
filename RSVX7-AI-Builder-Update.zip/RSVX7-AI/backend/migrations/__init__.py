"""Migrations are additive; execution is owned by mysql_repository."""
