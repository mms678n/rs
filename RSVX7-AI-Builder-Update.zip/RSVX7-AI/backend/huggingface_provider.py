"""Public HF router metadata; no SDK, database, credential storage, or billing."""
import copy
import re

BASE_URL = 'https://router.huggingface.co/v1'
IDENTITY_URL = 'https://huggingface.co/api/whoami-v2'


def is_huggingface(provider, base_url):
    return str(provider).lower() in ('huggingface', 'hf') and str(base_url).rstrip('/') == BASE_URL


def model_metadata(model, catalog):
    """Normalize /v1/models and explicit :provider IDs without guessing support."""
    if not isinstance(model, str) or not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)?', model):
        raise ValueError('invalid_model')
    base, _, selector = model.partition(':')
    if not isinstance(catalog, list):
        raise ValueError('invalid_catalog')
    item = next((row for row in catalog if isinstance(row, dict) and row.get('id') == base), None)
    if item is None:
        raise ValueError('model_unavailable')
    architecture = item.get('architecture') or {}
    if not isinstance(architecture, dict) or 'text' not in architecture.get('input_modalities', ['text']) or 'text' not in architecture.get('output_modalities', ['text']):
        raise ValueError('text_model_required')
    providers = item.get('providers') or []
    live = [row for row in providers if isinstance(row, dict) and row.get('status') == 'live']
    if selector and selector not in ('fastest', 'cheapest', 'preferred'):
        live = [row for row in live if row.get('provider') == selector]
    if not live:
        raise ValueError('provider_unavailable')

    def positive(value, fallback):
        return value if isinstance(value, int) and not isinstance(value, bool) and value > 0 else fallback

    # An automatic route can reach any live provider. Use the conservative
    # intersection of supported parameters and the smallest known context.
    context = min(positive(row.get('context_length'), 8192) for row in live)
    parameters = ['temperature', 'top_p', 'max_tokens']
    if all(row.get('supports_structured_output') is True for row in live):
        parameters += ['response_format', 'structured_outputs']
    if all(row.get('supports_tools') is True for row in live):
        parameters += ['tools', 'tool_choice']
    return {'model': model, 'context_length': context,
            'max_completion_tokens': min(8192, max(1, context - 512)),
            'supported_parameters': parameters, 'reasoning': None}


def migration_fields(saved, metadata, encrypted_key, now):
    """Change only the AI settings document; preserve all other collections."""
    return {**copy.deepcopy(metadata),
            'model_profiles': {name: copy.deepcopy(metadata) for name in ('kaligpt', 'deepdark', 'rsvx7-ai')},
            'provider_secret': encrypted_key,
            'model_revision': int(saved.get('model_revision') or 0) + 1,
            'connection_revision': int(saved.get('connection_revision') or 0) + 1,
            'updated_at': now, 'connection_updated_at': now}
