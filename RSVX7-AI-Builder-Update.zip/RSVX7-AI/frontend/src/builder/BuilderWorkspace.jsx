import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Code2, Eye, MessageSquare, Download, Save, FolderCode, ArrowLeft, Menu, Settings2, LoaderCircle, Play, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useChat } from '@/context/ChatContext';
import { useBuilderProjects } from './BuilderProjectsContext';
import { useTokens } from '@/context/TokensContext';
import { LanguageSwitcher, useI18n } from '@/i18n';
import { registerTranslations } from '@/i18n/runtime';
import ThemeSwitcher from '@/components/design/ThemeSwitcher';
import ChatInput from '@/components/chat/ChatInput';
import Markdown from '@/components/chat/Markdown';
import { createRuntime } from './runtime';
import { formatChatError } from './generated-runtime';
import { createRequestId } from './requestId';
import { generationProgress } from './generationProgress';
import PreviewFrame from './PreviewFrame';
import { BuildProgress } from './generated-widgets';
import CodeEditor from './CodeEditor';
import QuestionForm from './QuestionForm';
import ModelPicker, { DEFAULT_MODEL_ID } from '@/components/chat/ModelPicker';
import './builder.css';

registerTranslations('builder', { 'المحادثة': 'Chat', 'الكود': 'Code', 'المعاينة': 'Preview', 'تنزيل المشروع': 'Download project', 'حفظ': 'Save', 'إنشاء مشروعك': 'Build your project', 'صف الفكرة، ثم راجع التصور قبل التنفيذ.': 'Describe your idea, then review the proposal before building.', 'اعتماد وبدء التنفيذ': 'Approve and build', 'مراجعة التصور': 'Review proposal', 'إعادة الفحص': 'Run checks', 'تعديلات غير محفوظة': 'Unsaved changes', 'اختر ملفًا': 'Select a file', 'لا توجد ملفات بعد': 'No files yet', 'العودة إلى الدردشة': 'Back to chat', 'تعديل التصور': 'Revise proposal', 'جارٍ فتح المشروع…': 'Opening project…', 'إعادة المحاولة': 'Retry', 'مناقشة تعديل': 'Discuss changes', 'فتح القائمة': 'Open menu', 'الإعدادات': 'Settings', 'إغلاق': 'Close', 'ملفات المشروع': 'Project files', 'جارٍ العمل على المشروع': 'Working on the project', 'جارٍ تجهيز المعاينة': 'Preparing preview', 'فشلت بعض الفحوص. راجع النتائج أو اطلب من Builder إصلاح المشروع.': 'Some checks failed. Review the results or ask Builder to fix the project.' });
const empty = { revision: 0, files: {}, messages: [], checks: [], darkMode: true, phase: 'planning' };
registerTranslations('builder', { 'تعذّر بدء الإصلاح. أعد المحاولة يدويًا.': 'Repair could not start. Retry it manually.', 'الطلب والمرفقات يتجاوزان الحد الأقصى 20000 حرف. قلّل النص أو المرفقات ثم أعد الإرسال.': 'The request and attachments exceed the 20000 character limit. Shorten the text or attachments and send again.' });

export default function BuilderWorkspace({ onOpenSidebar, onOpenSettings, sidebarOpen = false, active = true }) {
  const { user, authFetch } = useAuth();
  const chat = useChat();
  const builderProjects = useBuilderProjects();
  const { refresh: refreshBalance } = useTokens();
  const { t, dir } = useI18n('builder');
  const tRef = useRef(t); tRef.current = t;
  const pid = builderProjects.activeId;
  const { loading: projectsLoading, error: projectsError, projects: builderList, select: selectProject, create: createProject, refresh: refreshProjects, registerSelectionGuard } = builderProjects;
  const creatingRef = useRef(false);
  useEffect(() => {
    if (!active || projectsLoading || projectsError || pid || creatingRef.current) return;
    if (builderList.length) { selectProject(builderList[0]._id); return; }
    creatingRef.current = true;
    createProject().catch((e) => setError(e.message)).finally(() => { creatingRef.current = false; });
  }, [active, projectsLoading, projectsError, pid, builderList, selectProject, createProject]);
  const [data, setData] = useState(empty), dataRef = useRef(empty);
  const [loading, setLoading] = useState(true), [submitting, setSubmitting] = useState(false), [error, setError] = useState('');
  const [tab, setTab] = useState('chat'), [selected, setSelected] = useState(''), [dirty, setDirty] = useState(false);
  const [build, setBuild] = useState({ phase: 'idle', checks: [], files: 0, attempt: 0 });
  const [darkMode, setDarkMode] = useState(true);
  const dirtyRef = useRef(false), inFlight = useRef(false), messagesRef = useRef(null), stickToLatest = useRef(true);
  const loadSequence = useRef(0), pendingRequest = useRef(null);
  const submission = useRef(null), stopping = useRef(false), submissionError = useRef('');
  const pendingSave = useRef(null);
  const handledCompletion = useRef('');
  const controller = useRef(null), runRef = useRef(null), applied = useRef(-1), repairNext = useRef(false), handledError = useRef(''), scope = useRef(0);
  const request = useCallback(async (path, options) => {
    const response = await authFetch('/builder/projects/' + encodeURIComponent(pid) + path, options);
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(typeof result.detail === 'string' ? result.detail : result.detail?.message || 'تعذّر إكمال الطلب.');
    return result;
  }, [authFetch, pid]);
  const load = useCallback(async () => {
    const epoch = scope.current;
    const sequence = ++loadSequence.current;
    const result = await request('?filesRevision=' + dataRef.current.revision);
    if (epoch !== scope.current || sequence !== loadSequence.current) return;
    if (dirtyRef.current && result.revision !== dataRef.current.revision) throw new Error('تغيّر المشروع في نافذة أخرى. نزّل تعديلاتك قبل إعادة التحميل.');
    const next = { ...dataRef.current, ...result };
    dataRef.current = next; setData(next); setLoading(false);
    return next;
  }, [request]);
  useEffect(() => {
    if (!pid) return;
    const epoch = ++scope.current;
    stickToLatest.current = true;
    inFlight.current = false; submission.current = null; stopping.current = false; pendingRequest.current = null; repairNext.current = false; setSubmitting(false); setBuild({ phase: 'idle', checks: [], files: 0, attempt: 0 });
    setLoading(true); setError(''); setDirty(false); dirtyRef.current = false; setSelected(''); applied.current = -1; handledError.current = ''; handledCompletion.current = '';
    dataRef.current = { ...empty, revision: -1 }; setData(empty);
    const session = createRuntime(state => {
      if (scope.current !== epoch) return;
      setBuild(state);
      if (['ready', 'failed'].includes(state.phase) && state.checks?.length === 7 && state.checks.some(c => c.status === 'passed' || c.status === 'failed')) {
        void request('/checks', { method: 'POST', body: JSON.stringify({ revision: dataRef.current.revision, checks: state.checks }) }).catch(() => {});
      }
    }, async repair => {
      if (scope.current !== epoch) return;
      if (!dataRef.current.approvedPlan) { session.runtime.pause(tRef.current('فشلت بعض الفحوص. راجع النتائج أو اطلب من Builder إصلاح المشروع.')); return; }
      const accepted = await runRef.current?.('repair', repair.prompt, undefined, {
        repairContext: { step: repair.step, diagnostic: repair.diagnostic, automatic: repair.automatic === true, affectedFiles: repair.affectedFiles || [] },
      });
      if (!accepted && scope.current === epoch && !stopping.current) {
        repairNext.current = false;
        const message = submissionError.current || tRef.current('تعذّر بدء الإصلاح. أعد المحاولة يدويًا.');
        setError(message); session.runtime.pause(message);
      }
    });
    controller.current = session;
    let disposed = false, timer, initializedDark = false;
    const poll = async () => {
      try {
        const next = inFlight.current || stopping.current || pendingSave.current?.epoch === epoch ? null : await load();
        if (next && scope.current === epoch && !stopping.current) {
          session.runtime.restoreRepairState(next.repairState);
          if (!initializedDark) { initializedDark = true; setDarkMode(next.darkMode !== false); }
          if (next.job?.status === 'running' && next.job.mode === 'build' && ['idle', 'stopped'].includes(session.runtime.state.get().phase)) session.runtime.beginTask(true, next.job.request?.action === 'repair');
          if (next.job?.status === 'failed' && handledError.current !== next.job.id) {
            const legacyFormatFailure = ['لم يرسل أحد الوكلاء ملفات أو تقريرًا صالحًا.', 'تعذّر قراءة مخرجات البرمجة أو المراجعة.'].some(prefix => next.job.error?.startsWith(prefix));
            const message = legacyFormatFailure
              ? formatChatError('DF_CHAT_ERROR:{"code":"file_format"}')
              : next.job.error?.startsWith('DF_CHAT_ERROR:') ? formatChatError(next.job.error) : next.job.error;
            handledError.current = next.job.id; setError(message); void refreshProjects().catch(() => {});
            if (next.job.mode === 'build') session.runtime.pause(message);
          }
          if (next.job?.status === 'completed' && handledCompletion.current !== next.job.id) {
            handledCompletion.current = next.job.id; setError(''); void refreshProjects().catch(() => {});
          }
          if (next.job?.status !== 'running' && next.revision !== applied.current && Object.keys(next.files || {}).length) {
            applied.current = next.revision;
            setSelected(previous => next.files[previous] ? previous : Object.keys(next.files)[0]);
            void session.apply(next.files, repairNext.current, next.repairState); repairNext.current = false;
          }
        }
      } catch (e) { if (!disposed) { setError(e.message); setLoading(false); } }
      if (!disposed) timer = setTimeout(poll, dataRef.current.job?.status === 'running' ? 1500 : 6000);
    };
    poll();
    return () => { disposed = true; scope.current = epoch + 1; clearTimeout(timer); session.dispose(); controller.current = null; };
  }, [pid, user?._id, request, load, refreshProjects]);
  useEffect(() => {
    const element = messagesRef.current;
    if (element && stickToLatest.current) element.scrollTop = element.scrollHeight;
  }, [data.messages.length, pid]);
  const busy = submitting || data.job?.status === 'running';
  const displayedBuild = generationProgress(build, data.job, data.revision);
  const displayedError = error || projectsError;
  const save = useCallback(async () => {
    const epoch = scope.current;
    if (pendingSave.current?.epoch === epoch) return pendingSave.current.operation;
    const operation = (async () => {
      while (dirtyRef.current) {
        ++loadSequence.current;
        const files = dataRef.current.files;
        const result = await request('/files', { method: 'PUT', body: JSON.stringify({ revision: dataRef.current.revision, files }) });
        if (epoch !== scope.current) throw new Error('تغيّر المشروع المفتوح.');
        ++loadSequence.current;
        const next = { ...dataRef.current, revision: result.revision, repairState: result.repairState || { automaticAttempts: 0, fingerprints: [] } };
        dataRef.current = next; setData(next);
        // Edits made during the PUT still need saving at the new revision.
        dirtyRef.current = next.files !== files; setDirty(dirtyRef.current);
        applied.current = result.revision;
      }
      return dataRef.current.revision;
    })();
    pendingSave.current = { epoch, operation };
    try { return await operation; }
    finally { if (pendingSave.current?.operation === operation) pendingSave.current = null; }
  }, [request]);
  useEffect(() => {
    if (!pid || !registerSelectionGuard) return;
    const epoch = scope.current;
    return registerSelectionGuard(async () => {
      if (epoch !== scope.current) return false;
      try { await save(); return epoch === scope.current; }
      catch (e) { if (epoch === scope.current) setError(e.message); return false; }
    });
  }, [pid, user?._id, request, load, refreshProjects, registerSelectionGuard, save]);
  function run(...args) {
    if (!pid || inFlight.current || stopping.current || dataRef.current.job?.status === 'running') return Promise.resolve(false);
    const operation = submitRun(...args);
    submission.current = operation;
    void operation.then(() => { if (submission.current === operation) submission.current = null; });
    return operation;
  }
  async function submitRun(action, text = '', proposalId, extra = {}) {
    if (Array.from(text).length > 20000) {
      setError(tRef.current('الطلب والمرفقات يتجاوزان الحد الأقصى 20000 حرف. قلّل النص أو المرفقات ثم أعد الإرسال.'));
      return false;
    }
    const epoch = scope.current;
    inFlight.current = true;
    ++loadSequence.current;
    submissionError.current = ''; setSubmitting(true); setError('');
    try {
      const revision = await save();
      if (epoch !== scope.current) return false;
      const payload = { revision, action, text, proposalId, darkMode, ...extra,
        personality: chat.prefs?.modelId || DEFAULT_MODEL_ID, deepThink: !!chat.prefs?.deepThink,
        autoSuffix: chat.prefs?.autoSuffix?.enabled ? chat.prefs.autoSuffix.text || '' : '' };
      const signature = JSON.stringify(payload);
      if (pendingRequest.current?.signature !== signature) pendingRequest.current = { signature, id: createRequestId() };
      const result = await request('/run', { method: 'POST', body: JSON.stringify({ ...payload, requestId: pendingRequest.current.id }) });
      if (epoch !== scope.current) return false;
      pendingRequest.current = null;
      ++loadSequence.current;
      dataRef.current = { ...dataRef.current, job: result.job }; setData(dataRef.current);
      if (result.job?.mode === 'build' && !stopping.current) {
        const repairing = result.job.request?.action === 'repair' || action === 'repair';
        repairNext.current = repairing;
        controller.current?.runtime.beginTask(true, repairing);
      }
      // An accepted job survives a refresh error. Never ask the composer/form
      // to resend a request that the server has already accepted.
      // Do not hold Stop behind this optional refresh after acceptance.
      void load().catch(e => { if (epoch === scope.current && !stopping.current) setError(e.message); });
      void refreshProjects().catch(() => {});
      return true;
    } catch (e) { if (epoch === scope.current) { submissionError.current = e.message; setError(e.message); } return false; }
    finally { if (epoch === scope.current) { inFlight.current = false; setSubmitting(false); void refreshBalance(); } }
  }
  runRef.current = run;
  useEffect(() => { if (data.job?.status && data.job.status !== 'running') void refreshBalance(); }, [data.job?.status, refreshBalance]);
  async function stop() {
    const epoch = scope.current;
    if (stopping.current) return;
    stopping.current = true;
    ++loadSequence.current;
    controller.current?.stop();
    try {
      // A cancel sent before /run is accepted can miss the job entirely.
      await submission.current;
      if (epoch !== scope.current) return;
      controller.current?.stop();
      await request('/cancel', { method: 'POST', body: '{}' });
      if (epoch !== scope.current) return;
      await load();
      if (epoch === scope.current) applied.current = dataRef.current.revision;
    } catch (e) { if (epoch === scope.current) setError(e.message); }
    finally { if (epoch === scope.current) stopping.current = false; }
  }
  const verify = async () => {
    const epoch = scope.current;
    try { await save(); if (epoch !== scope.current) return; await controller.current?.apply(dataRef.current.files, false, dataRef.current.repairState); } catch (e) { if (epoch === scope.current) setError(e.message); }
  };
  async function download() {
    try {
      const { default: JSZip } = await import('jszip'); const zip = new JSZip();
      for (const [path, file] of Object.entries(dataRef.current.files)) zip.file(path.replace('/home/project/', ''), file.content, { base64: file.isBinary });
      const url = URL.createObjectURL(await zip.generateAsync({ type: 'blob' })); const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'rsvx7-project.zip'; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) { setError(e.message); }
  }
  const composer = { sendMessage: (text, files) => run('message', files.length ? files.filter(f => f.status === 'ready').map(f => `Reference file ${f.name}:\n${f.text}`).join('\n\n') + '\n\n' + text : text),
    isStreaming: busy, messagesLoading: loading, saveErrors: [], stop, webSearchSupported: false,
    activeChat: { darkMode, messagesLoaded: !loading }, activateDarkMode: () => setDarkMode(true), deactivateDarkMode: () => setDarkMode(false) };
  const draftFiles = data.job?.status === 'running' && data.job.mode === 'build' ? data.job.draftFiles : null;
  const visibleFiles = draftFiles || data.files || {};
  const entries = Object.entries(visibleFiles);
  const visibleSelected = visibleFiles[selected] ? selected : entries[0]?.[0] || '';
  const current = visibleFiles[visibleSelected];
  return <section className="chat-main builder-workspace" dir={dir} data-testid="builder-workspace">
    <PreviewFrame state={build} runtime={controller.current?.runtime} verification />
    <header className="chat-topbar builder-topbar">
      <div className="chat-topbar-side">{!sidebarOpen && <button className="chat-icon-button" onClick={onOpenSidebar} aria-label={t('فتح القائمة')} data-testid="builder-open-sidebar-btn"><Menu size={18} /></button>}<span className="builder-badge"><Code2 size={16} />Builder</span><span className="builder-project-name" dir="auto" data-testid="builder-project-name">{builderList.find((p) => p._id === pid)?.name || data.projectName}</span></div>
      <div className="chat-topbar-side"><button className="chat-icon-button" onClick={onOpenSettings} aria-label={t('الإعدادات')} data-testid="builder-settings-btn"><Settings2 size={17} /></button><LanguageSwitcher /><ThemeSwitcher /></div>
    </header>
    <div className="builder-toolbar"><div className="builder-tabs" role="tablist" aria-label="Builder">
      {[['chat', 'المحادثة', MessageSquare], ['code', 'الكود', Code2], ['preview', 'المعاينة', Eye]].map(([id, label, Icon], index) => <button key={id} type="button" role="tab" id={`builder-tab-${id}`} aria-controls={`builder-panel-${id}`} aria-selected={tab === id} tabIndex={tab === id ? 0 : -1} onClick={() => setTab(id)} onKeyDown={event => {
        const tabs = ['chat', 'code', 'preview'];
        const forward = dir === 'rtl' ? 'ArrowLeft' : 'ArrowRight';
        const backward = dir === 'rtl' ? 'ArrowRight' : 'ArrowLeft';
        const next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : event.key === forward ? (index + 1) % tabs.length : event.key === backward ? (index - 1 + tabs.length) % tabs.length : -1;
        if (next < 0) return;
        event.preventDefault(); setTab(tabs[next]); document.getElementById(`builder-tab-${tabs[next]}`)?.focus();
      }} data-testid={`builder-tab-${id}`}><Icon size={16} aria-hidden="true" /><span>{t(label)}</span></button>)}
    </div><div className="builder-toolbar-actions">{data.approvedPlan && <button disabled={busy} title={t('مناقشة تعديل')} aria-label={t('مناقشة تعديل')} onClick={() => run('discuss', 'أريد مناقشة تعديل على المشروع الحالي. اسألني عن التعديل قبل تغيير الملفات.')} data-testid="builder-discuss-btn"><MessageSquare size={17} /></button>}<button onClick={download} data-testid="builder-download-btn" disabled={!Object.keys(data.files || {}).length} title={t('تنزيل المشروع')} aria-label={t('تنزيل المشروع')}><Download size={17} /></button><button onClick={verify} data-testid="builder-run-checks-btn" disabled={busy || !entries.length} title={t('إعادة الفحص')} aria-label={t('إعادة الفحص')}><Play size={16} /></button><button data-testid="builder-back-btn" onClick={() => { window.location.hash = '#chat'; }} title={t('العودة إلى الدردشة')} aria-label={t('العودة إلى الدردشة')}><ArrowLeft size={17} /></button></div></div>
    {displayedError && <div className="builder-error" role="alert" data-testid="builder-error"><span>{displayedError}</span>{(projectsError || ['failed', 'cancelled'].includes(data.job?.status)) && !busy && <button className="builder-retry" data-testid="builder-retry-btn" onClick={() => projectsError && !error ? void refreshProjects().catch(() => {}) : run('retry')}>{t('إعادة المحاولة')}</button>}{error && <button aria-label={t('إغلاق')} data-testid="builder-error-close-btn" onClick={() => setError('')}><X size={16} /></button>}</div>}
    {loading || !pid ? <div className="builder-loading" role="status"><LoaderCircle className="animate-spin" size={20} />{t('جارٍ فتح المشروع…')}</div> : <>
      <div className="builder-body" data-view={tab}>
        <div className="builder-chat-pane" role="tabpanel" id="builder-panel-chat" aria-labelledby="builder-tab-chat">
          <div className="builder-messages" role="log" aria-label={t('المحادثة')} aria-busy={busy} ref={messagesRef} onScroll={event => { const el = event.currentTarget; stickToLatest.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120; }}>
            {!data.messages.length && <div className="builder-welcome"><FolderCode size={38} /><h1>{t('إنشاء مشروعك')}</h1><p>{t('صف الفكرة، ثم راجع التصور قبل التنفيذ.')}</p></div>}
            {data.messages.map(message => <article key={message.id} className={'builder-message ' + message.role}>
              {message.content && <Markdown>{message.content}</Markdown>}
              {message.plan?.kind === 'questions' && <QuestionForm key={[user?._id, pid, message.id].join(':')} questions={message.plan.questions}
                draftKey={[user?._id, pid, message.id].join(':')}
                initialAnswers={[...data.messages].reverse().find(m => m.questionMessageId === message.id)?.questionAnswers}
                disabled={busy || message.id !== data.proposalId || data.plan?.kind !== 'questions'}
                onSubmit={answers => run('answers', '', undefined, { questionMessageId: message.id, answers })} />}
              {message.plan?.kind === 'proposal' && <div className="builder-plan"><h2>{message.plan.title}</h2><p>{message.plan.summary}</p><div className="builder-plan-pages">{message.plan.pages.map(p => <div key={p.name}><strong>{p.name}</strong><small>{p.purpose}</small></div>)}</div><ul>{message.plan.features.map(f => <li key={f}>{f}</li>)}</ul><p>{message.plan.design}</p>{message.id === data.proposalId && !data.approvedPlan && <button className="builder-primary" data-testid="builder-approve-btn" disabled={busy} onClick={() => run('approve', '', message.id)}>{t('اعتماد وبدء التنفيذ')}</button>}</div>}
            </article>)}
            {data.job?.status === 'running' && data.job.mode === 'planning' && <div className="builder-planning" role="status"><LoaderCircle size={16} className="animate-spin" />{t('مراجعة التصور')}</div>}
          </div>
          {displayedBuild.phase !== 'idle' && <BuildProgress state={displayedBuild} onStop={stop} onRetry={() => ['failed', 'cancelled'].includes(data.job?.status) ? run('retry') : controller.current?.runtime.canRetryRepair ? controller.current.runtime.requestRepair() : controller.current?.runtime.canRetryPreview ? controller.current.runtime.retryPreview() : verify()} onRepair={controller.current?.runtime.canRequestRepair || controller.current?.runtime.canRetryRepair ? () => controller.current?.runtime.requestRepair() : undefined} onPreview={() => setTab('preview')} />}
          <div className="builder-composer" data-testid="builder-composer"><div className="builder-composer-meta"><ModelPicker value={chat.prefs?.modelId || DEFAULT_MODEL_ID} onChange={chat.setModel} models={chat.aiModels || data.models} disabled={busy} /><span className="builder-model" dir="ltr" data-testid="builder-model-label">{busy && data.job?.model ? data.job.model : chat.aiModel || data.models?.[chat.prefs?.modelId]?.model || data.model}</span></div><ChatInput controller={composer} active={active} /></div>
        </div>
        <div className="builder-code-pane" role="tabpanel" id="builder-panel-code" aria-labelledby="builder-tab-code" hidden={tab !== 'code'}>
          <nav className="builder-files" aria-label={t('ملفات المشروع')} data-testid="builder-file-list">{entries.length ? entries.map(([path]) => <button key={path} className={visibleSelected === path ? 'active' : ''} aria-current={visibleSelected === path ? 'true' : undefined} title={path.replace('/home/project/', '')} onClick={() => setSelected(path)} dir="ltr" data-testid={`builder-file-${path.replace('/home/project/', '').replace(/[^a-zA-Z0-9]+/g, '-')}`}><Code2 size={13} />{path.replace('/home/project/', '')}</button>) : <span>{t('لا توجد ملفات بعد')}</span>}</nav>
          <div className="builder-editor-pane"><div className="builder-editor-toolbar"><span dir="ltr">{visibleSelected.replace('/home/project/', '')}</span><button data-testid="builder-save-btn" disabled={!dirty || busy || !!draftFiles} onClick={() => { const epoch = scope.current; void save().catch(e => { if (epoch === scope.current) setError(e.message); }); }}><Save size={15} />{t('حفظ')}</button></div>{dirty && <div className="builder-unsaved" role="status">{t('تعديلات غير محفوظة')}</div>}{current && !current.isBinary ? <CodeEditor path={visibleSelected} value={current.content} disabled={busy || !!draftFiles} onChange={value => { if (busy || draftFiles) return; const next = { ...dataRef.current, files: { ...dataRef.current.files, [visibleSelected]: { ...dataRef.current.files[visibleSelected], content: value } } }; dataRef.current = next; setData(next); setDirty(true); dirtyRef.current = true; controller.current?.runtime.invalidateChecks(); }} /> : <div className="builder-placeholder">{t('اختر ملفًا')}</div>}</div>
        </div>
        <div className="builder-preview-pane" role="tabpanel" id="builder-panel-preview" aria-labelledby="builder-tab-preview" hidden={tab !== 'preview'}>{build.previewUrl ? <PreviewFrame state={build} runtime={controller.current?.runtime} title={t('المعاينة')} /> : <div className="builder-placeholder"><Eye size={32} /><p>{t('المعاينة')}</p>{entries.length > 0 && <button className="builder-primary" data-testid="builder-preview-run-btn" disabled={busy} onClick={verify}>{t('إعادة الفحص')}</button>}</div>}{build.phase !== 'idle' && build.phase !== 'ready' && <div className="builder-preview-status">{build.message || t(busy ? 'جارٍ العمل على المشروع' : 'جارٍ تجهيز المعاينة')}</div>}</div>
      </div>
    </>}
  </section>;
}
