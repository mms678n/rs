import React, { useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useI18n } from '@/i18n';
import { registerTranslations } from '@/i18n/runtime';
import { Panel, StatusNote } from '@/components/design/Primitives';
import { Button } from '@/components/ui/button';

const labels = { offline: 'خدمة التحديث متوقفة', queued: 'بانتظار التحديث', fetch: 'جلب الإصدار', validate: 'فحص الملفات', build: 'بناء التحديث', restart: 'تشغيل الإصدار', verify: 'فحص التشغيل', ready: 'جاهز', current: 'أنت على آخر إصدار', restored: 'تعذّر التحديث؛ استُعيد الإصدار السابق', restore_failed: 'تعذّر التشغيل؛ راجع السيرفر', interrupted: 'انقطع التحديث؛ أعد المحاولة', failed: 'تعذّر التحديث؛ راجع سجل السيرفر' };
registerTranslations('platform-update', { 'تحديث المنصة': 'Update platform', 'ربط GitHub': 'Connect GitHub', 'خدمة التحديث متوقفة': 'Update service is offline', 'أكمل الربط مرة واحدة حسب OPERATIONS.txt داخل الحزمة.': 'Complete the one-time setup in OPERATIONS.txt included in the package.', 'التحديث يعيد تشغيل الموقع وقد يقطع المهام الجارية.': 'Updating restarts the site and may interrupt active tasks.', 'تعذّر الاتصال. أعد فتح الصفحة بعد إعادة تشغيل الموقع.': 'Connection lost. Reopen the page after the site restarts.', 'جلب الإصدار': 'Fetching release', 'فحص الملفات': 'Checking files', 'بناء التحديث': 'Building update', 'تشغيل الإصدار': 'Starting release', 'فحص التشغيل': 'Checking startup', 'جاهز': 'Ready', 'بانتظار التحديث': 'Update queued', 'أنت على آخر إصدار': 'Already up to date', 'تعذّر التحديث؛ استُعيد الإصدار السابق': 'Update failed; previous release restored', 'تعذّر التشغيل؛ راجع السيرفر': 'Startup failed; check the server', 'انقطع التحديث؛ أعد المحاولة': 'Update interrupted; retry', 'تعذّر التحديث؛ راجع سجل السيرفر': 'Update failed; check the server log' });

export default function PlatformUpdate() {
  const { authFetch } = useAuth(), { t } = useI18n('platform-update');
  const [state, setState] = useState(null), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  useEffect(() => {
    let active = true, timer;
    const poll = async () => {
      try {
        const response = await authFetch('/admin/platform-update');
        if (!response.ok) throw new Error();
        const value = await response.json();
        if (active) { setState(value); setError(''); }
      } catch { if (active) setError(t('تعذّر الاتصال. أعد فتح الصفحة بعد إعادة تشغيل الموقع.')); }
      if (active) timer = setTimeout(poll, 4000);
    };
    poll();
    return () => { active = false; clearTimeout(timer); };
  }, [authFetch, t]);
  const update = async () => {
    setBusy(true); setError('');
    try {
      const response = await authFetch('/admin/platform-update', { method: 'POST', body: '{}' });
      const value = await response.json();
      if (!response.ok) throw new Error(value.detail);
      setState(value);
    } catch (e) { setError(e.message || t('تعذّر الاتصال. أعد فتح الصفحة بعد إعادة تشغيل الموقع.')); }
    finally { setBusy(false); }
  };
  const running = ['pending', 'running'].includes(state?.status);
  return <Panel className="admin-content-card vps-card" data-testid="platform-update">
    <div className="vps-row"><h3><RefreshCw size={18} />{t('تحديث المنصة')}</h3>
      <Button data-testid="platform-update-start" disabled={!state?.configured || state?.status === 'offline' || running || busy} onClick={update}><RefreshCw size={15} className={running ? 'animate-spin' : ''} />{t('تحديث المنصة')}</Button></div>
    {state?.configured ? <><code dir="ltr">{state.repository} · {state.branch}{state.commit ? ' · ' + state.commit.slice(0, 12) : ''}</code><span role="status">{t(labels[state.stage] || 'جاهز')}</span><small>{t('التحديث يعيد تشغيل الموقع وقد يقطع المهام الجارية.')}</small></> : <small>{t('أكمل الربط مرة واحدة حسب OPERATIONS.txt داخل الحزمة.')}</small>}
    {error && <StatusNote tone="error">{error}</StatusNote>}
  </Panel>;
}
