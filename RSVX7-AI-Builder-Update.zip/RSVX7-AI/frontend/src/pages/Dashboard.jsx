import MonthlyPricing from "@/components/MonthlyPricing";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import Logo from "@/components/chat/Logo";
import {
  ActionButton,
  EmptyState,
  LoadingState,
  MetricCard,
  PageShell,
  Panel,
  StatusNote,
} from "@/components/design/Primitives";
import {
  ArrowLeft,
  Check,
  Clock3,
  Coins,
  Copy,
  Gift,
  KeyRound,
  LogOut,
  RefreshCw,
  ShieldCheck,
  Ticket,
  TrendingDown,
  TrendingUp,
  Users,
} from "lucide-react";
import { copyToClipboard } from "@/lib/clipboard";
import { LanguageSwitcher, useI18n } from "@/i18n";
import ThemeSwitcher from "@/components/design/ThemeSwitcher";
import { TelegramLinking } from "@/components/TelegramGate";
import { navigateTabs } from "@/lib/tabNavigation";
import "@/i18n/catalogs/account";
import "./dashboard-ui.css";

const BACKEND = process.env.REACT_APP_BACKEND_URL || "";
const FOCUS_REFRESH_WINDOW = 30_000;

function responseMessage(data, fallback) {
  if (typeof data?.detail === "string") return data.detail;
  if (typeof data?.detail?.message === "string") return data.detail.message;
  if (typeof data?.message === "string") return data.message;
  return fallback;
}

async function readResponse(r, fallback) {
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(responseMessage(data, `${fallback} (${r.status})`));
  return data;
}

function userId(user) {
  return user?._id || user?.id || null;
}

function useCreditPacks() {
  const [packs, setPacks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const requestRef = useRef(null);

  const refresh = useCallback(async () => {
    if (requestRef.current) return requestRef.current;
    const controller = new AbortController();
    const promise = fetch(`${BACKEND}/api/billing/packs`, { signal: controller.signal })
      .then((r) => readResponse(r, "تعذر تحميل حزم الرصيد"))
      .then((data) => {
        setPacks(Array.isArray(data?.packs) ? data.packs : []);
        setError("");
        return data;
      })
      .catch((e) => {
        if (e?.name !== "AbortError") setError(e?.message || "تعذر تحميل حزم الرصيد");
        return null;
      })
      .finally(() => {
        if (requestRef.current?.promise === promise) requestRef.current = null;
        setLoading(false);
      });
    requestRef.current = { controller, promise };
    setLoading(true);
    return promise;
  }, []);

  useEffect(() => {
    void refresh();
    return () => requestRef.current?.controller.abort();
  }, [refresh]);

  return { packs, loading, error, refresh };
}

function BalancePanel({ wallet, loading, error, onRetry, onRefresh, lastUpdated, isAdmin }) {
  const { t, formatNumber, formatDate } = useI18n("account");
  const balance = wallet?.token_balance ?? (isAdmin ? -1 : null);
  return (
    <Panel className="dashboard-wallet" data-testid="dashboard-wallet-card">
      <div className="dashboard-wallet-main">
        <div>
          <p className="dashboard-eyebrow"><Coins size={16} aria-hidden="true" /> {t("رصيد التوكنات")}</p>
          <div className="dashboard-balance" data-testid="wallet-balance" dir="ltr">
            {balance === null && loading ? <span className="dashboard-placeholder">—</span> : (balance === -1 ? "∞" : formatNumber(balance))}
          </div>
          <p className="dashboard-muted">{t("رصيد الشحن محفوظ حتى تستخدمه. الرصيد الشهري ينتهي بنهاية الفترة.")}</p>
          {lastUpdated && <p className="dashboard-updated">{t("آخر تحقق: {date}", { date: formatDate(lastUpdated) })}</p>}
        </div>
        <ActionButton
          tone="ghost"
          loading={loading}
          onClick={onRefresh}
          aria-label={t("تحديث الرصيد")}
          data-testid="dashboard-balance-refresh"
        >
          <RefreshCw size={16} aria-hidden="true" /> {t("تحديث")}
        </ActionButton>
      </div>
      {error && (
        <StatusNote tone="error" onRetry={onRetry} className="dashboard-inline-note">
          {t(error)}
        </StatusNote>
      )}
      {loading && <LoadingState compact label={t("جارٍ التحقق من الرصيد…")} />}
    </Panel>
  );
}

function UsageSection({ wallet, user }) {
  const { t, formatNumber } = useI18n("account");
  const source = wallet || user || {};
  return (
    <section className="dashboard-section" aria-labelledby="usage-heading">
      <div className="dashboard-section-heading">
        <div>
          <h2 id="usage-heading">{t("الاستخدام")}</h2>
          <p className="dashboard-muted">{t("الإجمالي المسجل من الخادم، وليس تقديرًا محليًا.")}</p>
        </div>
      </div>
      <div className="dashboard-metrics-grid">
        <div data-testid="stat-used"><MetricCard label={t("التوكنات المستخدمة")} value={formatNumber(source.total_used_tokens || 0)} detail={t("إجمالي الاستهلاك")} icon={TrendingDown} /></div>
        <div data-testid="stat-input"><MetricCard label={t("توكنات الإدخال")} value={formatNumber(source.total_input_tokens || 0)} detail={t("ما أرسلته في المحادثات")} icon={TrendingUp} /></div>
        <div data-testid="stat-output"><MetricCard label={t("توكنات الإخراج")} value={formatNumber(source.total_output_tokens || 0)} detail={t("ما عاد من النموذج")} icon={TrendingUp} /></div>
      </div>
    </section>
  );
}

function CreditPacksSection({ packsState }) {
  const { t, formatNumber } = useI18n("account");
  const { packs, loading, error, refresh } = packsState;
  return (
    <Panel className="dashboard-panel" data-testid="credit-packs-section">
      <div className="dashboard-section-heading dashboard-section-heading-compact">
        <div>
          <p className="dashboard-eyebrow"><Coins size={16} aria-hidden="true" /> {t("شحن الرصيد")}</p>
          <h2>{t("حزم التوكنات")}</h2>
          <p className="dashboard-muted">{t("الدفع اليدوي متاح حاليًا عبر المسؤول. لا نعرض زر شراء غير مهيأ.")}</p>
        </div>
      </div>
      {loading && packs.length === 0 && <LoadingState label={t("جارٍ تحميل الحزم…")} />}
      {error && <StatusNote tone="error" onRetry={refresh}>{t(error)}</StatusNote>}
      {!loading && !error && packs.length === 0 && (
        <EmptyState title={t("لا توجد حزم متاحة الآن")} description={t("تواصل مع المسؤول لإضافة رصيد إلى محفظتك.")} icon={Coins} />
      )}
      {packs.length > 0 && (
        <div className="dashboard-pack-grid">
          {packs.map((pack) => (
            <article className="dashboard-pack" key={pack.id} data-testid={`credit-pack-${pack.id}`}>
              <p className="dashboard-pack-label">{pack.label}</p>
              <strong dir="ltr">${pack.usd}</strong>
              <span dir="ltr">{t("{count} توكن", { count: formatNumber(pack.tokens) })}</span>
              <ActionButton
                tone="ghost"
                disabled
                data-testid={`buy-pack-${pack.id}`}
                title={t("تواصل مع المسؤول لإضافة الرصيد")}
              >
                {t("تواصل مع المسؤول")}
              </ActionButton>
            </article>
          ))}
        </div>
      )}
    </Panel>
  );
}

function CouponSection({ authFetch, onBalanceChange }) {
  const { t, formatNumber } = useI18n("account");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);
  const idempotencyKeys = useRef(new Map());

  const getKey = useCallback((value) => {
    const normalized = value.trim().toUpperCase();
    let key = idempotencyKeys.current.get(normalized);
    if (!key) {
      key = typeof globalThis.crypto?.randomUUID === "function"
        ? globalThis.crypto.randomUUID()
        : `coupon-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      idempotencyKeys.current.set(normalized, key);
    }
    return key;
  }, []);

  const redeem = async (event) => {
    event.preventDefault();
    const normalized = code.trim().toUpperCase();
    if (!normalized || busy) return;
    setBusy(true);
    setError("");
    setResult(null);
    try {
      const response = await authFetch("/coupons/redeem", {
        method: "POST",
        body: JSON.stringify({ code: normalized, idempotency_key: getKey(normalized) }),
      });
      const data = await readResponse(response, "تعذر استخدام الكوبون");
      setResult(data);
      // The server has confirmed the credit (or confirmed an idempotent retry).
      // Only then refresh the wallet; never show a local success before this point.
      await onBalanceChange?.();
      idempotencyKeys.current.delete(normalized);
      setCode("");
    } catch (e) {
      if (e?.name !== "AbortError") setError(e?.message || "تعذر استخدام الكوبون");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="dashboard-section" aria-labelledby="coupon-heading">
      <Panel className="dashboard-panel">
        <div className="dashboard-section-heading dashboard-section-heading-compact">
          <div>
            <p className="dashboard-eyebrow"><Ticket size={16} aria-hidden="true" /> {t("كوبون الرصيد")}</p>
            <h2 id="coupon-heading">{t("أضف التوكنات من رمز موثوق")}</h2>
            <p className="dashboard-muted">{t("كل طلب يحمل مفتاحًا ثابتًا لإعادة المحاولة دون إضافة الرصيد مرتين.")}</p>
          </div>
        </div>
        <form className="ds-form-stack dashboard-coupon-form" onSubmit={redeem}>
          <label className="ds-field" htmlFor="dashboard-coupon-code">
            <span>{t("رمز الكوبون")}</span>
            <input
              id="dashboard-coupon-code"
              className="ds-input dashboard-code-input"
              value={code}
              onChange={(event) => { setCode(event.target.value.toUpperCase()); setError(""); setResult(null); }}
              placeholder={t("مثال: rsvx7-…")}
              autoComplete="off"
              dir="ltr"
              data-testid="coupon-code"
            />
          </label>
          <ActionButton tone="primary" type="submit" loading={busy} disabled={!code.trim()} data-testid="coupon-submit">
            {t("استخدام الكوبون")}
          </ActionButton>
        </form>
        {error && <StatusNote tone="error" className="dashboard-inline-note">{t(error)}</StatusNote>}
        {result && (
          <div data-testid="coupon-result">
            <StatusNote tone="success" className="dashboard-inline-note">
              {result.idempotent
                ? t("تم التحقق من عملية الكوبون السابقة؛ لم يُضف الرصيد مرتين.")
                : t("تمت إضافة {tokens} توكن إلى رصيدك.", { tokens: formatNumber(result.tokens) })}
            </StatusNote>
          </div>
        )}
      </Panel>
    </section>
  );
}

function ReferralsSection({ authFetch }) {
  const { t, formatNumber } = useI18n("account");
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [copyState, setCopyState] = useState("");
  const requestRef = useRef(null);

  const load = useCallback(async () => {
    if (requestRef.current) return requestRef.current;
    const controller = new AbortController();
    const promise = authFetch("/referrals/me", { signal: controller.signal })
      .then((r) => readResponse(r, "تعذر تحميل الدعوات"))
      .then((data) => { setInfo(data); setError(""); return data; })
      .catch((e) => {
        if (e?.name !== "AbortError") setError(e?.message || "تعذر تحميل الدعوات");
        return null;
      })
      .finally(() => {
        if (requestRef.current?.promise === promise) requestRef.current = null;
        setLoading(false);
      });
    requestRef.current = { controller, promise };
    setLoading(true);
    return promise;
  }, [authFetch]);

  useEffect(() => {
    void load();
    return () => requestRef.current?.controller.abort();
  }, [load]);

  const shareUrl = info && typeof window !== "undefined"
    ? `${window.location.origin}/?ref=${encodeURIComponent(info.code)}`
    : "";

  const copyValue = async (value, kind) => {
    try {
      await copyToClipboard(value);
      setCopyState(kind);
      window.setTimeout(() => setCopyState((current) => current === kind ? "" : current), 1800);
    } catch {
      setCopyState("error");
    }
  };

  if (loading && !info) return <Panel className="dashboard-panel"><LoadingState label={t("جارٍ تحميل الدعوات…")} /></Panel>;
  if (error && !info) return <Panel className="dashboard-panel"><StatusNote tone="error" onRetry={load}>{t(error)}</StatusNote></Panel>;
  if (!info) return <Panel className="dashboard-panel"><EmptyState title={t("لا توجد بيانات دعوات")} description={t("أعد المحاولة عندما تتوفر معلومات الحساب.")} icon={Gift} /></Panel>;

  return (
    <section className="dashboard-section" aria-labelledby="referrals-heading">
      <Panel className="dashboard-panel dashboard-referrals" data-testid="referrals-card">
        <div className="dashboard-section-heading dashboard-section-heading-compact">
          <div>
            <p className="dashboard-eyebrow"><Gift size={16} aria-hidden="true" /> {t("الدعوات")}</p>
            <h2 id="referrals-heading">{t("ادعُ أصدقاءك واكسب توكنات")}</h2>
            <p className="dashboard-muted">{t("تُصرف المكافأة بعد تسجيل الصديق وربط Telegram. لا تُحتسب الدعوة أكثر من مرة.")}</p>
          </div>
          <div className="dashboard-referral-bonuses">
            <span>{t("مكافأتك")} <strong dir="ltr">+{formatNumber(info.referrer_bonus)}</strong></span>
            <span>{t("للصديق")} <strong dir="ltr">+{formatNumber(info.invitee_bonus)}</strong></span>
          </div>
        </div>
        <div className="dashboard-share-row">
          <label className="ds-field dashboard-share-field" htmlFor="referral-link-input">
            <span>{t("رابط الدعوة")}</span>
            <input id="referral-link-input" className="ds-input dashboard-mono" readOnly value={shareUrl} data-testid="referral-link" dir="ltr" />
          </label>
          <ActionButton tone="primary" onClick={() => copyValue(shareUrl, "link")} data-testid="referral-copy-link">
            {copyState === "link" ? <Check size={16} aria-hidden="true" /> : <Copy size={16} aria-hidden="true" />} {copyState === "link" ? t("تم النسخ") : t("نسخ الرابط")}
          </ActionButton>
        </div>
        <div className="dashboard-referral-code">
          <span>{t("أو شارك الرمز")}</span>
          <button type="button" onClick={() => copyValue(info.code, "code")} data-testid="referral-copy-code" dir="ltr">{info.code}</button>
          {copyState === "code" && <span className="dashboard-copy-status"><Check size={14} /> {t("تم النسخ")}</span>}
          {copyState === "error" && <span className="dashboard-copy-error">{t("تعذر النسخ؛ حدده وانسخه يدويًا.")}</span>}
        </div>
        <div className="dashboard-referral-stats">
          <div><Users size={17} aria-hidden="true" /><span>{t("دعوات مكتملة")}</span><strong data-testid="referral-count" dir="ltr">{formatNumber(info.referral_count)}</strong></div>
          <div><Coins size={17} aria-hidden="true" /><span>{t("توكنات مكتسبة")}</span><strong data-testid="referral-earned" dir="ltr">{formatNumber(info.referral_tokens_earned)}</strong></div>
        </div>
        {info.was_referred && info.reward_pending && (
          <div data-testid="referral-pending-hint">
            <StatusNote tone="info" className="dashboard-inline-note">
              <span className="dashboard-note-with-icon"><Clock3 size={16} /> {t("تمت دعوتك — اربط Telegram لفتح مكافأة {count}.", { count: `+${formatNumber(info.invitee_bonus)}` })}</span>
            </StatusNote>
          </div>
        )}
        {info.was_referred && !info.reward_pending && info.rewarded_at && (
          <StatusNote tone="success" className="dashboard-inline-note">
            {t("تمت إضافة مكافأة الدعوة {count} إلى رصيدك.", { count: `+${formatNumber(info.invitee_bonus)}` })}
          </StatusNote>
        )}
      </Panel>
    </section>
  );
}

function AccountSection({ user, onChangePassword }) {
  const { t, formatDate } = useI18n("account");
  const telegram = user?.telegram || {};
  const telegramLinked = Boolean(telegram.verified);
  return (
    <section className="dashboard-section" aria-labelledby="account-heading">
      <div className="dashboard-section-heading">
        <div>
          <p className="dashboard-eyebrow">{t("الحساب والأمان")}</p>
          <h2 id="account-heading">{t("بيانات الحساب وإعدادات الدخول")}</h2>
          <p className="dashboard-muted">{t("لا نعرض أسرار الجلسة أو معرّف Telegram الكامل في الواجهة.")}</p>
        </div>
      </div>
      <div className="dashboard-account-grid">
        <Panel className="dashboard-panel">
          <div className="dashboard-account-list">
            <div><span>{t("اسم المستخدم")}</span><strong dir="auto">{user?.username || "—"}</strong></div>
            <div><span>{t("الحالة")}</span><strong className={`dashboard-status dashboard-status-${user?.status === "suspended" ? "error" : "success"}`}>{user?.status || "active"}</strong></div>
            <div><span>{t("تاريخ التسجيل")}</span><strong>{formatDate(user?.registered_at, { dateStyle: "medium", timeStyle: "short" })}</strong></div>
            <div><span>{t("آخر دخول")}</span><strong>{formatDate(user?.last_login, { dateStyle: "medium", timeStyle: "short" })}</strong></div>
            <div><span>{t("بوابة Telegram")}</span><strong className={`dashboard-status dashboard-status-${telegramLinked ? "success" : "neutral"}`}>{telegramLinked ? t("مربوطة") : t("غير مربوط · اختياري")}</strong></div>
          </div>
        </Panel>
        <Panel className="dashboard-panel dashboard-security-card">
          <ShieldCheck size={22} aria-hidden="true" />
          <div><h3>{t("كلمة المرور")}</h3><p className="dashboard-muted">{t("استخدم كلمة قوية ولا تشاركها مع أي شخص.")}</p></div>
          <ActionButton tone="ghost" onClick={onChangePassword} data-testid="dash-change-pw-btn"><KeyRound size={16} /> {t("تغيير كلمة المرور")}</ActionButton>
        </Panel>
      </div>
      <TelegramLinking />
    </section>
  );
}

function ChangePasswordDialog({ open, onClose, authFetch, activateSession, refresh }) {
  const { t } = useI18n("account");
  const [oldPw, setOldPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const dialogRef = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const previous = document.activeElement;
    const dialog = dialogRef.current;
    dialog?.querySelector('input')?.focus();
    const trap = event => {
      if (event.key !== 'Tab' || !dialog) return;
      const items = [...dialog.querySelectorAll('button:not(:disabled),input:not(:disabled),[tabindex="0"]')];
      if (!items.length) { event.preventDefault(); dialog.focus(); return; }
      const first = items[0], last = items[items.length - 1];
      if (event.shiftKey && (document.activeElement === first || !dialog.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !dialog.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', trap);
    return () => { document.removeEventListener('keydown', trap); if (previous?.isConnected) previous.focus({preventScroll:true}); };
  }, [open]);

  useEffect(() => {
    if (!open) return undefined;
    const onKeyDown = (event) => { if (event.key === "Escape" && !busy) onClose?.(); };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [busy, onClose, open]);

  if (!open) return null;

  const submit = async (event) => {
    event.preventDefault();
    if (newPw.length < 6) { setError("يجب أن تتكون كلمة المرور الجديدة من 6 أحرف على الأقل."); return; }
    setBusy(true);
    setError("");
    try {
      const response = await authFetch("/auth/change-password", {
        method: "POST",
        body: JSON.stringify({ old_password: oldPw, new_password: newPw }),
      });
      const data = await readResponse(response, "تعذر تحديث كلمة المرور");
      if (data?.token && typeof activateSession === "function") await activateSession(data.token);
      else if (typeof refresh === "function") await refresh();
      setOldPw("");
      setNewPw("");
      onClose?.();
    } catch (e) {
      setError(e?.message || "تعذر تحديث كلمة المرور");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="dashboard-dialog-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose?.(); }}>
      <section ref={dialogRef} tabIndex={-1} className="dashboard-dialog" role="dialog" aria-modal="true" aria-labelledby="change-password-title">
        <div className="dashboard-dialog-heading"><div><p className="dashboard-eyebrow">{t("الأمان")}</p><h2 id="change-password-title">{t("تغيير كلمة المرور")}</h2></div><button type="button" className="dashboard-dialog-close" onClick={onClose} disabled={busy} aria-label={t("إغلاق")}>×</button></div>
        <p className="dashboard-muted">{t("ستبقى الجلسة متصلة إذا أعاد الخادم إصدار رمز جلسة جديد.")}</p>
        <form className="ds-form-stack" onSubmit={submit}>
          <label className="ds-field" htmlFor="cp-old"><span>{t("كلمة المرور الحالية")}</span><input id="cp-old" className="ds-input" type="password" value={oldPw} onChange={(event) => setOldPw(event.target.value)} data-testid="cp-old" autoComplete="current-password" /></label>
          <label className="ds-field" htmlFor="cp-new"><span>{t("كلمة المرور الجديدة")}</span><input id="cp-new" className="ds-input" type="password" value={newPw} onChange={(event) => setNewPw(event.target.value)} data-testid="cp-new" autoComplete="new-password" /></label>
          {error && <StatusNote tone="error">{t(error)}</StatusNote>}
          <div className="dashboard-dialog-actions"><ActionButton tone="ghost" type="button" onClick={onClose} disabled={busy}>{t("إلغاء")}</ActionButton><ActionButton tone="primary" loading={busy} type="submit" data-testid="cp-submit">{t("حفظ التغيير")}</ActionButton></div>
        </form>
      </section>
    </div>
  );
}

export default function Dashboard({ onExit }) {
  const { t, dir } = useI18n("account");
  const { user, authFetch, refresh, activateSession, logout } = useAuth();
  const accountUid = userId(user);
  const isAdmin = user?.plan === "admin" || ["super_admin", "admin", "moderator", "support"].includes(user?.role);
  const [activeTab, setActiveTab] = useState("overview");
  const [showPw, setShowPw] = useState(false);
  const [wallet, setWallet] = useState(() => user ? { ...user, unlimited: isAdmin } : null);
  const [balanceLoading, setBalanceLoading] = useState(Boolean(accountUid));
  const [balanceError, setBalanceError] = useState("");
  const [lastUpdated, setLastUpdated] = useState(null);
  const balanceRequestRef = useRef(null);
  const uidRef = useRef(accountUid);
  const lastBalanceAtRef = useRef(0);
  const walletRef = useRef(wallet);
  const packsState = useCreditPacks();

  useEffect(() => { uidRef.current = accountUid; }, [accountUid]);
  useEffect(() => { walletRef.current = wallet; }, [wallet]);

  const loadBalance = useCallback(async ({ force = false } = {}) => {
    if (!accountUid) return null;
    const existing = balanceRequestRef.current;
    if (existing?.uid === accountUid) return existing.promise;
    if (!force && Date.now() - lastBalanceAtRef.current < FOCUS_REFRESH_WINDOW) return walletRef.current;
    const controller = new AbortController();
    setBalanceLoading(true);
    const promise = authFetch("/billing/balance", { signal: controller.signal })
      .then((response) => readResponse(response, "تعذر تحديث الرصيد"))
      .then((data) => {
        if (!controller.signal.aborted && uidRef.current === accountUid) {
          const next = { ...(walletRef.current || {}), ...data };
          setWallet(next);
          walletRef.current = next;
          setBalanceError("");
          setLastUpdated(new Date().toISOString());
          lastBalanceAtRef.current = Date.now();
        }
        return data;
      })
      .catch((e) => {
        if (e?.name !== "AbortError" && uidRef.current === accountUid) setBalanceError(e?.message || "تعذر تحديث الرصيد");
        return null;
      })
      .finally(() => {
        if (balanceRequestRef.current?.promise === promise) balanceRequestRef.current = null;
        if (uidRef.current === accountUid) setBalanceLoading(false);
      });
    balanceRequestRef.current = { uid: accountUid, controller, promise };
    return promise;
  }, [accountUid, authFetch]);

  useEffect(() => {
    balanceRequestRef.current?.controller.abort();
    balanceRequestRef.current = null;
    setBalanceError("");
    setLastUpdated(null);
    const initial = user ? { ...user, unlimited: isAdmin } : null;
    setWallet(initial);
    walletRef.current = initial;
    lastBalanceAtRef.current = 0;
    if (accountUid) void loadBalance({ force: true });
    else setBalanceLoading(false);
    return () => balanceRequestRef.current?.controller.abort();
  }, [accountUid, isAdmin, loadBalance, user]);

  useEffect(() => {
    const onFocus = () => { void loadBalance(); };
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [loadBalance]);

  const tabs = useMemo(() => [
    ["overview", t("الرصيد")],
    ["usage", t("الاستخدام")],
    ["coupon", t("الكوبون")],
    ["referrals", t("الدعوات")],
    ["account", t("الحساب والأمان")],
  ], [t]);
  const displayUser = wallet || user;

  return (
    <div className="dashboard-ui" dir={dir}>
      <header className="dashboard-topbar" inert={showPw || undefined}>
        <div className="dashboard-topbar-inner">
          <div className="dashboard-brand"><Logo size={34} /><div><strong dir="ltr">rsvx7 / AI</strong><span>{t("لوحة الحساب")}</span></div></div>
          <div className="dashboard-topbar-actions"><LanguageSwitcher className="dashboard-language-switcher" /><ThemeSwitcher className="dashboard-theme-switcher" />
            <ActionButton tone="ghost" onClick={onExit} data-testid="dash-back-btn"><ArrowLeft size={16} aria-hidden="true" /> {t("العودة للمحادثة")}</ActionButton>
            <ActionButton tone="ghost" onClick={logout} data-testid="dash-logout-btn"><LogOut size={16} aria-hidden="true" /> {t("تسجيل الخروج")}</ActionButton>
          </div>
        </div>
      </header>
      <PageShell className="dashboard-page" inert={showPw || undefined}>
        <header className="dashboard-account-heading">
          <div>
            <span className="dashboard-account-kicker">{t("الحساب")}</span>
            <h1>{t("إدارة الحساب")}</h1>
            <p>{t("مرحبًا {name} — الرصيد والاستخدام والأمان في مكان واحد.", { name: user?.username || "" })}</p>
          </div>
          <span className="dashboard-account-chip"><span className="dashboard-status-dot" /> {isAdmin ? t("حساب إداري") : t("حساب نشط")}</span>
        </header>
        <div className="dashboard-tabs" role="tablist" aria-label={t("أقسام لوحة الحساب")} onKeyDown={event => navigateTabs(event, dir)}>
          {tabs.map(([id, label]) => (
            <button type="button" role="tab" id={`account-tab-${id}`} aria-controls={`account-panel-${id}`} tabIndex={activeTab === id ? 0 : -1} aria-selected={activeTab === id} className={`dashboard-tab ${activeTab === id ? "is-active" : ""}`} key={id} onClick={() => setActiveTab(id)} data-testid={`dashboard-tab-${id}`}>{label}</button>
          ))}
        </div>
        {activeTab === "overview" && (
          <div className="dashboard-tab-panel" role="tabpanel" id={`account-panel-${activeTab}`} aria-labelledby={`account-tab-${activeTab}`} tabIndex={0}>
            <BalancePanel wallet={displayUser} isAdmin={isAdmin} loading={balanceLoading} error={balanceError} onRetry={() => loadBalance({ force: true })} onRefresh={() => loadBalance({ force: true })} lastUpdated={lastUpdated} />
            <UsageSection wallet={displayUser} user={user} />
            <MonthlyPricing wallet={displayUser} />
            <CreditPacksSection packsState={packsState} />
          </div>
        )}
        {activeTab === "usage" && <div className="dashboard-tab-panel" role="tabpanel" id={`account-panel-${activeTab}`} aria-labelledby={`account-tab-${activeTab}`} tabIndex={0}><UsageSection wallet={displayUser} user={user} /></div>}
        {activeTab === "coupon" && <div className="dashboard-tab-panel" role="tabpanel" id={`account-panel-${activeTab}`} aria-labelledby={`account-tab-${activeTab}`} tabIndex={0}><CouponSection authFetch={authFetch} onBalanceChange={() => loadBalance({ force: true })} /></div>}
        {activeTab === "referrals" && <div className="dashboard-tab-panel" role="tabpanel" id={`account-panel-${activeTab}`} aria-labelledby={`account-tab-${activeTab}`} tabIndex={0}><ReferralsSection authFetch={authFetch} /></div>}
        {activeTab === "account" && <div className="dashboard-tab-panel" role="tabpanel" id={`account-panel-${activeTab}`} aria-labelledby={`account-tab-${activeTab}`} tabIndex={0}><AccountSection user={user} onChangePassword={() => setShowPw(true)} /></div>}
      </PageShell>
      <ChangePasswordDialog open={showPw} onClose={() => setShowPw(false)} authFetch={authFetch} activateSession={activateSession} refresh={refresh} />
    </div>
  );
}
