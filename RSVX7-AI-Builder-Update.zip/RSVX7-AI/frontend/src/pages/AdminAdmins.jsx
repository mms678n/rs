import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { useAuth } from "@/context/AuthContext";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/admin";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Plus, Trash2, Shield, ShieldAlert, User as UserIcon, RefreshCw } from "lucide-react";
import { ActionButton, EmptyState, LoadingState, PageHeader, Panel, StatusNote } from "@/components/design/Primitives";
import "./admin-ui.css";

const ROLES = [
  { id: "super_admin", label: "مدير عام" },
  { id: "admin", label: "مدير" },
  { id: "moderator", label: "مشرف" },
  { id: "support", label: "دعم" },
];
const EMPTY = { username: "", email: "", password: "", role: "admin", status: "active", permissions: [] };
const CACHE_TTL = 10_000;
const adminsCache = new Map();

const keyFor = (user, q) => `website-admins:${user?._id || user?.id || user?.username || "session"}:${q}`;
const detailOf = (data, fallback) => typeof data?.detail === "string" ? data.detail : fallback;
function translateAdminError(message, t) {
  const patterns = [
    [/^فشل تحميل المديرين \((.+)\)$/, "فشل تحميل المديرين ({status})"],
    [/^فشل تحميل الصلاحيات \((.+)\)$/, "فشل تحميل الصلاحيات ({status})"],
    [/^فشلت العملية \((.+)\)$/, "فشلت العملية ({status})"],
  ];
  const found = patterns.find(([pattern]) => pattern.test(message || ""));
  if (found) { const match = found[0].exec(message); return t(found[1], { status: match[1] }); }
  return t(message);
}
const permissionLabel = (permission) => ({ users: "المستخدمون", dashboard: "لوحة المؤشرات", coupons: "القسائم", website_admins: "المديرون", telegram: "Telegram", settings: "الإعدادات", ai_models: "نموذج AI", payments: "المدفوعات" }[permission] || permission.replace(/_/g, " "));

export default function AdminAdmins() {
  const { user, authFetch } = useAuth();
  const { t, dir, formatNumber } = useI18n("admin");
  const [admins, setAdmins] = useState([]);
  const [perms, setPerms] = useState([]);
  const [q, setQ] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [show, setShow] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const abortRef = useRef(null);
  const requestId = useRef(0);
  const isSuper = user?.role === "super_admin";
  const cacheKey = keyFor(user, searchTerm);

  useEffect(() => {
    const timer = setTimeout(() => setSearchTerm(q.trim()), 280);
    return () => clearTimeout(timer);
  }, [q]);

  const load = useCallback(async ({ force = false } = {}) => {
    const cached = adminsCache.get(cacheKey);
    if (!force && cached && Date.now() - cached.at < CACHE_TTL) {
      setAdmins(cached.admins); setPerms(cached.perms); setError(""); setLoading(false); return;
    }
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    const id = ++requestId.current;
    setLoading(true); setError("");
    try {
      const query = searchTerm ? `?q=${encodeURIComponent(searchTerm)}` : "";
      const [adminsResponse, permissionsResponse] = await Promise.all([
        authFetch(`/admin/website-admins${query}`, { signal: controller.signal }),
        authFetch("/admin/permissions", { signal: controller.signal }),
      ]);
      const [adminsData, permissionsData] = await Promise.all([
        adminsResponse.json().catch(() => ({})), permissionsResponse.json().catch(() => ({})),
      ]);
      if (!adminsResponse.ok) throw new Error(detailOf(adminsData, `فشل تحميل المديرين (${adminsResponse.status})`));
      if (!permissionsResponse.ok) throw new Error(detailOf(permissionsData, `فشل تحميل الصلاحيات (${permissionsResponse.status})`));
      if (controller.signal.aborted || id !== requestId.current) return;
      const nextAdmins = Array.isArray(adminsData) ? adminsData : [];
      const nextPerms = Array.isArray(permissionsData?.permissions) ? permissionsData.permissions : [];
      adminsCache.set(cacheKey, { admins: nextAdmins, perms: nextPerms, at: Date.now() });
      setAdmins(nextAdmins); setPerms(nextPerms);
    } catch (e) {
      if (e?.name === "AbortError") return;
      if (id === requestId.current) setError(e?.message || "تعذّر تحميل المديرين");
    } finally {
      if (id === requestId.current) setLoading(false);
    }
  }, [authFetch, cacheKey, searchTerm]);

  useEffect(() => { load(); return () => abortRef.current?.abort(); }, [load]);

  const visibleAdmins = useMemo(() => admins.filter((a) => (
    (roleFilter === "all" || a.role === roleFilter) && (statusFilter === "all" || a.status === statusFilter)
  )), [admins, roleFilter, statusFilter]);

  const openNew = () => { setEditing(null); setForm({ ...EMPTY, permissions: [] }); setShow(true); };
  const openEdit = (a) => {
    setEditing(a._id);
    setForm({ username: a.username, email: a.email || "", password: "", role: a.role || "admin", status: a.status || "active", permissions: a.permissions || [] });
    setShow(true);
  };

  const submit = async () => {
    if (!editing && form.username.length < 3) { toast.error(t("اسم المستخدم قصير جدًا")); return; }
    if (!editing && (form.password || "").length < 6) { toast.error(t("يجب أن تتكون كلمة المرور من 6 أحرف على الأقل")); return; }
    const url = editing ? `/admin/website-admins/${editing}` : "/admin/website-admins";
    const method = editing ? "PATCH" : "POST";
    const body = editing ? { email: form.email, password: form.password || null, role: form.role, status: form.status, permissions: form.permissions } : form;
    setSaving(true);
    try {
      const r = await authFetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) { toast.error(translateAdminError(detailOf(j, `فشلت العملية (${r.status})`), t)); return; }
      toast.success(editing ? t("تم تحديث المدير") : t("تم إنشاء المدير"));
      setShow(false);
      adminsCache.clear();
      await load({ force: true });
    } catch (e) { toast.error(translateAdminError(e?.message || "خطأ في الشبكة", t)); }
    finally { setSaving(false); }
  };

  const del = async (a) => {
    if (a.is_owner) { toast.error(t("لا يمكن حذف حساب المالك")); return; }
    if (!window.confirm(t("حذف المدير {username}؟", { username: a.username }))) return;
    setDeleting(a._id);
    try {
      const r = await authFetch(`/admin/website-admins/${a._id}`, { method: "DELETE" });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) { toast.error(translateAdminError(detailOf(j, `فشلت العملية (${r.status})`), t)); return; }
      toast.success(t("محذوف"));
      adminsCache.clear();
      await load({ force: true });
    } catch (e) { toast.error(translateAdminError(e?.message || "خطأ في الشبكة", t)); }
    finally { setDeleting(null); }
  };

  const togglePerm = (p) => setForm((f) => ({ ...f, permissions: f.permissions.includes(p) ? f.permissions.filter((x) => x !== p) : [...f.permissions, p] }));

  return (
    <section className="admin-section space-y-4" data-testid="admin-admins" dir={dir}>
      <PageHeader
        eyebrow={t("الوصول · إدارة الفريق")}
        title={t("مديرو الموقع")}
        description={t("تحكّم في الأدوار والصلاحيات الحالية دون تغيير عقد الـAPI. حساب المالك محمي من الحذف.")}
        actions={<div className="admin-inline-actions"><ActionButton tone="ghost" onClick={() => load({ force: true })} loading={loading} aria-label={t("تحديث المديرين")}><RefreshCw size={16} /> {t("تحديث")}</ActionButton>{isSuper && <ActionButton onClick={openNew} data-testid="new-admin-btn"><Plus size={16} /> {t("إضافة مدير")}</ActionButton>}</div>}
      />
      <Panel className="admin-content-card" style={{ padding: "16px" }}>
        <div className="admin-toolbar">
          <div className="admin-toolbar-group" style={{ flex: "1 1 420px" }}>
            <label className="ds-field" style={{ flex: "1 1 250px" }}><span className="sr-only">{t("البحث في المديرين")}</span><Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("ابحث باسم المستخدم…")} className="ds-input" data-testid="admin-search" /></label>
            <select className="ds-input" value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} aria-label={t("تصفية حسب الدور")} data-testid="admin-role-filter"><option value="all">{t("كل الأدوار")}</option>{ROLES.map((r) => <option key={r.id} value={r.id}>{t(r.label)}</option>)}</select>
            <select className="ds-input" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label={t("تصفية حسب الحالة")} data-testid="admin-status-filter"><option value="all">{t("كل الحالات")}</option><option value="active">{t("نشط")}</option><option value="suspended">{t("موقوف")}</option></select>
          </div>
          <p className="admin-soft-note">{t("{visible} من {total}", { visible: formatNumber(visibleAdmins.length), total: formatNumber(admins.length) })}</p>
        </div>
        {error && <StatusNote tone="error" className="admin-inline-error" onRetry={() => load({ force: true })}>{translateAdminError(error, t)}</StatusNote>}
        {loading && <LoadingState label={t("جارٍ تحميل المديرين…")} />}
        {!loading && !error && visibleAdmins.length === 0 && <EmptyState title={t(admins.length ? "لا توجد نتائج مطابقة" : "لا يوجد مديرون بعد")} description={t(admins.length ? "غيّر الفلاتر أو عبارة البحث." : "ستظهر الحسابات المهيأة هنا بعد إنشائها.")} action={q || roleFilter !== "all" || statusFilter !== "all" ? <ActionButton tone="ghost" onClick={() => { setQ(""); setRoleFilter("all"); setStatusFilter("all"); }}>{t("مسح الفلاتر")}</ActionButton> : undefined} />}
        {!loading && !error && visibleAdmins.length > 0 && (
          <div className="ds-table-wrap admin-table-panel"><div className="admin-table-scroll"><table className="ds-table" data-testid="admin-admins-table"><thead><tr><th>{t("المستخدم")}</th><th>{t("الدور")}</th><th>{t("الحالة")}</th><th>{t("الصلاحيات")}</th><th aria-label={t("إجراءات")} /></tr></thead><tbody>
            {visibleAdmins.map((a) => {
              const RoleIcon = a.role === "super_admin" ? ShieldAlert : Shield;
              return <tr key={a._id} data-testid={`admin-row-${a.username}`}>
                <td><div className="flex items-center gap-2"><UserIcon className="w-3.5 h-3.5 text-zinc-500" /><span dir="ltr" className="admin-code text-white">{a.username}</span>{a.is_owner && <Badge className="ml-1 bg-amber-500/15 text-amber-400 border-amber-500/30 text-[10px]">{t("المالك")}</Badge>}</div></td>
                <td><span className="inline-flex items-center gap-1 text-xs text-zinc-300"><RoleIcon className="w-3.5 h-3.5 text-brand-400" />{ROLES.find((r) => r.id === a.role)?.label ? t(ROLES.find((r) => r.id === a.role).label) : a.role}</span></td>
                <td>{a.status === "active" ? <Badge className="bg-emerald-500/15 text-emerald-400 border-emerald-500/30">{t("نشط")}</Badge> : <Badge className="bg-red-500/15 text-red-400 border-red-500/30">{t("موقوف")}</Badge>}</td>
                <td className="text-xs text-zinc-500">{a.role === "super_admin" ? <span className="text-brand-400">{t("كل الصلاحيات")}</span> : (a.permissions?.length ? `${formatNumber(a.permissions.length)} ${t(a.permissions.length === 1 ? "صلاحية" : "صلاحيات")}` : t("بلا صلاحيات"))}</td>
                <td className="text-right whitespace-nowrap">{isSuper && <><Button size="sm" variant="ghost" disabled={saving || !!deleting} onClick={() => openEdit(a)} data-testid={`edit-admin-${a.username}`}>{t("تعديل")}</Button>{!a.is_owner && <Button size="sm" variant="ghost" disabled={saving || !!deleting} onClick={() => del(a)} className="text-red-400 hover:text-red-300" data-testid={`del-admin-${a.username}`}><Trash2 className="w-3.5 h-3.5" /></Button>}</>}</td>
              </tr>;
            })}
          </tbody></table></div></div>
        )}
      </Panel>
      {!isSuper && <StatusNote tone="info">{t("هذه لوحة قراءة فقط. يملك مدير عام صلاحيات إضافة المديرين وتعديلهم وحذفهم.")}</StatusNote>}

      <Dialog open={show} onOpenChange={setShow}>
        <DialogContent className="bg-bg-surface border-soft text-white max-w-lg max-h-[85vh] overflow-y-auto scroll-elegant" data-testid="admin-dialog" dir={dir}>
          <DialogHeader><DialogTitle>{t(editing ? "تعديل مدير" : "مدير جديد")}</DialogTitle></DialogHeader>
          <div className="ds-form-stack">
            <div className="admin-form-grid"><div className="ds-field"><Label>{t("اسم المستخدم")}</Label><Input value={form.username} onChange={(e) => setForm((f) => ({ ...f, username: e.target.value.toLowerCase() }))} disabled={!!editing} className="ds-input" data-testid="admin-username" /></div><div className="ds-field"><Label>{t("البريد (اختياري)")}</Label><Input value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} className="ds-input" /></div></div>
            <div className="ds-field"><Label>{t(editing ? "كلمة مرور جديدة (اتركها فارغة للإبقاء)" : "كلمة المرور")}</Label><Input type="password" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} className="ds-input" data-testid="admin-password" /></div>
            <div className="admin-form-grid"><div className="ds-field"><Label>{t("الدور")}</Label><Select value={form.role} onValueChange={(v) => setForm((f) => ({ ...f, role: v }))}><SelectTrigger className="ds-input" data-testid="admin-role"><SelectValue /></SelectTrigger><SelectContent className="bg-bg-surface border-soft text-white">{ROLES.map((r) => <SelectItem key={r.id} value={r.id}>{t(r.label)}</SelectItem>)}</SelectContent></Select></div><div className="ds-field"><Label>{t("الحالة")}</Label><Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}><SelectTrigger className="ds-input" data-testid="admin-status"><SelectValue /></SelectTrigger><SelectContent className="bg-bg-surface border-soft text-white"><SelectItem value="active">{t("نشط")}</SelectItem><SelectItem value="suspended">{t("موقوف")}</SelectItem></SelectContent></Select></div></div>
            <div className="ds-field"><Label>{t("الصلاحيات")}</Label>{form.role === "super_admin" ? <div className="mt-1 p-3 rounded-lg bg-brand-500/10 border border-brand-500/30 text-brand-400 text-xs">{t("يملك مدير عام كل الصلاحيات تلقائيًا.")}</div> : <div className="mt-1 grid grid-cols-2 gap-1.5 max-h-56 overflow-y-auto scroll-elegant p-2 rounded-lg bg-bg-main/50 border border-soft">{perms.map((p) => <label key={p} className="flex items-center gap-2 text-xs text-zinc-300 py-1 px-2 rounded hover:bg-white/[0.04] cursor-pointer"><input type="checkbox" checked={form.permissions.includes(p)} onChange={() => togglePerm(p)} className="accent-brand-500" data-testid={`perm-${p}`} />{t(permissionLabel(p))}</label>)}</div>}</div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setShow(false)}>{t("إلغاء")}</Button><Button onClick={submit} disabled={saving} className="bg-brand-500 hover:bg-brand-600 text-white" data-testid="save-admin-btn">{saving ? t("جارٍ الحفظ…") : t(editing ? "حفظ" : "إنشاء")}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}
