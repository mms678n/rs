import React, { lazy, memo, Suspense, useEffect, useId, useRef, useState } from "react";
import { Check, ChevronDown, ChevronRight, Copy, Download, WrapText } from "lucide-react";
import StreamCodeBlock from "./StreamCodeBlock";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/chat";
import "./code-block.css";

const LazyHighlightedCode = lazy(() => import("./HighlightedCode"));
const LANG_ALIAS = { js: "javascript", jsx: "javascript", ts: "typescript", tsx: "typescript", py: "python", html: "markup", xml: "markup", sh: "bash", shell: "bash", yml: "yaml", txt: "text", plaintext: "text" };
const LANGUAGES = {
  javascript: ["JavaScript", "js"], jsx: ["JSX", "jsx"], typescript: ["TypeScript", "ts"], tsx: ["TSX", "tsx"],
  python: ["Python", "py"], json: ["JSON", "json"], html: ["HTML", "html"], xml: ["XML", "xml"], markup: ["HTML / XML", "html"],
  css: ["CSS", "css"], bash: ["Bash", "sh"], yaml: ["YAML", "yaml"], sql: ["SQL", "sql"], ruby: ["Ruby", "rb"], rust: ["Rust", "rs"], go: ["Go", "go"],
};
const SUPPORTED = new Set(["javascript", "typescript", "python", "json", "markup", "css", "bash"]);

function DeferredHighlightedCode({ language, value, wrap }) {
  const container = useRef(null);
  const [ready, setReady] = useState(false);
  const canHighlight = value.length <= 14000 && value.split("\n").length <= 300;
  useEffect(() => {
    if (!canHighlight) return undefined;
    let alive = true;
    let idle = null;
    const useIdle = typeof requestIdleCallback === "function";
    const schedule = () => {
      if (idle != null) return;
      const enable = () => { if (alive) setReady(true); };
      idle = useIdle ? requestIdleCallback(enable) : setTimeout(enable, 80);
    };
    const observer = typeof IntersectionObserver === "undefined" ? null : new IntersectionObserver((entries) => {
      if (!entries.some((entry) => entry.isIntersecting)) return;
      observer.disconnect();
      schedule();
    }, { rootMargin: "100px" });
    if (observer && container.current) observer.observe(container.current);
    else schedule();
    return () => {
      alive = false;
      observer?.disconnect();
      if (idle != null) {
        if (useIdle && typeof cancelIdleCallback === "function") cancelIdleCallback(idle);
        else clearTimeout(idle);
      }
    };
  }, [canHighlight]);
  const plain = <StreamCodeBlock value={value} wrap={wrap} />;
  return <div ref={container}>{ready && canHighlight
    ? <Suspense fallback={plain}><LazyHighlightedCode language={language} value={value} wrap={wrap} /></Suspense>
    : plain}</div>;
}

function CodeBlockImpl({ language, value = "", streaming = false }) {
  const { t, dir } = useI18n("chat");
  const [copyState, setCopyState] = useState("");
  const [wrap, setWrap] = useState(false);
  const [open, setOpen] = useState(true);
  const contentId = useId();
  const feedbackTimer = useRef(null);
  const copyAttempt = useRef(0);
  const code = String(value);
  const rawLanguage = String(language || "text").trim().toLowerCase();
  const lang = LANG_ALIAS[rawLanguage] || rawLanguage;
  const languageInfo = LANGUAGES[rawLanguage] || LANGUAGES[lang];
  const label = languageInfo?.[0] || (lang === "text" ? t("نص عادي") : rawLanguage);
  const feedback = copyState === "copied" ? t("تم النسخ") : copyState === "error" ? t("تعذّر نسخ الشيفرة. حاول مرة أخرى.") : "";

  useEffect(() => () => { clearTimeout(feedbackTimer.current); copyAttempt.current += 1; }, []);
  const copy = async () => {
    const attempt = ++copyAttempt.current;
    clearTimeout(feedbackTimer.current);
    try {
      await navigator.clipboard.writeText(code);
      if (attempt !== copyAttempt.current) return;
      setCopyState("copied");
    } catch {
      if (attempt !== copyAttempt.current) return;
      setCopyState("error");
    }
    feedbackTimer.current = setTimeout(() => setCopyState(""), 2000);
  };
  const download = () => {
    const url = URL.createObjectURL(new Blob([code], { type: "text/plain;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `snippet.${languageInfo?.[1] || "txt"}`;
    anchor.click();
    // Let the browser consume the URL before releasing it.
    setTimeout(() => URL.revokeObjectURL(url), 0);
  };
  return <div className="chat-code" dir="ltr" data-testid="code-block" data-streaming={streaming ? "1" : "0"}>
    <div className="code-toolbar" dir="ltr">
      <div className="code-heading">
        <button type="button" onClick={() => setOpen((current) => !current)} aria-label={t("طي أو فتح كتلة الكود")} aria-expanded={open} aria-controls={contentId} title={t("طي أو فتح كتلة الكود")} data-testid="code-toggle-btn">{open ? <ChevronDown size={15} aria-hidden="true" /> : <ChevronRight size={15} aria-hidden="true" />}</button>
        <span className="code-language" title={label}>{label}</span>
        {streaming && <span className="code-stream-state" dir={dir}>{t("جارٍ التوليد…")}</span>}
      </div>
      <div className="code-actions">
        <button type="button" onClick={() => setWrap((current) => !current)} aria-pressed={wrap} title={t("التفاف الأسطر")} aria-label={t("تبديل التفاف الأسطر")} data-testid="code-wrap-btn"><WrapText size={15} aria-hidden="true" /></button>
        <button type="button" onClick={download} title={t("تنزيل الكود")} aria-label={t("تنزيل الشيفرة")} data-testid="code-download-btn"><Download size={15} aria-hidden="true" /></button>
        <button type="button" onClick={copy} className="code-copy" data-copy-state={copyState} title={feedback || t("نسخ الشيفرة")} aria-label={feedback || t("نسخ الشيفرة")} data-testid="code-copy-btn">{copyState === "copied" ? <Check size={15} aria-hidden="true" /> : <Copy size={15} aria-hidden="true" />}<span dir={dir}>{copyState === "copied" ? t("تم النسخ") : t("نسخ")}</span></button>
      </div>
    </div>
    <span className="code-feedback" role="status" aria-live="polite" aria-atomic="true" dir={dir}>{feedback}</span>
    <div id={contentId} className="code-block-scroll" dir="ltr" hidden={!open} tabIndex={0} role="region" aria-label={t("محتوى الشيفرة: {language}", { language: label })}>
      {streaming || !SUPPORTED.has(lang) ? <StreamCodeBlock value={code} wrap={wrap} /> : <DeferredHighlightedCode language={lang} value={code} wrap={wrap} />}
    </div>
  </div>;
}
export default memo(CodeBlockImpl, (a, b) => a.value === b.value && a.language === b.language && a.streaming === b.streaming);
