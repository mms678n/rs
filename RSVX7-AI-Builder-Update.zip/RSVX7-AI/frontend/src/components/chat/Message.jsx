import React, { memo, useCallback, useDeferredValue, useEffect, useState, useSyncExternalStore } from "react";
import { Atom, Check, ChevronDown, ChevronUp, Copy, Pencil, RotateCcw, ThumbsDown, ThumbsUp } from "lucide-react";
import Markdown from "@/components/chat/Markdown";
import FileChip from "@/components/chat/FileChip";
import GateMessage from "@/components/chat/GateMessage";
import { useChat } from "@/context/ChatContext";
import { streamStore } from "@/context/streamStore";
import { MessageUsageStats } from "@/components/chat/TokenBalance";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/chat";
import "./deepseek-messages.css";

function useLiveContent(messageId, isStreamingThis) {
  const subscribe = useCallback((listener) => isStreamingThis ? streamStore.subscribe(listener) : () => {}, [isStreamingThis]);
  const getSnapshot = useCallback(() => {
    if (!isStreamingThis) return null;
    return typeof streamStore.getPublishedSnapshot === "function"
      ? streamStore.getPublishedSnapshot(messageId) : streamStore.getSnapshot(messageId);
  }, [messageId, isStreamingThis]);
  return useSyncExternalStore(subscribe, getSnapshot, () => null);
}

// Reasoning is a separate subscription so a reasoning delta never wakes the
// completed message list or causes Markdown to be parsed again.
function useLiveReasoning(messageId, isStreamingThis) {
  const subscribe = useCallback((listener) => isStreamingThis ? streamStore.subscribe(listener) : () => {}, [isStreamingThis]);
  const getSnapshot = useCallback(() => {
    if (!isStreamingThis || typeof streamStore.getReasoningSnapshot !== "function") return null;
    const snapshot = typeof streamStore.getPublishedReasoningSnapshot === "function"
      ? streamStore.getPublishedReasoningSnapshot(messageId) : streamStore.getReasoningSnapshot(messageId);
    return snapshot == null ? null : String(snapshot);
  }, [messageId, isStreamingThis]);
  return useSyncExternalStore(subscribe, getSnapshot, () => null);
}

function readReasoning(value) {
  if (typeof value === "string") return value;
  if (value && typeof value.text === "string") return value.text;
  return "";
}

function timestampMs(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value < 100000000000 ? value * 1000 : value;
  if (typeof value !== "string" || !value) return null;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function useReasoningDuration(message, isStreamingThis, hasReasoning) {
  const storedDuration = Number(message.reasoningDurationMs);
  const hasStoredDuration = Number.isFinite(storedDuration) && storedDuration >= 0;
  const startedAt = timestampMs(message.reasoningStartedAt);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!isStreamingThis || !hasReasoning || startedAt == null || (hasStoredDuration && storedDuration > 0)) return undefined;
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [hasReasoning, hasStoredDuration, isStreamingThis, startedAt, storedDuration]);

  if (!isStreamingThis && hasStoredDuration) return storedDuration;
  if (isStreamingThis && startedAt != null) return Math.max(0, now - startedAt);
  if (isStreamingThis && hasStoredDuration) return storedDuration;
  return null;
}

function formatDuration(durationMs, formatNumber) {
  if (durationMs == null || !Number.isFinite(durationMs)) return null;
  if (durationMs < 1000) return `${formatNumber(Math.max(1, Math.round(durationMs)))}ms`;
  return `${formatNumber(durationMs / 1000, { minimumFractionDigits: 1, maximumFractionDigits: 1 })}s`;
}

function ReasoningPanel({ messageId, text, durationMs, active }) {
  const [open, setOpen] = useState(true);
  const panelId = `reasoning-panel-${messageId}`;
  const { t, formatNumber } = useI18n("chat");
  const duration = formatDuration(durationMs, formatNumber);
  return <section className="deepseek-reasoning" data-testid="reasoning-panel" data-active={active ? "1" : "0"}>
    <button type="button" className="deepseek-reasoning-header" onClick={() => setOpen((value) => !value)} aria-expanded={open} aria-controls={panelId} data-testid={`reasoning-toggle-${messageId}`}>
      <span className="deepseek-reasoning-pill"><Atom size={15} aria-hidden="true" /><span>{active ? t("التفكير جارٍ") : t("التفكير")}</span>{duration && <span className="deepseek-reasoning-duration" dir="ltr">{duration}</span>}</span>
      {open ? <ChevronUp size={15} aria-hidden="true" /> : <ChevronDown size={15} aria-hidden="true" />}
    </button>
    <div id={panelId} className="deepseek-reasoning-panel" hidden={!open} dir="auto">{text}</div>
  </section>;
}

function CopyMessageButton({ text }) {
  const { t } = useI18n("chat");
  const [copied, setCopied] = useState(false);
  const copy = async () => { try { await navigator.clipboard.writeText(text); setCopied(true); window.setTimeout(() => setCopied(false), 1500); } catch {} };
  return <button onClick={copy} className="chat-action-button" data-testid="msg-copy-btn" aria-label={t("نسخ الرسالة")} title={t("نسخ الرسالة")}>{copied ? <Check className="text-emerald-300" size={15} aria-hidden="true" /> : <Copy size={15} aria-hidden="true" />}</button>;
}

function MessageImpl({ message, isStreamingThis }) {
  const { regenerate, editAndResend } = useChat();
  const { t } = useI18n("chat");
  const [editing, setEditing] = useState(false);
  const [editText, setEditText] = useState(message.content || "");
  const liveContent = useLiveContent(message.id, isStreamingThis);
  const liveReasoning = useLiveReasoning(message.id, isStreamingThis);
  // Markdown for the live message renders at lower priority so typing never waits on it.
  const deferredLive = useDeferredValue(liveContent);
  const displayContent = liveContent != null ? (deferredLive ?? liveContent) : (message.content || "");
  const reasoning = liveReasoning != null ? liveReasoning : readReasoning(message.reasoning);
  const hasReasoning = Boolean(reasoning.trim());
  const reasoningDuration = useReasoningDuration(message, isStreamingThis, hasReasoning);

  if (message.gate) return <GateMessage message={message} />;
  if (message.role === "user") {
    return <div className="chat-message chat-message-user deepseek-message-user" data-testid={`user-message-${message.id}`}>
      <div className="chat-message-body">
        {message.files?.length > 0 && <div className="deepseek-user-files flex flex-wrap justify-start gap-2 mb-2">{message.files.map((file) => <FileChip key={file.id} file={file} compact />)}</div>}
        {editing ? <div className="chat-edit-panel"><textarea value={editText} onChange={(event) => setEditText(event.target.value)} dir="auto" data-testid="edit-textarea" aria-label={t("تعديل الرسالة")} /><div className="chat-edit-actions"><button onClick={() => { setEditing(false); setEditText(message.content || ""); }} className="min-h-[40px] rounded-lg px-3 text-xs text-zinc-300 hover:bg-white/[.06]" data-testid="edit-cancel-btn">{t("إلغاء")}</button><button onClick={() => { setEditing(false); editAndResend(message.id, editText); }} className="min-h-[40px] rounded-lg bg-[#9D3E59] px-3 text-xs text-white" data-testid="edit-save-btn">{t("إرسال")}</button></div></div> : <><div className="chat-user-bubble" dir="auto">{message.content}</div><div className="chat-message-actions"><CopyMessageButton text={message.content || ""} /><button onClick={() => setEditing(true)} className="chat-action-button" data-testid="msg-edit-btn" aria-label={t("تعديل الرسالة")} title={t("تعديل الرسالة")}><Pencil size={15} aria-hidden="true" /></button></div></>}
      </div>
    </div>;
  }

  return <div className="chat-message deepseek-assistant-message" data-testid={`assistant-message-${message.id}`}>
    <div className="chat-message-body">
      {hasReasoning && <ReasoningPanel messageId={message.id} text={reasoning} durationMs={reasoningDuration} active={isStreamingThis} />}
      {isStreamingThis && !displayContent && !hasReasoning ? <div className="deepseek-generation-status" role="status" aria-live="polite"><span className="dot-thinking" aria-hidden="true"><span /><span /><span /></span><span>{t("جارٍ التوليد…")}</span></div> : displayContent ? <div className={isStreamingThis ? "stream-cursor" : ""} dir="auto"><Markdown streaming={isStreamingThis}>{displayContent}</Markdown></div> : null}
      {!isStreamingThis && message.finishReason === "error" && <div className="chat-stream-error" role="alert" data-testid={`message-error-${message.id}`}><span>{message.streamError || t("تعذّر إكمال الرد.")}</span><button onClick={() => regenerate(message.id)} className="chat-stream-error-retry" data-testid="msg-error-retry-btn"><RotateCcw size={14} aria-hidden="true" />{t("إعادة المحاولة")}</button></div>}
      {!isStreamingThis && displayContent && <><div className="chat-message-actions"><CopyMessageButton text={displayContent} /><button onClick={() => regenerate(message.id)} className="chat-action-button" data-testid="msg-regen-btn" aria-label={t("إعادة توليد الرد")} title={t("إعادة توليد الرد")}><RotateCcw size={15} aria-hidden="true" /></button><button className="chat-action-button" data-testid="msg-like-btn" aria-label={t("رد مفيد")} title={t("رد مفيد")}><ThumbsUp size={15} aria-hidden="true" /></button><button className="chat-action-button" data-testid="msg-dislike-btn" aria-label={t("رد غير مفيد")} title={t("رد غير مفيد")}><ThumbsDown size={15} aria-hidden="true" /></button></div><MessageUsageStats usage={message.usage} /></>}
    </div>
  </div>;
}

const Message = memo(MessageImpl, (previous, next) => {
  const a = previous.message;
  const b = next.message;
  if (previous.isStreamingThis !== next.isStreamingThis) return false;
  if (a === b) return true;
  if (a.id !== b.id || a.content !== b.content || a.reasoning !== b.reasoning || !!a.thinking !== !!b.thinking) return false;
  if (a.reasoningDurationMs !== b.reasoningDurationMs || a.reasoningStartedAt !== b.reasoningStartedAt || a.finishReason !== b.finishReason) return false;
  if ((a.files?.length || 0) !== (b.files?.length || 0) || a.usage !== b.usage || a.gate !== b.gate || a.streamError !== b.streamError) return false;
  return true;
});
export default Message;
