import React from "react";
// Use the Light/lowlight entry rather than the Prism root: it keeps the
// highlighted chunk small and avoids importing every Prism grammar.
import SyntaxHighlighter from "react-syntax-highlighter/dist/cjs/light";
import javascript from "react-syntax-highlighter/dist/cjs/languages/hljs/javascript";
import typescript from "react-syntax-highlighter/dist/cjs/languages/hljs/typescript";
import python from "react-syntax-highlighter/dist/cjs/languages/hljs/python";
import json from "react-syntax-highlighter/dist/cjs/languages/hljs/json";
import xml from "react-syntax-highlighter/dist/cjs/languages/hljs/xml";
import css from "react-syntax-highlighter/dist/cjs/languages/hljs/css";
import bash from "react-syntax-highlighter/dist/cjs/languages/hljs/bash";

SyntaxHighlighter.registerLanguage("javascript", javascript);
SyntaxHighlighter.registerLanguage("typescript", typescript);
SyntaxHighlighter.registerLanguage("python", python);
SyntaxHighlighter.registerLanguage("json", json);
SyntaxHighlighter.registerLanguage("xml", xml);
SyntaxHighlighter.registerLanguage("markup", xml);
SyntaxHighlighter.registerLanguage("css", css);
SyntaxHighlighter.registerLanguage("bash", bash);

const LIGHT_HLJS = {
  hljs: { background: "transparent", color: "var(--foreground)" },
  comment: { color: "var(--code-comment)" }, keyword: { color: "var(--code-keyword)" },
  string: { color: "var(--code-string)" }, number: { color: "var(--code-number)" },
  title: { color: "var(--code-title)" }, name: { color: "var(--code-name)" },
  built_in: { color: "var(--code-title)" }, type: { color: "var(--code-name)" },
  meta: { color: "var(--code-meta)" }, attr: { color: "var(--code-name)" },
};

export default function HighlightedCode({ language, value, wrap }) {
  return <SyntaxHighlighter language={language} style={LIGHT_HLJS} wrapLongLines={wrap} showLineNumbers={false} className={`stream-code${wrap ? " is-wrapped" : ""}`} customStyle={{ margin: 0, background: "transparent" }} codeTagProps={{ dir: "ltr" }}>{value}</SyntaxHighlighter>;
}
