import React from "react";
import { act } from "react";
import { createRoot } from "react-dom/client";
jest.mock("remark-gfm", () => () => null);
jest.mock("react-markdown", () => ({ children }) => <div data-testid="mock-markdown">{children}</div>);
import Markdown from "./Markdown";

let container;
let root;

beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
});

test("renders GFM prose and an open code tail without dropping formatting", async () => {
  const source = "## Heading\n\n- one\n- two\n\n| a | b |\n| - | - |\n| 1 | 2 |\n\nSee [docs](https://example.test) and `inline()`\n\n```python\nprint(1";
  await act(async () => root.render(<Markdown streaming>{source}</Markdown>));

  expect(container.querySelector("h2")?.textContent).toBe("Heading");
  expect(container.textContent).toContain("- one");
  expect(container.textContent).toContain("| 1 | 2 |");
  expect(container.textContent).toContain("[docs](https://example.test)");
  expect(container.querySelector("code")?.textContent).toContain("print(1");
  expect(container.querySelector('[data-testid="code-block"]')?.getAttribute("data-streaming")).toBe("1");
});

test("keeps completed DOM nodes when the stream becomes done", async () => {
  const live = "### Result\n\nThe answer is **42**.\n\n```js\nconst answer = 42;";
  const done = `${live}\n\`\`\`\n\nTail text`;
  await act(async () => root.render(<Markdown streaming>{live}</Markdown>));
  const codeBefore = container.querySelector('[data-testid="code-block"]');
  const proseBefore = Array.from(container.querySelectorAll(".markdown-stream-segment")).find((node) => node.textContent.includes("42"));
  expect(codeBefore).not.toBeNull();
  expect(proseBefore?.textContent).toContain("**42**");

  await act(async () => root.render(<Markdown streaming={false}>{done}</Markdown>));
  expect(container.querySelector('[data-testid="code-block"]')).toBe(codeBefore);
  expect(Array.from(container.querySelectorAll(".markdown-stream-segment")).find((node) => node.textContent.includes("42"))).toBe(proseBefore);
  expect(container.textContent).toContain("Tail text");
  expect(container.textContent).toContain("const answer = 42;");
});

test("does not expose unsafe link protocols", async () => {
  await act(async () => root.render(<Markdown streaming>{"[bad](javascript:alert(1))"}</Markdown>));
  expect(container.querySelector('a[href^="javascript:"]')).toBeNull();
});

test("shares later reference definitions across completed prose blocks without replacing code", async () => {
  const source = "See [docs].\n\n```js\nlet n = 1;\n```\n\n";
  await act(async () => root.render(<Markdown streaming>{source}</Markdown>));
  const code = container.querySelector('[data-testid="code-block"] pre');
  await act(async () => root.render(<Markdown streaming={false}>{source + "[docs]: https://example.test"}</Markdown>));
  const prose = Array.from(container.querySelectorAll('[data-testid="mock-markdown"]')).find((node) => node.textContent.includes("See [docs]."));
  expect(prose.textContent).toContain("[docs]: https://example.test");
  expect(prose.textContent).not.toContain("[https://example.test]");
  expect(container.querySelector('[data-testid="code-block"] pre')).toBe(code);
});

test("uses a direct lightweight path only for simple headings and prose", async () => {
  await act(async () => root.render(<Markdown streaming>{"### Fast heading\nA multilingual paragraph تجربة بث.\n\n"}</Markdown>));
  expect(container.querySelector("h3")?.textContent).toBe("Fast heading");
  expect(container.querySelector("p")?.textContent).toBe("A multilingual paragraph تجربة بث.");
  expect(container.querySelector('[data-testid="mock-markdown"]')).toBeNull();
});

test("preserves streamed code whitespace through completion and copies the exact final payload", async () => {
  const payload = "const arabic = 'مرحبا';  \n\n";
  const live = "```js\n" + payload;
  const writeText = jest.fn().mockResolvedValue(undefined);
  Object.defineProperty(navigator, "clipboard", { configurable: true, value: { writeText } });
  await act(async () => root.render(<Markdown streaming>{live}</Markdown>));
  const codeBlock = container.querySelector('[data-testid="code-block"]');
  expect(codeBlock.querySelector("pre code").textContent).toBe(payload);
  await act(async () => root.render(<Markdown streaming={false}>{live + "\n```"}</Markdown>));
  expect(container.querySelector('[data-testid="code-block"]')).toBe(codeBlock);
  expect(codeBlock.querySelector("pre code").textContent).toBe(payload);
  expect(codeBlock.getAttribute("data-streaming")).toBe("0");
  await act(async () => codeBlock.querySelector('[data-testid="code-copy-btn"]').click());
  expect(writeText).toHaveBeenCalledWith(payload);
});

test("closed code keeps its controls and wrap preference as the final prose arrives", async () => {
  const source = "```unknown\nfirst\n\n\n```\n\n";
  await act(async () => root.render(<Markdown streaming>{source}</Markdown>));
  const codeBlock = container.querySelector('[data-testid="code-block"]');
  expect(codeBlock.getAttribute("data-streaming")).toBe("0");
  await act(async () => codeBlock.querySelector('[data-testid="code-wrap-btn"]').click());
  await act(async () => root.render(<Markdown streaming={false}>{source + "Done."}</Markdown>));
  expect(container.querySelector('[data-testid="code-block"]')).toBe(codeBlock);
  expect(codeBlock.querySelector('[data-testid="code-wrap-btn"]').getAttribute("aria-pressed")).toBe("true");
  expect(codeBlock.querySelector("pre code").textContent).toBe("first\n\n");
});

test("preserves CRLF within completed streamed code when rendering and copying", async () => {
  const payload = "const arabic = 'مرحبا';  \r\n\r\n";
  const source = "```unknown\r\n" + payload;
  const writeText = jest.fn().mockResolvedValue(undefined);
  Object.defineProperty(navigator, "clipboard", { configurable: true, value: { writeText } });
  await act(async () => root.render(<Markdown streaming>{source}</Markdown>));
  expect(container.querySelector("pre code").textContent).toBe(payload);
  await act(async () => root.render(<Markdown streaming={false}>{source + "\r\n```"}</Markdown>));
  expect(container.querySelector("pre code").textContent).toBe(payload);
  await act(async () => container.querySelector('[data-testid="code-copy-btn"]').click());
  expect(writeText).toHaveBeenCalledWith(payload);
});
