import React from "react";
import { act } from "react";
import { createRoot } from "react-dom/client";

jest.mock("@/lib/aiClient", () => ({
  streamChat: jest.fn(),
  suggestedTitle: jest.fn(() => "New chat"),
  fetchAICapabilities: jest.fn(() => Promise.resolve({})),
}));
jest.mock("@/components/chat/ModelPicker", () => ({
  DEFAULT_MODEL_ID: "default-model",
  backendModelFor: jest.fn((value) => value),
}));

let mockWorkspaceState = { currentProjectId: "project-a" };
let mockAuthState = { user: { _id: "account-a" } };
jest.mock("@/context/WorkspaceContext", () => ({
  useWorkspace: () => mockWorkspaceState,
}));
jest.mock("@/context/TokensContext", () => ({
  useTokens: () => ({ applyUsage: jest.fn() }),
}));
jest.mock("@/context/AuthContext", () => ({
  useAuth: () => mockAuthState,
}));

let mockStreamText = "";
let mockStreamReasoning = "";
jest.mock("@/context/streamStore", () => ({
  streamStore: {
    start: jest.fn(() => { mockStreamText = ""; mockStreamReasoning = ""; }),
    push: jest.fn((text) => { mockStreamText = text; }),
    pushReasoning: jest.fn((text) => { mockStreamReasoning = text; }),
    flush: jest.fn(),
    stop: jest.fn(() => { mockStreamText = ""; mockStreamReasoning = ""; }),
    recordChunk: jest.fn(),
    getSnapshot: jest.fn(() => mockStreamText),
    getReasoningSnapshot: jest.fn(() => mockStreamReasoning),
    getActiveId: jest.fn(() => null),
  },
}));
jest.mock("@/lib/workspaceClient", () => ({
  wsListConversations: jest.fn(),
  wsCreateConversation: jest.fn(),
  wsGetConversation: jest.fn(),
  wsUpdateConversation: jest.fn(),
  wsDeleteConversation: jest.fn(),
  wsSaveTurn: jest.fn(),
}));
jest.mock("sonner", () => ({ toast: { error: jest.fn(), success: jest.fn() } }));

import { ChatProvider, useChat } from "./ChatContext";
import * as aiClient from "@/lib/aiClient";
import * as workspaceClient from "@/lib/workspaceClient";

const mockStreamChat = aiClient.streamChat;
const mockListConversations = workspaceClient.wsListConversations;
const mockCreateConversation = workspaceClient.wsCreateConversation;
const mockSaveTurn = workspaceClient.wsSaveTurn;

let container;
let root;
let api;
let streamOptions;
let resolveStream;
let createdConversationId;

function Probe() {
  api = useChat();
  return null;
}

const renderProvider = async () => {
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
  await act(async () => root.render(<ChatProvider><Probe /></ChatProvider>));
  await act(async () => {});
};

const flush = async () => act(async () => {});

beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  localStorage.clear();
  mockWorkspaceState = { currentProjectId: "project-a" };
  mockAuthState = { user: { _id: "account-a" } };
  mockStreamText = "";
  mockStreamReasoning = "";
  streamOptions = null;
  resolveStream = null;
  createdConversationId = null;
  mockStreamChat.mockReset();
  aiClient.fetchAICapabilities.mockReset().mockResolvedValue({});
  mockCreateConversation.mockReset();
  mockSaveTurn.mockReset();
  mockListConversations.mockReset();
  mockCreateConversation.mockImplementation((_projectId, body) => {
    createdConversationId = body.id;
    return Promise.resolve({ _id: body.id, id: body.id });
  });
  mockListConversations.mockImplementation(() => Promise.resolve(createdConversationId ? [{
    _id: createdConversationId,
    title: "New chat",
    model_id: "default-model",
    dark_mode: true,
    message_count: 2,
  }] : []));
  workspaceClient.wsGetConversation.mockResolvedValue({ messages: [] });
  mockSaveTurn.mockResolvedValue({});
  mockStreamChat.mockImplementation((_messages, options) => {
    streamOptions = options;
    return new Promise((resolve) => { resolveStream = resolve; });
  });
  api = null;
});

test('model selection changes provider capabilities and the next chat request together', async () => {
  aiClient.fetchAICapabilities.mockResolvedValueOnce({model:'provider/default',profiles:{
    kaligpt:{model:'provider/fast',supports_reasoning:false,reasoning_mandatory:false},
    deepdark:{model:'provider/reasoning',supports_reasoning:true,reasoning_mandatory:true},
  }});
  await renderProvider();
  await act(async () => api.setModel('deepdark'));
  expect(api.aiModel).toBe('provider/reasoning');
  expect(api.reasoningSupported).toBe(true); expect(api.prefs.deepThink).toBe(true);
  await act(async () => api.sendMessage('Analyze this'));
  expect(streamOptions.personality).toBe('deepdark'); expect(streamOptions.deepThink).toBe(true);
  await act(async () => { api.stop(); });
  await act(async () => api.setModel('kaligpt'));
  expect(api.aiModel).toBe('provider/fast');
  expect(api.reasoningSupported).toBe(false); expect(api.prefs.deepThink).toBe(false);
});

test('saving model assignments refreshes capabilities immediately within the focus cooldown', async () => {
  aiClient.fetchAICapabilities.mockResolvedValueOnce({model:'provider/old'})
    .mockResolvedValueOnce({model:'provider/new'});
  await renderProvider();
  expect(api.aiModel).toBe('provider/old');
  await act(async () => window.dispatchEvent(new Event('rsvx7:ai-settings-updated')));
  expect(api.aiModel).toBe('provider/new');
  expect(aiClient.fetchAICapabilities).toHaveBeenCalledTimes(2);
});

afterEach(async () => {
  if (root) await act(async () => root.unmount());
  if (container) container.remove();
  root = null;
  container = null;
});

test("stop persists partial text and external reasoning, then reloads the saved abort turn", async () => {
  await renderProvider();
  await act(async () => { expect(api.sendMessage("stop me")).toBe(true); });
  await act(async () => {
    streamOptions.onReasoning("private reasoning");
    streamOptions.onChunk("partial answer");
  });

  let resolveSave;
  mockSaveTurn.mockImplementation(() => new Promise((resolve) => { resolveSave = resolve; }));
  await act(async () => api.abort());
  expect(api.phase).toBe("idle");
  expect(api.isStreaming).toBe(false);
  const stopped = api.activeChat.messages.find((message) => message.role === "assistant");
  expect(stopped.content).toBe("partial answer");
  expect(stopped.reasoning).toBe("private reasoning");
  expect(stopped.finishReason).toBe("abort");
  expect(stopped.saveStatus).toBe("pending");
  expect(stopped.content).not.toContain("تم إلغاء");
  expect(mockSaveTurn).toHaveBeenCalledTimes(1);
  expect(mockSaveTurn.mock.calls[0][1].messages[1]).toMatchObject({
    content: "partial answer",
    reasoning: "private reasoning",
    finish_reason: "abort",
  });
  expect(Object.keys(localStorage).some((key) => key.startsWith("rsvx7-chat-outbox-v1:"))).toBe(true);

  resolveSave({});
  resolveStream();
  await flush();
  await flush();
  expect(api.activeChat.messages.find((message) => message.role === "assistant").saveStatus).toBe("saved");
  expect(Object.keys(localStorage).some((key) => key.startsWith("rsvx7-chat-outbox-v1:"))).toBe(false);

  const savedChatId = api.activeChat.id;
  mockListConversations.mockResolvedValue([{ _id: savedChatId, title: "New chat", model_id: "default-model", dark_mode: true, message_count: 2 }]);
  workspaceClient.wsGetConversation.mockResolvedValue({ messages: mockSaveTurn.mock.calls[0][1].messages });
  await act(async () => root.unmount());
  container.remove();
  root = null;
  container = null;
  await renderProvider();
  const reloaded = api.activeChat.messages.find((message) => message.role === "assistant");
  expect(reloaded).toMatchObject({
    content: "partial answer",
    reasoning: "private reasoning",
    finishReason: "abort",
    saveStatus: "saved",
    pending: false,
  });
});

test("network errors save actual output and reasoning without appending a fake error", async () => {
  await renderProvider();
  await act(async () => { expect(api.sendMessage("network")).toBe(true); });
  await act(async () => {
    streamOptions.onReasoning("reasoning before failure");
    streamOptions.onChunk("actual partial");
  });
  await act(async () => streamOptions.onError(new Error("network failed")));

  const failed = api.activeChat.messages.find((message) => message.role === "assistant");
  expect(failed.content).toBe("actual partial");
  expect(failed.content).not.toContain("network failed");
  expect(failed.streamError).toBe("network failed");
  expect(failed.finishReason).toBe("error");
  expect(mockSaveTurn.mock.calls[0][1].messages[1]).toMatchObject({
    content: "actual partial",
    reasoning: "reasoning before failure",
    finish_reason: "error",
  });
  await act(async () => { expect(api.sendMessage("blocked while error reader cleans up")).toBe(false); });
  resolveStream();
  await flush();
});

test("a terminal callback cannot start another stream until the reader promise settles", async () => {
  await renderProvider();
  await act(async () => { expect(api.sendMessage("first")).toBe(true); });
  await act(async () => streamOptions.onChunk("done text"));
  await act(async () => streamOptions.onDone("done text", "stop"));

  expect(api.phase).toBe("idle");
  expect(api.isStreaming).toBe(false);
  await act(async () => { expect(api.sendMessage("must wait for finally")).toBe(false); });
  expect(mockStreamChat).toHaveBeenCalledTimes(1);

  resolveStream();
  await flush();
  await act(async () => { expect(api.sendMessage("after reader cleanup")).toBe(true); });
  expect(mockStreamChat).toHaveBeenCalledTimes(2);
});

test('late wallet errors preserve and persist output; late tokens are ignored', async () => {
  await renderProvider();
  await act(async () => { api.sendMessage('wallet failure'); });
  await act(async () => {
    streamOptions.onChunk('answer already received');
    streamOptions.onError(Object.assign(new Error('top up'), { detail: { code: 'insufficient_tokens' } }));
    streamOptions.onChunk('answer already received plus stale data');
    streamOptions.onDone('stale', 'stop');
  });
  const message = api.activeChat.messages.find(m => m.role === 'assistant');
  expect(message.content).toBe('answer already received');
  expect(message.gate).toBeUndefined();
  expect(message.finishReason).toBe('error');
  expect(mockSaveTurn).toHaveBeenCalledTimes(1);
  expect(mockSaveTurn.mock.calls[0][1].messages[1].content).toBe('answer already received');
  resolveStream();
  await flush();
});
