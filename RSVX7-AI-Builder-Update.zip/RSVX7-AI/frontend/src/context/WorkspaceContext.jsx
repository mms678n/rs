import React, { createContext, useContext, useCallback, useEffect, useRef, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  wsListProjects, wsCreateProject, wsUpdateProject, wsDeleteProject,
  wsBootstrap, wsMigrate,
} from "@/lib/workspaceClient";
import { toast } from "sonner";
import { t, formatNumber } from "@/i18n";
import "@/i18n/catalogs/services";

const Ctx = createContext(null);
const serviceT = (source, variables) => t(source, variables, "services");

const CURRENT_PROJECT_KEY = "rsvx7_current_project";
const MIGRATED_KEY = "rsvx7_migrated_v1";
const LEGACY_CHATS_KEY = "rsvx7-chats-v1";
const LEGACY_CLAIMED_KEY = "rsvx7-chats-v1-claimed-by";
const FOCUS_REFRESH_MS = 6_000;

const _scopedKey = (base, uid) => `${base}:${encodeURIComponent(uid)}`;
const isAbortError = (error) => error?.name === "AbortError" || error?.code === 20;

function readStorage(key) {
  try { return localStorage.getItem(key); } catch { return null; }
}
function writeStorage(key, value) {
  try { localStorage.setItem(key, value); } catch { /* storage is optional */ }
}
function removeStorage(key) {
  try { localStorage.removeItem(key); } catch { /* storage is optional */ }
}

function legacyClaimOwner() {
  const claim = readStorage(LEGACY_CLAIMED_KEY);
  if (!claim) return null;
  try {
    const parsed = JSON.parse(claim);
    return parsed && typeof parsed.uid === "string" ? parsed.uid : claim;
  } catch { return claim; }
}

// One-shot migration: on first successful workspace mount for this user, import
// conversations saved by the old localStorage-only ChatContext into General.
export async function _migrateLegacyIfNeeded(uid, options = {}) {
  const migratedKey = _scopedKey(MIGRATED_KEY, uid);
  if (readStorage(migratedKey) === "1") return null;
  try {
    const scopedLegacyKey = _scopedKey(LEGACY_CHATS_KEY, uid);
    let raw = readStorage(scopedLegacyKey);
    let claimedGlobal = false;
    // The old app used one unscoped key. Only its explicit owner may reuse a
    // claim after a failed request; another uid must never read that raw data.
    const claimOwner = legacyClaimOwner();
    if (!raw && (!claimOwner || claimOwner === uid)) {
      raw = readStorage(LEGACY_CHATS_KEY);
      if (raw) {
        if (!claimOwner) writeStorage(LEGACY_CLAIMED_KEY, uid);
        claimedGlobal = true;
      }
    }
    if (!raw) { writeStorage(migratedKey, "1"); return null; }
    let chats;
    try { chats = JSON.parse(raw); } catch {
      // Corrupt/empty legacy content is explicitly not transferable. Keep a
      // failed network migration retryable, but do not retry malformed data.
      writeStorage(migratedKey, "1");
      return null;
    }
    if (!Array.isArray(chats) || chats.length === 0) {
      writeStorage(migratedKey, "1");
      return null;
    }
    const result = await wsMigrate(chats, options);
    writeStorage(migratedKey, "1");
    if (claimedGlobal) {
      removeStorage(LEGACY_CHATS_KEY);
      removeStorage(LEGACY_CLAIMED_KEY);
    }
    return result;
  } catch (error) {
    // An aborted/failed migration remains retryable; leave both the claim and
    // the original localStorage copy intact so the same uid can retry safely.
    if (!isAbortError(error)) return null;
    throw error;
  }
}

export function WorkspaceProvider({ children }) {
  const { user } = useAuth();
  const userId = user?._id || user?.id || user?.user_id || null;
  const [projects, setProjects] = useState([]);
  const [archivedProjects, setArchivedProjects] = useState([]);
  const [currentProjectId, _setCurrentProjectId] = useState(null);
  const [loading, setLoading] = useState(Boolean(userId));
  const [migrated, setMigrated] = useState(null);
  const [workspaceError, setWorkspaceError] = useState(null);
  const [bootRetry, setBootRetry] = useState(0);
  const sessionRef = useRef(0);
  const activeUserRef = useRef(null);
  const bootingKeyRef = useRef(null);
  const refreshSerialRef = useRef(0);
  const focusRefreshAtRef = useRef(0);

  const setCurrentProjectId = useCallback((pid) => {
    _setCurrentProjectId(pid);
    if (pid && userId) writeStorage(_scopedKey(CURRENT_PROJECT_KEY, userId), pid);
    else if (userId) removeStorage(_scopedKey(CURRENT_PROJECT_KEY, userId));
  }, [userId]);

  const refreshProjects = useCallback(async ({ signal, force = false } = {}) => {
    if (!userId) return [];
    const requestUser = userId;
    const requestSession = sessionRef.current;
    const requestSerial = ++refreshSerialRef.current;
    const requestOptions = { ...(signal ? { signal } : {}), ...(force ? { cache: false } : {}) };
    try {
      // Both lists are independent. Fetch them together and let the client
      // dedupe any concurrent read without sharing data between principals.
      const [active, archived] = await Promise.all([
        wsListProjects(false, requestOptions),
        wsListProjects(true, requestOptions),
      ]);
      if (activeUserRef.current !== requestUser || sessionRef.current !== requestSession
          || requestSerial !== refreshSerialRef.current) return [];
      setProjects(Array.isArray(active) ? active : []);
      setArchivedProjects(Array.isArray(archived) ? archived : []);
      setWorkspaceError(null);
      return Array.isArray(active) ? active : [];
    } catch (error) {
      if (activeUserRef.current === requestUser && sessionRef.current === requestSession
          && requestSerial === refreshSerialRef.current && !isAbortError(error)) {
        setWorkspaceError(error);
      }
      throw error;
    }
  }, [userId]);

  // Boot: bootstrap → optional migration → parallel project lists. A cancelled
  // session cannot update the next user's state, and every failure remains retryable.
  useEffect(() => {
    const session = ++sessionRef.current;
    const key = userId ? `${userId}:${bootRetry}` : null;
    activeUserRef.current = userId;
    refreshSerialRef.current += 1;
    setProjects([]);
    setArchivedProjects([]);
    setMigrated(null);
    setWorkspaceError(null);
    const stored = userId ? readStorage(_scopedKey(CURRENT_PROJECT_KEY, userId)) : null;
    _setCurrentProjectId(stored || null);

    if (!userId) {
      setLoading(false);
      return undefined;
    }
    // StrictMode can set up/tear down an effect twice; the cleanup below clears
    // this key so a real second setup still starts a fresh, abortable boot.
    if (bootingKeyRef.current === key) return undefined;
    bootingKeyRef.current = key;
    const controller = new AbortController();
    let cancelled = false;
    setLoading(true);

    (async () => {
      try {
        await wsBootstrap({ signal: controller.signal });
        const result = await _migrateLegacyIfNeeded(userId, { signal: controller.signal });
        if (cancelled || sessionRef.current !== session || activeUserRef.current !== userId) return;
        if (result?.conversations_imported > 0) {
          setMigrated(result);
          toast.success(serviceT("تمت استعادة {count} محادثة إلى مساحة العمل", {
            count: formatNumber(result.conversations_imported),
          }));
        }
        const list = await refreshProjects({ signal: controller.signal, force: true });
        if (cancelled || sessionRef.current !== session || activeUserRef.current !== userId) return;
        const safeList = Array.isArray(list) ? list : [];
        const has = (id) => safeList.some((p) => p._id === id);
        if (stored && has(stored)) {
          _setCurrentProjectId(stored);
        } else {
          const general = safeList.find((p) => p.name === "General") || safeList[0];
          if (general) {
            _setCurrentProjectId(general._id);
            writeStorage(_scopedKey(CURRENT_PROJECT_KEY, userId), general._id);
          }
        }
        setWorkspaceError(null);
      } catch (error) {
        if (!cancelled && sessionRef.current === session && activeUserRef.current === userId
            && !isAbortError(error)) setWorkspaceError(error);
      } finally {
        if (!cancelled && sessionRef.current === session && activeUserRef.current === userId) {
          setLoading(false);
        }
        if (bootingKeyRef.current === key) bootingKeyRef.current = null;
      }
    })();

    return () => {
      cancelled = true;
      controller.abort();
      if (bootingKeyRef.current === key) bootingKeyRef.current = null;
    };
  }, [userId, bootRetry, refreshProjects]);

  // Refresh on window focus, but not for every focus event (tab switches can
  // produce several in quick succession). Hidden tabs never start a request.
  useEffect(() => {
    if (!userId) return undefined;
    const onFocus = () => {
      if (document.visibilityState === "hidden") return;
      const now = Date.now();
      if (now - focusRefreshAtRef.current < FOCUS_REFRESH_MS) return;
      focusRefreshAtRef.current = now;
      refreshProjects({ force: true }).catch(() => {});
    };
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [userId, refreshProjects]);

  const retryBootstrap = useCallback(() => setBootRetry((n) => n + 1), []);

  const createProject = useCallback(async (body) => {
    const created = await wsCreateProject(body);
    if (!userId || activeUserRef.current !== userId) return created;
    setProjects((previous) => [created, ...previous.filter((p) => p._id !== created?._id)]);
    setCurrentProjectId(created._id);
    return created;
  }, [userId, setCurrentProjectId]);

  const updateProject = useCallback(async (pid, patch) => {
    const updated = await wsUpdateProject(pid, patch);
    if (!userId || activeUserRef.current !== userId) return updated;
    setProjects((previous) => previous.map((p) => (p._id === pid ? { ...p, ...updated } : p)));
    setArchivedProjects((previous) => previous.map((p) => (p._id === pid ? { ...p, ...updated } : p)));
    // Keep archive membership canonical, but do not block the save on a second
    // request. The stale guard in refreshProjects protects concurrent updates.
    if (patch.is_archived !== undefined) refreshProjects({ force: true }).catch(() => {});
    return updated;
  }, [userId, refreshProjects]);

  const deleteProject = useCallback(async (pid) => {
    await wsDeleteProject(pid);
    if (!userId || activeUserRef.current !== userId) return;
    const next = projects.find((p) => p._id !== pid);
    setProjects((previous) => previous.filter((p) => p._id !== pid));
    setArchivedProjects((previous) => previous.filter((p) => p._id !== pid));
    if (currentProjectId === pid) setCurrentProjectId(next?._id || null);
  }, [userId, currentProjectId, projects, setCurrentProjectId]);

  const touchProjectOpened = useCallback(async (pid) => {
    try { await wsUpdateProject(pid, { touch_opened: true }); } catch { /* telemetry-like touch is best effort */ }
  }, []);

  const currentProject = projects.find((p) => p._id === currentProjectId) || null;

  const value = {
    loading,
    projects, archivedProjects,
    currentProject, currentProjectId,
    setCurrentProjectId,
    refreshProjects,
    createProject, updateProject, deleteProject, touchProjectOpened,
    migrated, workspaceError, retryBootstrap,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useWorkspace = () => {
  const context = useContext(Ctx);
  if (!context) throw new Error("useWorkspace must be used within WorkspaceProvider");
  return context;
};
